import React, { useState } from 'react';
import { ArrowLeft, ArrowRight } from 'lucide-react';

interface SecretAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  correctPassword: string;
}

export const SecretAdminEntryModal: React.FC<SecretAdminModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  correctPassword,
}) => {
  const [inputVal, setInputVal] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Rule 2: If password is correct, open admin panel.
    // If password is wrong, show NO reaction, no error message. Just stay silent.
    if (inputVal === correctPassword) {
      setInputVal('');
      onSuccess();
    } else {
      // Complete silence. No reaction, no toast, no error text.
      // Reset input silently.
      setInputVal('');
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Strictly Rule 2: No text anywhere. Just two arrow buttons on both sides and blank input box in middle */}
        <form onSubmit={handleSubmit} className="relative">
          <div className="flex items-center gap-2.5 w-full">
            {/* Left Arrow: Back */}
            <button
              type="button"
              onClick={onClose}
              className="w-12 h-12 shrink-0 rounded-xl bg-zinc-900 border border-zinc-700 hover:border-zinc-500 text-zinc-400 hover:text-white flex items-center justify-center transition active:scale-95 shadow-2xl cursor-pointer"
              aria-label="Back"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            {/* Password Input Box */}
            <input
              type="password"
              autoFocus
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              className="flex-1 h-12 px-4 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-center focus:outline-none focus:border-zinc-500 shadow-2xl tracking-widest text-lg font-mono"
              placeholder=""
            />

            {/* Right Arrow: Enter / Submit */}
            <button
              type="submit"
              className="w-12 h-12 shrink-0 rounded-xl bg-zinc-900 border border-zinc-700 hover:border-zinc-500 text-zinc-400 hover:text-white flex items-center justify-center transition active:scale-95 shadow-2xl cursor-pointer"
              aria-label="Enter"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
