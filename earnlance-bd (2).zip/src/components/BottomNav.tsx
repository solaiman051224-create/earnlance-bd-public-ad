import React from 'react';
import { BottomTab, Language } from '../types';
import { translations } from '../translations';
import { Home, Crown, CheckSquare, Users, User as UserIcon } from 'lucide-react';

interface BottomNavProps {
  currentTab: BottomTab;
  onTabChange: (tab: BottomTab) => void;
  language: Language;
  hasActivePackage: boolean;
  tasksCompleted: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onTabChange,
  language,
  hasActivePackage,
  tasksCompleted,
}) => {
  const t = translations[language];

  const navItems = [
    {
      id: 'home' as BottomTab,
      label: t.navHome,
      icon: Home,
    },
    {
      id: 'vip' as BottomTab,
      label: t.navVip,
      icon: Crown,
      badge: hasActivePackage ? 'VIP' : undefined,
    },
    {
      id: 'task' as BottomTab,
      label: t.navTask,
      icon: CheckSquare,
      badge: tasksCompleted < 5 && hasActivePackage ? `${5 - tasksCompleted}` : undefined,
    },
    {
      id: 'referral' as BottomTab,
      label: t.navReferral,
      icon: Users,
    },
    {
      id: 'profile' as BottomTab,
      label: t.navProfile,
      icon: UserIcon,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 backdrop-blur-lg border-t border-slate-800 shadow-2xl safe-area-pb">
      <div className="max-w-md mx-auto grid grid-cols-5 h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`relative flex flex-col items-center justify-center transition-all duration-200 select-none ${
                isActive
                  ? 'text-amber-400 font-bold'
                  : 'text-slate-400 hover:text-slate-200 font-medium'
              }`}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform duration-200 ${
                    isActive ? 'scale-110 stroke-[2.4]' : 'stroke-[1.8]'
                  }`}
                />
                {item.badge && (
                  <span className="absolute -top-1.5 -right-2.5 px-1 py-0.2 min-w-4 text-[9px] font-extrabold text-white bg-gradient-to-r from-amber-500 to-rose-500 rounded-full text-center shadow">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className={`text-[11px] mt-1 ${isActive ? 'text-amber-400' : 'text-slate-400'}`}>
                {item.label}
              </span>
              {isActive && (
                <span className="absolute bottom-1 w-6 h-0.5 bg-amber-400 rounded-full shadow-[0_0_8px_rgba(251,191,36,0.8)]" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
