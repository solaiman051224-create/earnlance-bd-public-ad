import React, { useRef } from 'react';
import { EarnlanceLogo } from './EarnlanceLogo';
import { Language, User } from '../types';
import { Globe, Headphones, Wallet } from 'lucide-react';

interface HeaderProps {
  currentUser: User | null;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenSecretAdmin: () => void;
  onOpenSupport: () => void;
  onOpenDeposit: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  language,
  onLanguageChange,
  onOpenSecretAdmin,
  onOpenSupport,
  onOpenDeposit,
}) => {
  // Secret Click Tracker: 5 clicks within 3 seconds, strictly NO visual feedback
  const clicksRef = useRef<number[]>([]);

  const handleLogoClick = () => {
    const now = Date.now();
    clicksRef.current = clicksRef.current.filter((time) => now - time < 3000);
    clicksRef.current.push(now);
    if (clicksRef.current.length >= 5) {
      clicksRef.current = [];
      onOpenSecretAdmin();
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800/80 px-4 py-2.5 transition-all">
      <div className="max-w-md mx-auto flex items-center justify-between gap-2">
        {/* Logo with secret 5-click detector */}
        <EarnlanceLogo
          size="md"
          onClick={handleLogoClick}
          className="active:opacity-95 select-none"
        />

        {/* Right Action Icons: Language Toggle & Wallet or Support */}
        <div className="flex items-center gap-2">
          {/* Language Switcher */}
          <button
            onClick={() => onLanguageChange(language === 'bn' ? 'en' : 'bn')}
            className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/60 shadow-sm transition active:scale-95"
            title={language === 'bn' ? 'Switch to English' : 'বাংলায় পরিবর্তন করুন'}
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span>{language === 'bn' ? 'English' : 'বাংলা'}</span>
          </button>

          {currentUser && (
            <>
              {/* Quick Deposit / Balance badge */}
              <button
                onClick={onOpenDeposit}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-blue-700 to-indigo-700 hover:from-blue-600 hover:to-indigo-600 text-white font-bold text-xs shadow-md border border-blue-500/30 active:scale-95 transition"
              >
                <Wallet className="w-3.5 h-3.5 text-amber-300" />
                <span>৳ {currentUser.balance.toLocaleString()}</span>
              </button>

              {/* In-app Support */}
              <button
                onClick={onOpenSupport}
                className="relative p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 active:scale-95 transition"
                title="In-App Support"
              >
                <Headphones className="w-4 h-4 text-blue-400" />
                <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-slate-900 animate-pulse"></span>
              </button>
            </>
          )}
        </div>
      </div>
    </header>
  );
};
