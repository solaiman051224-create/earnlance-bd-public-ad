import React, { useState, useRef, useEffect } from 'react';
import { Language, SupportMessage, User } from '../types';
import { translations } from '../translations';
import { MessageSquare, Send, X, Headphones } from 'lucide-react';

interface SupportModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  messages: SupportMessage[];
  language: Language;
  onSendMessage: (text: string) => void;
}

export const SupportModal: React.FC<SupportModalProps> = ({
  isOpen,
  onClose,
  user,
  messages,
  language,
  onSendMessage,
}) => {
  const t = translations[language];
  const [text, setText] = useState('');
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Filter messages for current user
  const userMessages = messages.filter((m) => m.userId === user.id);

  useEffect(() => {
    if (isOpen) {
      chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isOpen, userMessages.length]);

  if (!isOpen) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    onSendMessage(text.trim());
    setText('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm h-[520px] bg-slate-900 border border-slate-700 rounded-2xl flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-3.5 bg-slate-850 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
              <Headphones className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>{t.supportTitle}</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              </h3>
              <p className="text-[10px] text-slate-400">{t.supportSubtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Thread */}
        <div className="flex-1 p-3.5 overflow-y-auto space-y-3 bg-slate-950/40">
          {userMessages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-4 text-slate-500 space-y-2">
              <MessageSquare className="w-8 h-8 opacity-40 text-blue-400" />
              <p className="text-xs">
                {language === 'bn'
                  ? 'এখনও কোন বার্তা নেই। আপনার সমস্যা বা প্রশ্ন লিখে পাঠান, অ্যাডমিন সহায়তা করবেন।'
                  : 'No messages yet. Send a message, the system administrator will assist you.'}
              </p>
            </div>
          ) : (
            userMessages.map((msg) => {
              const isAdmin = msg.sender === 'admin';
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isAdmin ? 'items-start' : 'items-end'}`}
                >
                  <div className="flex items-center gap-1 mb-1">
                    <span className="text-[10px] font-bold text-slate-400">
                      {isAdmin ? t.adminBadge : t.youBadge}
                    </span>
                    <span className="text-[9px] text-slate-500 font-mono">
                      {new Date(msg.createdAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <div
                    className={`max-w-[85%] rounded-2xl px-3 py-2 text-xs leading-relaxed ${
                      isAdmin
                        ? 'bg-slate-800 border border-slate-700 text-slate-200 rounded-tl-xs'
                        : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-tr-xs shadow-md'
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              );
            })
          )}
          <div ref={chatBottomRef} />
        </div>

        {/* Chat Input */}
        <form
          onSubmit={handleSend}
          className="p-2.5 bg-slate-900 border-t border-slate-800 flex items-center gap-2"
        >
          <input
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={t.typeMessage}
            className="flex-1 px-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-blue-400"
          />
          <button
            type="submit"
            disabled={!text.trim()}
            className="p-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white transition active:scale-95"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
