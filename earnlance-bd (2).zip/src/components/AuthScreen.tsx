import React, { useState, useEffect, useRef } from 'react';
import { EarnlanceLogo } from './EarnlanceLogo';
import { Language, User } from '../types';
import { translations } from '../translations';
import { apiLoginUser, apiRegisterUser } from '../api';
import { Phone, Lock, UserPlus, LogIn, AlertCircle, Globe } from 'lucide-react';

interface AuthScreenProps {
  users: User[];
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onLoginSuccess: (user: User) => void;
  onRegisterSuccess: (newUser: User) => void;
  onSecretAdminClick: () => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({
  users,
  language,
  onLanguageChange,
  onLoginSuccess,
  onRegisterSuccess,
  onSecretAdminClick,
}) => {
  const t = translations[language];
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Check URL query for ?ref=
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    if (ref) {
      setReferralCode(ref.trim().toUpperCase());
      setMode('register');
    }
  }, []);

  // Secret 5-click tracker on logo (Rule 2)
  const clicksRef = useRef<number[]>([]);
  const handleLogoClick = () => {
    const now = Date.now();
    clicksRef.current = clicksRef.current.filter((time) => now - time < 3000);
    clicksRef.current.push(now);
    if (clicksRef.current.length >= 5) {
      clicksRef.current = [];
      onSecretAdminClick();
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanPhone = phone.trim();
    if (!cleanPhone || !password) {
      setError(language === 'bn' ? 'সব তথ্য পূরণ করুন' : 'Please fill all fields');
      return;
    }

    setLoading(true);
    try {
      const res = await apiLoginUser({ phone: cleanPhone, password });
      if (res.success && res.user) {
        onLoginSuccess(res.user);
        return;
      }
      if (res.error) {
        setError(res.error);
        return;
      }

      // Offline / Local fallback
      const matchedUser = users.find(
        (u) =>
          (u.phone.toLowerCase() === cleanPhone.toLowerCase() ||
            u.id.toLowerCase() === cleanPhone.toLowerCase() ||
            (u.referralCode && u.referralCode.toLowerCase() === cleanPhone.toLowerCase())) &&
          u.password === password
      );
      if (!matchedUser) {
        setError(t.invalidCredentials);
        return;
      }
      if (matchedUser.isBlocked) {
        setError(t.accountBlocked);
        return;
      }

      onLoginSuccess(matchedUser);
    } catch {
      setError('লগইন ব্যর্থ হয়েছে। পুনরায় চেষ্টা করুন।');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanPhone = phone.trim();
    const cleanRef = referralCode.trim().toUpperCase();

    if (!cleanPhone || cleanPhone.length < 11) {
      setError(
        language === 'bn'
          ? 'সঠিক ১১ সংখ্যার মোবাইল নাম্বার দিন (যেমন: 01XXXXXXXXX)'
          : 'Please enter a valid 11-digit phone number'
      );
      return;
    }

    if (!password || password.length < 6) {
      setError(
        language === 'bn'
          ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে'
          : 'Password must be at least 6 characters'
      );
      return;
    }

    if (password !== confirmPassword) {
      setError(
        language === 'bn' ? 'পাসওয়ার্ড দুইটি মিলছে না' : 'Passwords do not match'
      );
      return;
    }

    // Rule 1: Registration is impossible without a Referral Code
    if (!cleanRef) {
      setError(t.referralRequiredNote);
      return;
    }

    setLoading(true);
    try {
      // 1. Call persistent backend API
      const res = await apiRegisterUser({
        phone: cleanPhone,
        password,
        referralCode: cleanRef,
      });

      if (res.success && res.user) {
        onRegisterSuccess(res.user);
        return;
      }
      if (res.error) {
        setError(res.error);
        return;
      }

      // 2. Offline fallback
      const exists = users.some((u) => u.phone === cleanPhone);
      if (exists) {
        setError(t.phoneExists);
        return;
      }

      const isMasterCode = ['EARNLANCE', 'OFFICIAL', 'VIP100', 'ADMIN01'].includes(cleanRef);
      const referrer = users.find(
        (u) => u.referralCode.toUpperCase() === cleanRef
      );

      if (!referrer && !isMasterCode && users.length > 0) {
        setError(t.invalidReferral);
        return;
      }

      const newReferralCode = 'EL' + Math.floor(100000 + Math.random() * 900000);
      const newUser: User = {
        id: `user_${Date.now()}`,
        phone: cleanPhone,
        password: password,
        balance: 0,
        totalDeposit: 0,
        totalWithdraw: 0,
        totalEarned: 0,
        referralCode: newReferralCode,
        referredBy: referrer ? referrer.referralCode : cleanRef,
        activePackageId: null,
        purchasedPackageIds: [],
        packageActivatedAt: null,
        bkashNagadNumber: null,
        withdrawPassword: null,
        paymentMethod: null,
        paymentDetailsSet: false,
        tasksCompletedToday: 0,
        lastTaskTimestamp: null,
        isBlocked: false,
        createdAt: new Date().toISOString(),
      };

      onRegisterSuccess(newUser);
    } catch {
      setError('রেজিস্ট্রেশন ব্যর্থ হয়েছে। আবার চেষ্টা করুন।');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-between bg-slate-950 p-4 relative overflow-hidden">
      {/* Background Glows */}
      <div className="absolute -top-32 -left-32 w-80 h-80 rounded-full bg-blue-600/15 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-80 h-80 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />

      {/* Language Bar */}
      <div className="flex items-center justify-between max-w-sm w-full mx-auto pt-2">
        <span className="text-[10px] text-slate-500 font-mono tracking-wider">
          SECURE 256-BIT ENCRYPTION
        </span>
        <button
          onClick={() => onLanguageChange(language === 'bn' ? 'en' : 'bn')}
          className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-900 text-slate-300 border border-slate-800 hover:bg-slate-850 transition"
        >
          <Globe className="w-3.5 h-3.5 text-amber-400" />
          <span>{language === 'bn' ? 'English' : 'বাংলা'}</span>
        </button>
      </div>

      {/* Auth Card */}
      <div className="w-full max-w-sm mx-auto my-auto space-y-5">
        {/* Logo with secret 5-click handler */}
        <div className="text-center space-y-1">
          <div className="flex justify-center pb-1">
            <EarnlanceLogo
              size="lg"
              onClick={handleLogoClick}
              className="active:opacity-90 transition-opacity select-none cursor-pointer"
            />
          </div>
          <p className="text-xs text-slate-400 font-medium">
            {t.tagline}
          </p>
        </div>

        {/* Tab Toggle: Login / Register */}
        <div className="p-1 rounded-xl bg-slate-900 border border-slate-800 grid grid-cols-2 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setError('');
            }}
            className={`py-2 rounded-lg transition ${
              mode === 'login'
                ? 'bg-gradient-to-r from-blue-700 to-indigo-700 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {t.login}
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setError('');
            }}
            className={`py-2 rounded-lg transition ${
              mode === 'register'
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {t.register}
          </button>
        </div>

        {/* Error Callout */}
        {error && (
          <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2 animate-shake">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Login Form */}
        {mode === 'login' ? (
          <form onSubmit={handleLogin} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {t.phone}
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  required
                  autoCapitalize="none"
                  autoCorrect="off"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder={t.phonePlaceholder}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {t.password}
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t.passwordPlaceholder}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-700 via-indigo-600 to-blue-700 hover:from-blue-600 hover:to-indigo-500 text-white font-bold text-sm shadow-lg shadow-blue-600/20 active:scale-98 transition flex items-center justify-center gap-2 mt-2 disabled:opacity-60"
            >
              <LogIn className="w-4 h-4" />
              <span>{loading ? 'লোড হচ্ছে...' : t.login}</span>
            </button>
          </form>
        ) : (
          /* Registration Form */
          <form onSubmit={handleRegister} className="space-y-3">
            {/* Rule 1: Registration requires a Referral Code */}
            <div>
              <label className="block text-xs font-semibold text-amber-400 mb-1">
                {t.referralCode} *
              </label>
              <input
                type="text"
                required
                value={referralCode}
                onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
                placeholder={language === 'bn' ? 'রেফার কোড দিন (যেমন: OFFICIAL)' : 'Enter Referral Code'}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-amber-500/40 text-amber-300 text-sm font-mono uppercase focus:outline-none focus:border-amber-400"
              />
              <p className="text-[10px] text-slate-400 mt-1">
                {language === 'bn'
                  ? 'রেফার কোড ছাড়া একাউন্ট খোলা অসম্ভব। সঠিক রেফার কোড দিন।'
                  : 'Referral code is mandatory for account creation.'}
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {t.phone} (One account per phone)
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-sm font-mono focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {t.password}
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Min 6 characters"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-sm focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {t.confirmPassword}
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm password"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-sm focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 active:scale-98 transition flex items-center justify-center gap-2 mt-1 disabled:opacity-60"
            >
              <UserPlus className="w-4 h-4" />
              <span>{loading ? 'লোড হচ্ছে...' : t.register}</span>
            </button>
          </form>
        )}
      </div>

      {/* Footer Branding */}
      <footer className="text-center py-3 text-slate-500 text-[11px] font-mono">
        © 2026 EARNLANCE BD. All Rights Reserved.
      </footer>
    </div>
  );
};
