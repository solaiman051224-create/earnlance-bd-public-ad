import React from 'react';

interface LogoProps {
  className?: string;
  onClick?: () => void;
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const EarnlanceLogo: React.FC<LogoProps> = ({
  className = '',
  onClick,
  showText = true,
  size = 'md',
}) => {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
  };

  const textSizes = {
    sm: 'text-base',
    md: 'text-xl',
    lg: 'text-2xl',
  };

  return (
    <div
      onClick={onClick}
      className={`inline-flex items-center gap-2.5 select-none cursor-pointer ${className}`}
      role="button"
      tabIndex={0}
      title="Earnlance BD"
    >
      {/* SVG recreation of the Earnlance BD shield logo */}
      <div className={`relative ${iconSizes[size]} shrink-0 drop-shadow-md`}>
        <svg
          viewBox="0 0 120 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full"
        >
          {/* Shield Outline */}
          <path
            d="M60 6C86 6 108 17 108 34C108 68 85 99 60 114C35 99 12 68 12 34C12 17 34 6 60 6Z"
            stroke="#2563EB"
            strokeWidth="9"
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
          />
          {/* Letter E with horizontal cross bars */}
          <path
            d="M32 37H86"
            stroke="#3B82F6"
            strokeWidth="8.5"
            strokeLinecap="round"
          />
          <path
            d="M32 59H84"
            stroke="#3B82F6"
            strokeWidth="8.5"
            strokeLinecap="round"
          />
          <path
            d="M32 59V76C32 87 45 93 60 93C75 93 86 85 86 74"
            stroke="#3B82F6"
            strokeWidth="8.5"
            strokeLinecap="round"
          />
          {/* Golden Taka Symbol (৳) nested inside */}
          <g transform="translate(68, 51) scale(0.68)">
            <path
              d="M14 8C14 4.5 17 2 21 2C25 2 28 4.5 28 8C28 11.5 24 15 19 18L10 24C6 26.5 4 30.5 4 35.5C4 44 11 51 22 51C33 51 39 44 39 36"
              stroke="#F59E0B"
              strokeWidth="5.5"
              strokeLinecap="round"
              fill="none"
            />
            <path
              d="M0 24H36"
              stroke="#F59E0B"
              strokeWidth="5.5"
              strokeLinecap="round"
            />
          </g>
        </svg>
      </div>

      {showText && (
        <div className="flex items-center tracking-tight leading-none">
          <span className={`font-black text-blue-500 tracking-wider ${textSizes[size]}`}>
            EARNLANCE
          </span>
          <span className={`font-black text-amber-400 ml-1.5 ${textSizes[size]}`}>
            BD
          </span>
        </div>
      )}
    </div>
  );
};
