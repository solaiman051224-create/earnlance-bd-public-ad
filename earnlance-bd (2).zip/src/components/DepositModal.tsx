import React, { useState } from 'react';
import { AdminConfig, Language, User } from '../types';
import { translations } from '../translations';
import { Copy, Check, X, ArrowDownLeft } from 'lucide-react';

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  adminConfig: AdminConfig;
  language: Language;
  onSubmitDeposit: (amount: number, method: 'bKash' | 'Nagad', senderNumber: string, trxId: string) => void;
}

export const DepositModal: React.FC<DepositModalProps> = ({
  isOpen,
  onClose,
  user,
  adminConfig,
  language,
  onSubmitDeposit,
}) => {
  const t = translations[language];
  const [method, setMethod] = useState<'bKash' | 'Nagad'>('bKash');
  const [amount, setAmount] = useState<string>('1000');
  const [senderNumber, setSenderNumber] = useState(user.bkashNagadNumber || user.phone);
  const [trxId, setTrxId] = useState('');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const currentReceivingNumber = method === 'bKash' ? adminConfig.bkashNumber : adminConfig.nagadNumber;
  const currentReceivingType = method === 'bKash' ? adminConfig.bkashType : adminConfig.nagadType;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentReceivingNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount < adminConfig.minDeposit) {
      setError(language === 'bn' ? `সর্বনিম্ন রিচার্জ ৳ ${adminConfig.minDeposit}` : `Minimum deposit is ৳ ${adminConfig.minDeposit}`);
      return;
    }

    if (!senderNumber.trim() || senderNumber.trim().length < 11) {
      setError(language === 'bn' ? 'সঠিক সেন্ডার নাম্বার দিন' : 'Enter valid sender phone number');
      return;
    }

    if (!trxId.trim() || trxId.trim().length < 5) {
      setError(language === 'bn' ? 'সঠিক TrxID (ট্রানজেকশন আইডি) লিখুন' : 'Enter valid Transaction ID (TrxID)');
      return;
    }

    onSubmitDeposit(numAmount, method, senderNumber.trim(), trxId.trim().toUpperCase());
    onClose();
  };

  const quickAmounts = [500, 1000, 2000, 3000, 5000, 10000];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl p-5 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <ArrowDownLeft className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">{t.depositTitle}</h3>
              <p className="text-[11px] text-slate-400">{t.officialNumbers}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Method selector */}
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => setMethod('bKash')}
            className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 border transition ${
              method === 'bKash'
                ? 'bg-pink-600/25 border-pink-500 text-pink-300 shadow-sm'
                : 'bg-slate-800/80 border-slate-700 text-slate-400'
            }`}
          >
            <span>bKash (বিকাশ)</span>
          </button>
          <button
            type="button"
            onClick={() => setMethod('Nagad')}
            className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 border transition ${
              method === 'Nagad'
                ? 'bg-amber-600/25 border-amber-500 text-amber-300 shadow-sm'
                : 'bg-slate-800/80 border-slate-700 text-slate-400'
            }`}
          >
            <span>Nagad (নগদ)</span>
          </button>
        </div>

        {/* Admin Payment Receiving Number Card */}
        <div className="p-3.5 rounded-xl bg-slate-800/90 border border-slate-700 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-300">
            <span className="font-medium">{t.sendToNumber} ({currentReceivingType}):</span>
            <span className="text-[10px] bg-slate-700 px-2 py-0.5 rounded text-amber-300">
              {method}
            </span>
          </div>
          <div className="flex items-center justify-between bg-slate-900/80 px-3 py-2 rounded-lg border border-slate-700/60">
            <span className="font-mono text-base font-bold text-white tracking-wider">
              {currentReceivingNumber}
            </span>
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition active:scale-95"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? t.copied : 'Copy'}</span>
            </button>
          </div>
          <p className="text-[11px] text-amber-300/90">
            {t.minDepositNotice.replace('{min}', String(adminConfig.minDeposit))}
          </p>
        </div>

        {error && (
          <div className="p-2.5 rounded-lg bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3">
          {/* Quick Amount Chips */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {t.enterAmount}
            </label>
            <div className="grid grid-cols-3 gap-1.5 mb-2">
              {quickAmounts.map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setAmount(String(amt))}
                  className={`py-1 rounded-lg text-xs font-bold transition border ${
                    amount === String(amt)
                      ? 'bg-amber-500 text-slate-950 border-amber-400'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
                  }`}
                >
                  ৳ {amt}
                </button>
              ))}
            </div>
            <input
              type="number"
              min={adminConfig.minDeposit}
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono text-sm focus:outline-none focus:border-amber-400"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {t.enterSenderPhone}
            </label>
            <input
              type="tel"
              required
              value={senderNumber}
              onChange={(e) => setSenderNumber(e.target.value)}
              placeholder="01XXXXXXXXX"
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-400 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {t.enterTrxId}
            </label>
            <input
              type="text"
              required
              value={trxId}
              onChange={(e) => setTrxId(e.target.value)}
              placeholder="e.g. 9B8X2KLM"
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono text-sm uppercase focus:outline-none focus:border-amber-400"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/20 active:scale-98 transition mt-1"
          >
            {t.submitDeposit}
          </button>
        </form>
      </div>
    </div>
  );
};
