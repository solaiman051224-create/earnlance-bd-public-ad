import React, { useState } from 'react';
import { AdminConfig, Language, User } from '../types';
import { translations } from '../translations';
import { ArrowUpRight, X, AlertCircle } from 'lucide-react';

interface WithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  adminConfig: AdminConfig;
  language: Language;
  onSubmitWithdraw: (amount: number, withdrawPassword: string) => void;
}

export const WithdrawModal: React.FC<WithdrawModalProps> = ({
  isOpen,
  onClose,
  user,
  adminConfig,
  language,
  onSubmitWithdraw,
}) => {
  const t = translations[language];
  const [amount, setAmount] = useState<string>('500');
  const [withdrawPassword, setWithdrawPassword] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount < adminConfig.minWithdraw) {
      setError(
        language === 'bn'
          ? `সর্বনিম্ন উত্তোলন ৳ ${adminConfig.minWithdraw}`
          : `Minimum withdrawal is ৳ ${adminConfig.minWithdraw}`
      );
      return;
    }

    if (numAmount > user.balance) {
      setError(
        language === 'bn'
          ? `অপর্যাপ্ত ব্যালেন্স! আপনার বর্তমান ব্যালেন্স ৳ ${user.balance}`
          : `Insufficient balance! Your current balance is ৳ ${user.balance}`
      );
      return;
    }

    // Verify Withdraw Password set by user during setup
    if (withdrawPassword !== user.withdrawPassword) {
      setError(t.wrongWithdrawPassword);
      return;
    }

    onSubmitWithdraw(numAmount, withdrawPassword);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
              <ArrowUpRight className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">{t.withdrawTitle}</h3>
              <p className="text-[11px] text-slate-400">{t.withdrawInstruction}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Balance & Locked Wallet Card */}
        <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">{t.currentBalance}:</span>
            <span className="text-base font-bold text-amber-400 font-mono">
              ৳ {user.balance.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-700/50">
            <div className="flex items-center gap-1.5 text-xs text-slate-300">
              <span className="text-amber-400 font-semibold">{user.paymentMethod || 'bKash'}:</span>
              <span className="font-mono font-bold text-white">
                {user.bkashNagadNumber || user.phone}
              </span>
            </div>
          </div>
        </div>

        {error && (
          <div className="p-2.5 rounded-lg bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {t.enterWithdrawAmount}
            </label>
            <input
              type="number"
              min={adminConfig.minWithdraw}
              max={user.balance}
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono text-sm focus:outline-none focus:border-amber-400"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              {t.minWithdrawNotice.replace('{min}', String(adminConfig.minWithdraw))}
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {t.enterWithdrawPassword}
            </label>
            <input
              type="password"
              required
              value={withdrawPassword}
              onChange={(e) => setWithdrawPassword(e.target.value)}
              placeholder="গোপন উইথড্র পাসওয়ার্ড লিখুন"
              className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-400 font-mono"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 active:scale-98 transition"
          >
            {t.submitWithdraw}
          </button>
        </form>
      </div>
    </div>
  );
};
