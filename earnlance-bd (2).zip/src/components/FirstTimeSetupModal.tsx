import React, { useState } from 'react';
import { Language } from '../types';
import { translations } from '../translations';
import { Wallet, CheckCircle2, X } from 'lucide-react';

interface FirstTimeSetupModalProps {
  isOpen: boolean;
  language: Language;
  onSave: (paymentMethod: 'bKash' | 'Nagad', walletNumber: string, withdrawPassword: string) => void;
  onClose?: () => void;
}

export const FirstTimeSetupModal: React.FC<FirstTimeSetupModalProps> = ({
  isOpen,
  language,
  onSave,
  onClose,
}) => {
  const t = translations[language];
  const [method, setMethod] = useState<'bKash' | 'Nagad'>('bKash');
  const [walletNumber, setWalletNumber] = useState('');
  const [withdrawPassword, setWithdrawPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanNumber = walletNumber.trim();
    if (!cleanNumber || cleanNumber.length < 11) {
      setError(language === 'bn' ? 'সঠিক ১১ সংখ্যার মোবাইল নাম্বার দিন (যেমন: 01XXXXXXXXX)' : 'Enter a valid 11-digit phone number (e.g. 01XXXXXXXXX)');
      return;
    }

    if (!withdrawPassword || withdrawPassword.length < 4) {
      setError(language === 'bn' ? 'উইথড্র পাসওয়ার্ড কমপক্ষে ৪ সংখ্যার হতে হবে' : 'Withdraw password must be at least 4 digits');
      return;
    }

    if (withdrawPassword !== confirmPassword) {
      setError(language === 'bn' ? 'দুইটি উইথড্র পাসওয়ার্ড মিলছে না' : 'Withdraw passwords do not match');
      return;
    }

    onSave(method, cleanNumber, withdrawPassword);
    if (onClose) onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700/80 rounded-2xl p-5 shadow-2xl space-y-4 animate-in zoom-in-95 duration-200 relative">
        {onClose && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        {/* Header Icon */}
        <div className="text-center space-y-1.5 pt-1">
          <div className="w-12 h-12 mx-auto rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
            <Wallet className="w-6 h-6" />
          </div>
          <h2 className="text-lg font-bold text-white">
            {language === 'bn' ? 'ওয়ালেট যুক্ত করুন' : 'Setup Wallet'}
          </h2>
          <p className="text-xs text-slate-400">
            {language === 'bn' ? 'আপনার বিকাশ বা নগদ একাউন্ট ও গোপন উইথড্র পিন সেট করুন।' : 'Configure your bKash or Nagad wallet & withdraw password.'}
          </p>
        </div>

        {error && (
          <div className="p-2.5 rounded-lg bg-rose-950/50 border border-rose-500/40 text-rose-300 text-xs font-medium">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {/* Method Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {t.selectPaymentMethod}
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setMethod('bKash')}
                className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 border transition cursor-pointer ${
                  method === 'bKash'
                    ? 'bg-pink-600/20 border-pink-500 text-pink-300 shadow-sm'
                    : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                }`}
              >
                <span>bKash (বিকাশ)</span>
              </button>
              <button
                type="button"
                onClick={() => setMethod('Nagad')}
                className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 border transition cursor-pointer ${
                  method === 'Nagad'
                    ? 'bg-amber-600/20 border-amber-500 text-amber-300 shadow-sm'
                    : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                }`}
              >
                <span>Nagad (নগদ)</span>
              </button>
            </div>
          </div>

          {/* Account Number */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {method} {t.phone}
            </label>
            <input
              type="tel"
              required
              value={walletNumber}
              onChange={(e) => setWalletNumber(e.target.value)}
              placeholder="01XXXXXXXXX"
              className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-400 font-mono"
            />
          </div>

          {/* Withdraw Password */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {t.withdrawPassword}
            </label>
            <input
              type="password"
              required
              value={withdrawPassword}
              onChange={(e) => setWithdrawPassword(e.target.value)}
              placeholder="৪-৬ সংখ্যার উইথড্র পিন"
              className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-400 font-mono"
            />
          </div>

          {/* Confirm Withdraw Password */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {t.confirmWithdrawPassword}
            </label>
            <input
              type="password"
              required
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="পাসওয়ার্ড পুনরায় লিখুন"
              className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-400 font-mono"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 active:scale-98 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{language === 'bn' ? 'ওয়ালেট সেভ করুন' : 'Save Wallet'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
