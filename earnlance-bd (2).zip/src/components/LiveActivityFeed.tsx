import React, { useEffect, useState } from 'react';
import { Zap } from 'lucide-react';
import { Language } from '../types';
import { DEFAULT_FEED_ITEMS } from '../storage';

interface LiveActivityFeedProps {
  feedItems: string[];
  isActive: boolean;
  language: Language;
}

export const LiveActivityFeed: React.FC<LiveActivityFeedProps> = ({
  feedItems,
  isActive,
  language,
}) => {
  const [index, setIndex] = useState(0);

  const displayItems =
    feedItems && feedItems.length > 0 ? feedItems : DEFAULT_FEED_ITEMS;

  useEffect(() => {
    if (!isActive || displayItems.length <= 1) return;
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % displayItems.length);
    }, 2600);
    return () => clearInterval(interval);
  }, [isActive, displayItems.length]);

  if (!isActive || displayItems.length === 0) return null;

  const currentItem = displayItems[index % displayItems.length];

  return (
    <div className="w-full bg-slate-900/95 border border-slate-800 rounded-xl p-2.5 shadow-lg overflow-hidden backdrop-blur-sm">
      <div className="flex items-center gap-2">
        {/* Pulse Live Badge */}
        <div className="flex items-center gap-1.5 shrink-0 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span>{language === 'bn' ? 'সরাসরি লেনদেন' : 'LIVE FEED'}</span>
        </div>

        {/* Ticker Item */}
        <div className="flex-1 overflow-hidden relative h-5">
          <div
            key={index}
            className="flex items-center gap-1.5 text-xs text-slate-200 font-medium whitespace-nowrap animate-in fade-in slide-in-from-bottom-2 duration-300"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="font-semibold text-white tracking-wide truncate">
              {currentItem}
            </span>
            <span className="text-[10px] text-emerald-400 font-bold ml-auto shrink-0 font-mono bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
              {language === 'bn' ? 'এইমাত্র' : 'Just now'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
