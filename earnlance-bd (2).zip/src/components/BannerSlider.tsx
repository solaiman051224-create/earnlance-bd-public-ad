import React, { useState, useEffect } from 'react';
import { Banner } from '../types';
import { ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';

interface BannerSliderProps {
  banners: Banner[];
  onBannerAction?: (banner: Banner) => void;
}

export const BannerSlider: React.FC<BannerSliderProps> = ({ banners, onBannerAction }) => {
  const activeBanners = banners.filter((b) => b.isActive);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Auto change every 2 seconds per Rule 5
  useEffect(() => {
    if (activeBanners.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
    }, 2000);
    return () => clearInterval(timer);
  }, [activeBanners.length]);

  if (activeBanners.length === 0) {
    return null;
  }

  const current = activeBanners[currentIndex % activeBanners.length];

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev - 1 + activeBanners.length) % activeBanners.length);
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
  };

  return (
    <div className="relative w-full overflow-hidden rounded-2xl border border-slate-700/60 shadow-xl bg-slate-900 group">
      {/* Banner Canvas */}
      <div className="relative h-44 sm:h-48 w-full overflow-hidden">
        {/* Background Image with Fallback gradient */}
        <img
          src={current.imageUrl}
          alt={current.title}
          className="absolute inset-0 w-full h-full object-cover object-center transform transition-transform duration-700 scale-105"
        />

        {/* Gradient Overlay for high contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/90 via-slate-900/50 to-transparent" />

        {/* Content */}
        <div className="absolute inset-0 p-4 flex flex-col justify-end z-10">
          <div className="flex items-center gap-1.5 mb-1.5">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-500/90 text-slate-950 shadow-sm">
              <Sparkles className="w-3 h-3" />
              {current.tag || 'VIP Notice'}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              {currentIndex + 1}/{activeBanners.length}
            </span>
          </div>
          <h3 className="text-lg font-extrabold text-white leading-tight drop-shadow-md">
            {current.title}
          </h3>
          <p className="text-xs text-slate-300 font-medium line-clamp-2 mt-0.5 max-w-[85%] drop-shadow">
            {current.subtitle}
          </p>

          {current.linkText && (
            <div className="mt-2.5">
              <span
                onClick={() => onBannerAction && onBannerAction(current)}
                className="inline-flex items-center text-[11px] font-bold text-amber-300 hover:text-amber-200 cursor-pointer bg-slate-800/80 px-2.5 py-1 rounded-lg border border-slate-700/80 backdrop-blur-sm"
              >
                {current.linkText} →
              </span>
            </div>
          )}
        </div>

        {/* Manual Arrows */}
        <button
          onClick={handlePrev}
          aria-label="Previous Banner"
          className="absolute left-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center opacity-70 group-hover:opacity-100 transition backdrop-blur-xs z-20"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <button
          onClick={handleNext}
          aria-label="Next Banner"
          className="absolute right-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center opacity-70 group-hover:opacity-100 transition backdrop-blur-xs z-20"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Indicator Dots */}
      <div className="absolute bottom-2 right-3 z-20 flex items-center gap-1">
        {activeBanners.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentIndex(idx)}
            aria-label={`Slide ${idx + 1}`}
            className={`h-1.5 rounded-full transition-all duration-300 ${
              idx === currentIndex
                ? 'w-5 bg-amber-400 shadow-[0_0_6px_rgba(251,191,36,0.9)]'
                : 'w-1.5 bg-white/40'
            }`}
          />
        ))}
      </div>
    </div>
  );
};
