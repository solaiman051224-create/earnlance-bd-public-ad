import React, { useState, useEffect } from 'react';
import { AdTask, Language } from '../types';
import { translations } from '../translations';
import { Play, CheckCircle2, Volume2 } from 'lucide-react';

interface AdPlayerModalProps {
  isOpen: boolean;
  ad: AdTask | null;
  taskIndex: number;
  language: Language;
  onClose: () => void;
  onComplete: () => void;
}

export const AdPlayerModal: React.FC<AdPlayerModalProps> = ({
  isOpen,
  ad,
  taskIndex,
  language,
  onClose,
  onComplete,
}) => {
  const t = translations[language];
  const [timeLeft, setTimeLeft] = useState(6);
  const [isCompleted, setIsCompleted] = useState(false);

  useEffect(() => {
    if (!isOpen || !ad) {
      setTimeLeft(6);
      setIsCompleted(false);
      return;
    }

    const duration = ad.durationSeconds || 6;
    setTimeLeft(duration);
    setIsCompleted(false);

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsCompleted(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, ad]);

  if (!isOpen || !ad) return null;

  const totalDuration = ad.durationSeconds || 6;
  const progressPercent = Math.min(100, Math.round(((totalDuration - timeLeft) / totalDuration) * 100));

  const handleClaim = () => {
    onComplete();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl space-y-3">
        {/* Ad Video Simulator Screen */}
        <div className="relative h-56 bg-black overflow-hidden group">
          <img
            src={ad.thumbnail}
            alt={ad.title}
            className="w-full h-full object-cover opacity-85"
          />

          {/* Video Player Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/60 p-3 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="px-2 py-0.5 rounded-full bg-amber-500/90 text-slate-950 text-[10px] font-bold">
                Task #{taskIndex + 1}
              </span>
              <div className="flex items-center gap-1.5 bg-black/60 px-2 py-0.5 rounded-full text-[11px] text-white font-mono">
                <Volume2 className="w-3.5 h-3.5 text-slate-300" />
                <span>{timeLeft > 0 ? `${timeLeft}s` : 'DONE'}</span>
              </div>
            </div>

            {/* Play animation pulse if running */}
            {!isCompleted && (
              <div className="self-center flex flex-col items-center gap-2">
                <div className="w-12 h-12 rounded-full bg-blue-600/60 backdrop-blur-sm border border-blue-400/40 flex items-center justify-center text-white animate-pulse">
                  <Play className="w-6 h-6 fill-white ml-0.5" />
                </div>
                <span className="text-xs font-semibold text-white/90 drop-shadow">
                  {t.watchingAd}
                </span>
              </div>
            )}

            {/* Bottom info */}
            <div>
              <p className="text-xs font-bold text-white drop-shadow">
                {language === 'bn' ? ad.titleBn : ad.title}
              </p>
              <p className="text-[10px] text-slate-300">
                {t.adSponsor}: {ad.sponsor} • {ad.category}
              </p>
            </div>
          </div>

          {/* Video Progress Bar */}
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-slate-800">
            <div
              className="h-full bg-amber-400 transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Modal Body & Action */}
        <div className="p-4 pt-1 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>{language === 'bn' ? 'বিজ্ঞাপন অগ্রগতি' : 'Ad View Progress'}</span>
            <span className="font-mono font-bold text-amber-400">{progressPercent}%</span>
          </div>

          {isCompleted ? (
            <button
              onClick={handleClaim}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/20 active:scale-98 transition flex items-center justify-center gap-2 animate-bounce"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{t.claimReward}</span>
            </button>
          ) : (
            <button
              disabled
              className="w-full py-2.5 rounded-xl bg-slate-800 text-slate-400 font-bold text-xs cursor-not-allowed flex items-center justify-center gap-2"
            >
              <span>{language === 'bn' ? `অনুগ্রহ করে অপেক্ষা করুন (${timeLeft}s)` : `Please wait (${timeLeft}s)`}</span>
            </button>
          )}

          <div className="text-center">
            <button
              onClick={onClose}
              className="text-xs text-slate-400 hover:text-white transition"
            >
              {t.cancel}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
