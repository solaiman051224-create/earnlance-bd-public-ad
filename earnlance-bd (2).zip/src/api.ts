import {
  AdminConfig,
  AdTask,
  Banner,
  SupportMessage,
  Transaction,
  User,
  VipPackage,
} from './types';

export interface ServerState {
  users: User[];
  packages: VipPackage[];
  banners: Banner[];
  tasks: AdTask[];
  transactions: Transaction[];
  supportMessages: SupportMessage[];
  feedItems: string[];
  adminConfig: AdminConfig;
}

export async function fetchServerState(): Promise<ServerState | null> {
  try {
    const res = await fetch('/api/state');
    if (!res.ok) return null;
    return await res.json();
  } catch (err) {
    console.warn('Could not fetch server state:', err);
    return null;
  }
}

export async function apiRegisterUser(data: {
  phone: string;
  password: string;
  referralCode: string;
}): Promise<{ success: boolean; user?: User; error?: string }> {
  try {
    const res = await fetch('/api/users/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, error: err?.message || 'Network error' };
  }
}

export async function apiLoginUser(data: {
  phone: string;
  password: string;
}): Promise<{ success: boolean; user?: User; error?: string }> {
  try {
    const res = await fetch('/api/users/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, error: err?.message || 'Network error' };
  }
}

export async function apiUpdateUser(user: User): Promise<boolean> {
  try {
    const res = await fetch(`/api/users/${user.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(user),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function apiToggleBlockUser(userId: string): Promise<boolean> {
  try {
    const res = await fetch('/api/users/toggle-block', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function apiDeleteUser(
  userId: string
): Promise<{ success: boolean; users?: User[]; deletedUsers?: any[] }> {
  try {
    const res = await fetch('/api/admin/delete-user', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId }),
    });
    if (!res.ok) return { success: false };
    return await res.json();
  } catch {
    return { success: false };
  }
}

export async function apiAdminCreateUser(data: {
  phone: string;
  password?: string;
  balance?: number;
  packageId?: string;
}): Promise<{
  success: boolean;
  user?: User;
  users?: User[];
  transactions?: Transaction[];
  deletedUsers?: any[];
  error?: string;
}> {
  try {
    const res = await fetch('/api/admin/create-user', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await res.json().catch(() => null);
    if (!res.ok) {
      return {
        success: false,
        error: result?.error || `Server error (${res.status})`,
      };
    }
    return result || { success: false, error: 'Empty response' };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Network error' };
  }
}

export async function apiPurchasePackage(
  userId: string,
  packageId: string
): Promise<{
  success: boolean;
  user?: User;
  refundedAmount?: number;
  previousPackageName?: string;
  error?: string;
}> {
  try {
    const res = await fetch('/api/packages/purchase', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, packageId }),
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, error: err?.message || 'Network error' };
  }
}

export async function apiCompleteTask(
  userId: string
): Promise<{ success: boolean; user?: User; error?: string }> {
  try {
    const res = await fetch('/api/tasks/complete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId }),
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, error: err?.message || 'Network error' };
  }
}

export async function apiSubmitDeposit(data: {
  userId: string;
  amount: number;
  method: string;
  senderNumber: string;
  trxId: string;
}): Promise<{ success: boolean; transaction?: Transaction; error?: string }> {
  try {
    const res = await fetch('/api/transactions/deposit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, error: err?.message || 'Network error' };
  }
}

export async function apiSubmitWithdraw(data: {
  userId: string;
  amount: number;
  withdrawPassword: string;
}): Promise<{ success: boolean; transaction?: Transaction; user?: User; error?: string }> {
  try {
    const res = await fetch('/api/transactions/withdraw', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, error: err?.message || 'Network error' };
  }
}

export async function apiUpdateTransactionStatus(
  txId: string,
  status: 'approved' | 'rejected'
): Promise<{ success: boolean; transaction?: Transaction; user?: User; error?: string }> {
  try {
    const res = await fetch('/api/transactions/status', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ txId, status }),
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, error: err?.message || 'Network error' };
  }
}

export async function apiAdjustUserBalance(
  userId: string,
  action: 'add' | 'deduct',
  amount: number,
  note?: string
): Promise<{ success: boolean; user?: User; error?: string }> {
  try {
    const res = await fetch('/api/admin/user/balance', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, action, amount, note }),
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, error: err?.message || 'Network error' };
  }
}

export async function apiUpdateAdminUsers(users: User[]): Promise<boolean> {
  try {
    const res = await fetch('/api/admin/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ users }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function apiUpdateAdminConfig(config: AdminConfig): Promise<boolean> {
  try {
    const res = await fetch('/api/admin/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function apiUpdatePackages(packages: VipPackage[]): Promise<boolean> {
  try {
    const res = await fetch('/api/admin/packages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ packages }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function apiUpdateBanners(banners: Banner[]): Promise<boolean> {
  try {
    const res = await fetch('/api/admin/banners', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ banners }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function apiUpdateTasks(tasks: AdTask[]): Promise<boolean> {
  try {
    const res = await fetch('/api/admin/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tasks }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function apiSendSupportMessage(data: {
  userId: string;
  text: string;
  sender: 'user' | 'admin';
}): Promise<{ success: boolean; message?: SupportMessage }> {
  try {
    const res = await fetch('/api/support/message', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return await res.json();
  } catch {
    return { success: false };
  }
}
