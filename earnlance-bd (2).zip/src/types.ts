export type Language = 'bn' | 'en';
export type BottomTab = 'home' | 'vip' | 'task' | 'referral' | 'profile';

export interface User {
  id: string;
  phone: string;
  password: string;
  balance: number;
  totalDeposit: number;
  totalWithdraw: number;
  totalEarned: number;
  referralCode: string;
  referredBy: string | null;
  activePackageId: string | null;
  purchasedPackageIds: string[]; // lifetime rule: each package can be bought only once
  packageActivatedAt: string | null;
  bkashNagadNumber: string | null;
  withdrawPassword: string | null;
  paymentMethod: 'bKash' | 'Nagad' | null;
  paymentDetailsSet: boolean; // Once set by user, cannot be modified by user. Only admin can modify.
  tasksCompletedToday: number; // 0 to 5
  lastTaskTimestamp: number | null; // Milliseconds timestamp of last batch completion
  isBlocked?: boolean; // Admin can block or unblock user
  createdAt: string;
}

export interface VipPackage {
  id: string;
  tier: number;
  name: string;
  nameBn: string;
  price: number;
  dailyIncome: number;
  validityDays: number;
  isActive: boolean;
  description: string;
  badgeColor: string;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  imageUrl: string;
  linkText: string;
  tag: string;
  bgGradient: string;
  isActive: boolean;
}

export interface AdTask {
  id: string;
  title: string;
  titleBn: string;
  sponsor: string;
  category: string;
  durationSeconds: number;
  thumbnail: string;
  isActive: boolean;
}

export interface Transaction {
  id: string;
  userId: string;
  userPhone: string;
  type: 'deposit' | 'withdraw' | 'task_income' | 'package_purchase' | 'package_refund' | 'referral_commission';
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  method: 'bKash' | 'Nagad' | 'Wallet';
  accountNumber?: string;
  trxId?: string;
  packageName?: string;
  createdAt: string;
  note?: string;
}

export interface ActivityFeedItem {
  id: string;
  text: string;
  createdAt: string;
}

export interface SupportMessage {
  id: string;
  userId: string;
  sender: 'user' | 'admin';
  text: string;
  createdAt: string;
  read: boolean;
}

export interface AdminConfig {
  adminPassword: string;
  bkashNumber: string;
  nagadNumber: string;
  bkashType: string; // e.g. "Send Money (Personal)"
  nagadType: string; // e.g. "Send Money (Personal)"
  minDeposit: number;
  minWithdraw: number;
  feedActive: boolean;
  customFeedItems: string[];
}
