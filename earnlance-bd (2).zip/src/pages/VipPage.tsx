import React, { useState } from 'react';
import { Language, User, VipPackage } from '../types';
import { translations } from '../translations';
import { Crown, CheckCircle, AlertTriangle, Zap, Clock, Lock } from 'lucide-react';

interface VipPageProps {
  currentUser: User | null;
  packages: VipPackage[];
  language: Language;
  onPurchasePackage: (pkg: VipPackage) => void;
  onOpenDeposit: () => void;
}

export const VipPage: React.FC<VipPageProps> = ({
  currentUser,
  packages,
  language,
  onPurchasePackage,
  onOpenDeposit,
}) => {
  const t = translations[language];
  const [selectedPkg, setSelectedPkg] = useState<VipPackage | null>(null);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showInsufficientModal, setShowInsufficientModal] = useState(false);

  const activePackage = currentUser?.activePackageId
    ? packages.find((p) => p.id === currentUser.activePackageId)
    : null;

  const handleBuyClick = (pkg: VipPackage) => {
    if (!currentUser) return;
    if (!pkg.isActive) return;

    // Already active
    if (currentUser.activePackageId === pkg.id) {
      return;
    }

    // Downgrade blocked: cannot buy smaller package if a bigger package is active
    if (activePackage && pkg.price <= activePackage.price) {
      return;
    }

    // Balance check: user's available balance includes previous package refund if upgrading
    const refundAmount = activePackage ? activePackage.price : 0;
    const availableBalance = currentUser.balance + refundAmount;

    if (availableBalance < pkg.price) {
      setSelectedPkg(pkg);
      setShowInsufficientModal(true);
      return;
    }

    setSelectedPkg(pkg);
    setShowConfirmModal(true);
  };

  const handleConfirmPurchase = () => {
    if (!selectedPkg) return;
    onPurchasePackage(selectedPkg);
    setShowConfirmModal(false);
    setSelectedPkg(null);
  };

  return (
    <div className="space-y-4 pb-24">
      {/* Page Header */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-900 via-indigo-950 to-slate-900 border border-blue-500/30 text-white space-y-2 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-amber-400">
            <Crown className="w-5 h-5" />
            <h2 className="text-base font-extrabold uppercase tracking-wide">
              {t.vipTitle}
            </h2>
          </div>
          {activePackage && (
            <span className="text-[11px] font-bold text-amber-300 bg-amber-500/10 px-2.5 py-0.5 rounded-full border border-amber-500/20">
              {language === 'bn' ? activePackage.nameBn : activePackage.name} সক্রিয়
            </span>
          )}
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          {t.vipSubtitle}
        </p>

        {activePackage ? (
          <div className="pt-2 border-t border-slate-700/60 text-xs space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">বর্তমান সক্রিয় প্যাকেজ:</span>
              <span className="font-bold text-amber-300">
                {language === 'bn' ? activePackage.nameBn : activePackage.name} (৳ {activePackage.price.toLocaleString()})
              </span>
            </div>
            <p className="text-[11px] text-emerald-400/90 leading-normal">
              💡 নিয়ম: একজন ইউজার একসাথে ১টি ভিআইপি প্যাকেজে কাজ করতে পারবেন। নতুন বড় প্যাকেজে আপগ্রেড করলে বর্তমান প্যাকেজ বন্ধ হয়ে তার মূল্য (৳{activePackage.price.toLocaleString()}) ব্যালেন্সে রিফান্ড হবে। ছোট প্যাকেজ কেনা যাবে না।
            </p>
          </div>
        ) : (
          <div className="pt-1.5 border-t border-slate-700/60 text-[11px] text-slate-400">
            {language === 'bn'
              ? 'যেকোনো একটি ভিআইপি প্যাকেজ বেছে নিয়ে দৈনিক ইনকাম শুরু করুন।'
              : 'Choose any VIP package to unlock tasks and start earning daily income.'}
          </div>
        )}
      </div>

      {/* 10 VIP Packages Grid */}
      <div className="space-y-3">
        {packages.map((pkg) => {
          const isCurrentActive = currentUser?.activePackageId === pkg.id;
          const isDowngrade = Boolean(activePackage && pkg.price <= activePackage.price && !isCurrentActive);
          const isUpgrade = Boolean(activePackage && pkg.price > activePackage.price);
          const totalEstimatedIncome = pkg.dailyIncome * pkg.validityDays;

          return (
            <div
              key={pkg.id}
              className={`relative rounded-2xl border transition-all overflow-hidden ${
                isCurrentActive
                  ? 'bg-gradient-to-br from-blue-950 via-slate-900 to-indigo-950 border-blue-400 ring-2 ring-blue-500/40 shadow-xl'
                  : isDowngrade
                  ? 'bg-slate-900/60 border-slate-800 opacity-65'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700 shadow-md'
              }`}
            >
              {/* Top Banner Stripe */}
              <div className="px-4 py-3 flex items-center justify-between border-b border-slate-800/80">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-7 h-7 rounded-lg bg-gradient-to-br ${pkg.badgeColor} flex items-center justify-center text-slate-950 font-black text-xs shadow`}
                  >
                    V{pkg.tier}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                      <span>{language === 'bn' ? pkg.nameBn : pkg.name}</span>
                      {isCurrentActive && (
                        <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.2 rounded border border-emerald-500/30">
                          {t.statusActive}
                        </span>
                      )}
                    </h3>
                    <span className="text-[10px] text-slate-400">
                      Tier {pkg.tier} Plan
                    </span>
                  </div>
                </div>

                {/* Price Tag */}
                <div className="text-right">
                  <div className="text-base font-black text-amber-400 font-mono tracking-tight">
                    ৳ {pkg.price.toLocaleString()}
                  </div>
                  <span className="text-[10px] text-slate-400 block -mt-0.5">
                    {t.price}
                  </span>
                </div>
              </div>

              {/* Package Details */}
              <div className="p-4 space-y-3">
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="p-2 rounded-xl bg-slate-800/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">{t.dailyProfit}</span>
                    <span className="text-xs font-bold text-emerald-400 font-mono">
                      ৳ {pkg.dailyIncome.toLocaleString()}
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-800/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">{t.validity}</span>
                    <span className="text-xs font-bold text-white font-mono">
                      {pkg.validityDays} {t.days}
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-800/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">{t.totalIncome}</span>
                    <span className="text-xs font-bold text-amber-300 font-mono">
                      ৳ {totalEstimatedIncome.toLocaleString()}
                    </span>
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 leading-relaxed italic">
                  {pkg.description}
                </p>

                {/* Purchase Button State with Upgrade/Downgrade Rules */}
                <div>
                  {isCurrentActive ? (
                    <div className="w-full py-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm">
                      <CheckCircle className="w-4 h-4 text-emerald-400" />
                      <span>{t.statusActive}</span>
                    </div>
                  ) : !pkg.isActive ? (
                    <button
                      disabled
                      className="w-full py-2.5 px-3 rounded-xl bg-slate-800/90 border border-amber-500/40 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 cursor-not-allowed shadow-inner transition select-none"
                    >
                      <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span className="truncate">{t.packageNotActive}</span>
                    </button>
                  ) : isDowngrade ? (
                    <button
                      disabled
                      title="বড় প্যাকেজ থাকা অবস্থায় ছোট প্যাকেজ কেনা সম্ভব নয়"
                      className="w-full py-2.5 px-3 rounded-xl bg-slate-800/70 border border-rose-500/30 text-rose-300/80 font-bold text-xs flex items-center justify-center gap-1.5 cursor-not-allowed select-none transition"
                    >
                      <Lock className="w-3.5 h-3.5 text-rose-400" />
                      <span>{t.cannotBuySmaller}</span>
                    </button>
                  ) : isUpgrade ? (
                    <div className="space-y-1">
                      <button
                        onClick={() => handleBuyClick(pkg)}
                        className="w-full py-2.5 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-black text-xs shadow-md shadow-indigo-500/25 active:scale-98 transition flex items-center justify-center gap-1.5"
                      >
                        <Zap className="w-3.5 h-3.5 fill-current text-amber-300" />
                        <span>{t.upgradeNow} (৳ {pkg.price.toLocaleString()})</span>
                      </button>
                      <div className="text-[10px] text-emerald-400/90 text-center font-medium">
                        🔄 পূর্বের {activePackage?.name} প্যাকেজের ৳{(activePackage?.price || 0).toLocaleString()} ব্যালেন্সে ফেরত পাবেন
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => handleBuyClick(pkg)}
                      className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs shadow-md shadow-amber-500/20 active:scale-98 transition flex items-center justify-center gap-1.5"
                    >
                      <Zap className="w-3.5 h-3.5 stroke-[2.5]" />
                      <span>{t.buyNow} (৳ {pkg.price.toLocaleString()})</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Confirmation Modal */}
      {showConfirmModal && selectedPkg && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="text-center space-y-1.5">
              <div className="w-12 h-12 mx-auto rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                <Crown className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">
                {activePackage ? t.confirmUpgradeTitle : t.confirmBuyTitle}
              </h3>
              <p className="text-xs text-slate-300">
                {language === 'bn'
                  ? `আপনি কি ${selectedPkg.nameBn} প্যাকেজটি (৳${selectedPkg.price.toLocaleString()}) বেছে নিতে নিশ্চিত?`
                  : `Are you sure you want to activate ${selectedPkg.name} for ৳${selectedPkg.price.toLocaleString()}?`}
              </p>
            </div>

            {/* If user is upgrading from an existing package */}
            {activePackage ? (
              <div className="p-3.5 rounded-xl bg-blue-950/40 border border-blue-500/30 text-xs space-y-2">
                <div className="flex items-center gap-1.5 text-blue-300 font-bold">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span>আপগ্রেড ও রিফান্ড হিসাব:</span>
                </div>
                <div className="space-y-1.5 text-slate-300 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-400">বর্তমান প্যাকেজ:</span>
                    <span className="font-bold text-amber-400">{activePackage.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">পূর্বের প্যাকেজ রিফান্ড:</span>
                    <span className="font-bold text-emerald-400 font-mono">+ ৳ {activePackage.price.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">নতুন প্যাকেজ মূল্য:</span>
                    <span className="font-bold text-rose-400 font-mono">- ৳ {selectedPkg.price.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between pt-1 border-t border-slate-700/60">
                    <span className="text-slate-400">আপনার বর্তমান ব্যালেন্স:</span>
                    <span className="font-mono font-bold text-white">৳ {(currentUser?.balance || 0).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between pt-1 border-t border-slate-700/60 text-xs">
                    <span className="text-amber-300 font-bold">আপগ্রেড পরবর্তী ব্যালেন্স:</span>
                    <span className="font-mono font-black text-amber-300">
                      ৳ {((currentUser?.balance || 0) + activePackage.price - selectedPkg.price).toLocaleString()}
                    </span>
                  </div>
                </div>
                <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-[10px] text-amber-300 flex items-start gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <p className="leading-tight">
                    নতুন প্যাকেজ অ্যাক্টিভ করার সাথে সাথে আগের {activePackage.name} প্যাকেজটি বন্ধ হয়ে যাবে এবং তার সম্পূর্ণ ৳{activePackage.price.toLocaleString()} আপনার ব্যালেন্সে যোগ হবে।
                  </p>
                </div>
              </div>
            ) : null}

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-bold transition"
              >
                {t.cancel}
              </button>
              <button
                type="button"
                onClick={handleConfirmPurchase}
                className="py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-black shadow-md transition"
              >
                {activePackage ? t.upgradeNow : t.buyNow}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Insufficient Balance Modal */}
      {showInsufficientModal && selectedPkg && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="text-center space-y-1.5">
              <div className="w-12 h-12 mx-auto rounded-full bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">
                {t.insufficientBalance}
              </h3>
              <div className="text-xs text-slate-300 text-left p-3 rounded-xl bg-slate-800/80 border border-slate-700 space-y-1">
                {activePackage ? (
                  <>
                    <div className="flex justify-between">
                      <span className="text-slate-400">নতুন প্যাকেজ মূল্য:</span>
                      <span className="font-bold text-amber-400 font-mono">৳ {selectedPkg.price.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">পূর্বের প্যাকেজ রিফান্ড:</span>
                      <span className="font-bold text-emerald-400 font-mono">+ ৳ {activePackage.price.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">বর্তমান ব্যালেন্স:</span>
                      <span className="font-bold text-white font-mono">৳ {(currentUser?.balance || 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between pt-1 border-t border-slate-700 text-rose-400 font-bold">
                      <span>ঘাটতি (আরও লাগবে):</span>
                      <span className="font-mono">
                        ৳ {(selectedPkg.price - ((currentUser?.balance || 0) + activePackage.price)).toLocaleString()}
                      </span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex justify-between">
                      <span className="text-slate-400">প্যাকেজ মূল্য:</span>
                      <span className="font-bold text-amber-400 font-mono">৳ {selectedPkg.price.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">বর্তমান ব্যালেন্স:</span>
                      <span className="font-bold text-white font-mono">৳ {(currentUser?.balance || 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between pt-1 border-t border-slate-700 text-rose-400 font-bold">
                      <span>ঘাটতি (আরও লাগবে):</span>
                      <span className="font-mono">
                        ৳ {(selectedPkg.price - (currentUser?.balance || 0)).toLocaleString()}
                      </span>
                    </div>
                  </>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowInsufficientModal(false)}
                className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-bold transition"
              >
                {t.cancel}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowInsufficientModal(false);
                  onOpenDeposit();
                }}
                className="py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-extrabold shadow-md transition"
              >
                {t.depositNow}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
