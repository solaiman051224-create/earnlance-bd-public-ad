import React, { useState, useEffect } from 'react';
import { AdTask, Language, User, VipPackage } from '../types';
import { translations } from '../translations';
import { AdPlayerModal } from '../components/AdPlayerModal';
import {
  PlayCircle,
  Lock,
  Clock,
  CheckCircle2,
  Sparkles,
  Crown,
} from 'lucide-react';

interface TaskPageProps {
  currentUser: User | null;
  tasks: AdTask[];
  packages: VipPackage[];
  language: Language;
  onNavigateToVip: () => void;
  onCompleteTask: (taskId: string) => void;
}

export const TaskPage: React.FC<TaskPageProps> = ({
  currentUser,
  tasks,
  packages,
  language,
  onNavigateToVip,
  onCompleteTask,
}) => {
  const t = translations[language];

  const activePackage = currentUser?.activePackageId
    ? packages.find((p) => p.id === currentUser.activePackageId)
    : null;

  const [activeAd, setActiveAd] = useState<AdTask | null>(null);
  const [selectedTaskIndex, setSelectedTaskIndex] = useState(0);
  const [timeLeft24h, setTimeLeft24h] = useState('');

  // 24 Hour Countdown Timer calculation
  useEffect(() => {
    if (!currentUser?.lastTaskTimestamp || currentUser.tasksCompletedToday < 5) return;

    const interval = setInterval(() => {
      const now = Date.now();
      const elapsed = now - currentUser.lastTaskTimestamp!;
      const remaining = 24 * 3600 * 1000 - elapsed;

      if (remaining <= 0) {
        setTimeLeft24h('00:00:00');
        clearInterval(interval);
      } else {
        const hours = Math.floor(remaining / (3600 * 1000));
        const minutes = Math.floor((remaining % (3600 * 1000)) / (60 * 1000));
        const seconds = Math.floor((remaining % (60 * 1000)) / 1000);
        setTimeLeft24h(
          `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(
            seconds
          ).padStart(2, '0')}`
        );
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [currentUser?.lastTaskTimestamp, currentUser?.tasksCompletedToday]);

  // If user does not have an active package/deposit per Rule 7
  if (!currentUser?.activePackageId || !activePackage) {
    return (
      <div className="space-y-4 pb-20 pt-2">
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 text-center space-y-4 shadow-xl">
          <div className="w-16 h-16 mx-auto rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
            <Lock className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-white">
              {t.taskTitle}
            </h3>
            <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
              {t.noPackageTaskWarning}
            </p>
          </div>
          <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 text-xs text-amber-300">
            {language === 'bn'
              ? 'নিয়ম: শুধুমাত্র প্যাকেজ সক্রিয় করলেই বিজ্ঞাপন ভিডিও দেখা যাবে। কাজ শুরু করতে একটি ভিআইপি প্যাকেজ কিনুন।'
              : 'Rule: User can watch Ads/Videos only if he has an active deposit/package. Activate a VIP package to unlock tasks.'}
          </div>
          <button
            onClick={onNavigateToVip}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/25 active:scale-98 transition flex items-center justify-center gap-2"
          >
            <Crown className="w-4 h-4" />
            <span>{t.goActivateVip}</span>
          </button>
        </div>
      </div>
    );
  }

  // Active ads from admin (filtered to active, strictly take 5)
  const activeTaskList = tasks.filter((t) => t.isActive).slice(0, 5);
  const tasksCompleted = currentUser.tasksCompletedToday || 0;
  const isAllCompleted = tasksCompleted >= 5;

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* Active Package Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-900 via-indigo-950 to-slate-900 border border-blue-500/30 text-white flex items-center justify-between shadow-lg">
        <div>
          <span className="text-[10px] text-blue-300 uppercase font-bold tracking-wider">
            {t.activePackage}
          </span>
          <h3 className="text-sm font-extrabold text-white flex items-center gap-1.5 mt-0.5">
            <Crown className="w-4 h-4 text-amber-400" />
            <span>{language === 'bn' ? activePackage.nameBn : activePackage.name}</span>
          </h3>
        </div>
        <div className="text-right">
          <span className="text-[10px] text-slate-300 block">{t.dailyProfit}</span>
          <span className="text-sm font-black text-amber-400 font-mono">
            ৳ {activePackage.dailyIncome}
          </span>
        </div>
      </div>

      {/* If 5 Tasks Completed -> Rule 7: show "আজকের কাজ সম্পন্ন" and block! Do NOT show 6th video! */}
      {isAllCompleted ? (
        <div className="rounded-2xl bg-gradient-to-b from-slate-900 via-slate-900/90 to-slate-950 border border-emerald-500/40 p-6 text-center space-y-4 shadow-2xl animate-in zoom-in-95 duration-200">
          <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-lg shadow-emerald-500/10">
            <CheckCircle2 className="w-9 h-9" />
          </div>
          <div className="space-y-1.5">
            {/* The exact requested Bengali phrase: আজকের কাজ সম্পন্ন */}
            <h2 className="text-xl font-extrabold text-emerald-400">
              {language === 'bn' ? 'আজকের কাজ সম্পন্ন' : 'Today\'s Task Completed'}
            </h2>
            <p className="text-xs text-slate-300 max-w-xs mx-auto leading-relaxed">
              {t.taskCompleteSubtitle}
            </p>
          </div>

          {/* 24h Countdown Timer Card */}
          <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-1.5">
            <div className="flex items-center justify-center gap-1.5 text-xs text-slate-400">
              <Clock className="w-4 h-4 text-amber-400" />
              <span>{t.timerNextTask}</span>
            </div>
            <div className="font-mono text-2xl font-black text-amber-400 tracking-widest">
              {timeLeft24h || '23:59:45'}
            </div>
            <p className="text-[10px] text-slate-400">
              {language === 'bn' ? '২৪ ঘণ্টা পূর্ণ হলে আবার ৫টি নতুন কাজ পাবেন' : '5 tasks will refresh after 24 hours'}
            </p>
          </div>

          <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-500/20 text-xs text-blue-300 flex items-center justify-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-400" />
            <span>
              {language === 'bn'
                ? `আজকের আয় ৳ ${activePackage.dailyIncome} ব্যালেন্সে যুক্ত হয়েছে!`
                : `Today's earning ৳ ${activePackage.dailyIncome} added to your balance!`}
            </span>
          </div>
        </div>
      ) : (
        /* Task List: Show 5 videos per Rule 7 */
        <div className="space-y-3">
          {/* Progress Header */}
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400 font-bold text-xs">
                {tasksCompleted}/5
              </div>
              <span className="text-xs font-bold text-white">
                {tasksCompleted} {t.ofFiveTasks}
              </span>
            </div>
            {/* Visual step indicators */}
            <div className="flex items-center gap-1.5">
              {[0, 1, 2, 3, 4].map((idx) => (
                <div
                  key={idx}
                  className={`w-4 h-1.5 rounded-full transition-all ${
                    idx < tasksCompleted
                      ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]'
                      : 'bg-slate-700'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* 5 Video/Ad Cards */}
          <div className="space-y-2.5">
            {activeTaskList.map((ad, index) => {
              const isFinished = index < tasksCompleted;
              const isCurrent = index === tasksCompleted;

              return (
                <div
                  key={ad.id}
                  onClick={() => {
                    if (isCurrent) {
                      setSelectedTaskIndex(index);
                      setActiveAd(ad);
                    }
                  }}
                  className={`relative rounded-xl border p-3 flex items-center justify-between transition-all ${
                    isFinished
                      ? 'bg-slate-900/40 border-slate-800 opacity-60'
                      : isCurrent
                      ? 'bg-slate-900 border-amber-500/80 shadow-lg cursor-pointer ring-1 ring-amber-500/40 hover:bg-slate-850'
                      : 'bg-slate-900/60 border-slate-800/80 opacity-40 cursor-not-allowed'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {/* Thumbnail / Status Icon */}
                    <div className="relative w-14 h-14 rounded-lg overflow-hidden shrink-0 border border-slate-700">
                      <img
                        src={ad.thumbnail}
                        alt={ad.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        {isFinished ? (
                          <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                        ) : isCurrent ? (
                          <PlayCircle className="w-6 h-6 text-amber-400 animate-pulse" />
                        ) : (
                          <Lock className="w-5 h-5 text-slate-400" />
                        )}
                      </div>
                    </div>

                    {/* Details */}
                    <div>
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span className="text-[10px] font-bold text-amber-400">
                          Task #{index + 1}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {ad.durationSeconds}s
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-white line-clamp-1">
                        {language === 'bn' ? ad.titleBn : ad.title}
                      </h4>
                      <p className="text-[10px] text-slate-400">
                        {t.adSponsor}: {ad.sponsor}
                      </p>
                    </div>
                  </div>

                  {/* Action button */}
                  <div>
                    {isFinished ? (
                      <span className="text-[11px] font-bold text-emerald-400 px-2.5 py-1 rounded bg-emerald-500/10">
                        {language === 'bn' ? 'সম্পন্ন' : 'Done'}
                      </span>
                    ) : isCurrent ? (
                      <button className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow-md flex items-center gap-1 active:scale-95 transition">
                        <PlayCircle className="w-3.5 h-3.5 fill-slate-950" />
                        <span>{language === 'bn' ? 'দেখুন' : 'Watch'}</span>
                      </button>
                    ) : (
                      <span className="text-[10px] text-slate-500 flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        <span>{language === 'bn' ? 'লকড' : 'Locked'}</span>
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Interactive Ad Watching Modal */}
      <AdPlayerModal
        isOpen={Boolean(activeAd)}
        ad={activeAd}
        taskIndex={selectedTaskIndex}
        language={language}
        onClose={() => setActiveAd(null)}
        onComplete={() => {
          if (activeAd) {
            onCompleteTask(activeAd.id);
            setActiveAd(null);
          }
        }}
      />
    </div>
  );
};
