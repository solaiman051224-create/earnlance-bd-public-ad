import React, { useState } from 'react';
import { Language, Transaction, User } from '../types';
import { translations } from '../translations';
import { Users, Copy, Check, Share2, Gift, ArrowDownRight } from 'lucide-react';

interface ReferralPageProps {
  currentUser: User | null;
  allUsers: User[];
  transactions: Transaction[];
  language: Language;
}

export const ReferralPage: React.FC<ReferralPageProps> = ({
  currentUser,
  allUsers,
  transactions,
  language,
}) => {
  const t = translations[language];
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!currentUser) return null;

  const appOrigin = window.location.origin;
  const referralLink = `${appOrigin}/?ref=${currentUser.referralCode}`;

  // Find invited members
  const invitedUsers = allUsers.filter((u) => u.referredBy === currentUser.referralCode);

  // Referral commissions
  const referralTransactions = transactions.filter(
    (tx) => tx.userId === currentUser.id && tx.type === 'referral_commission'
  );
  const totalCommissionEarned = referralTransactions.reduce((acc, tx) => acc + tx.amount, 0);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentUser.referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* Referral Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-900 via-indigo-950 to-slate-900 border border-blue-500/30 text-white space-y-1.5 shadow-lg">
        <div className="flex items-center gap-2 text-amber-400">
          <Users className="w-5 h-5" />
          <h2 className="text-base font-extrabold uppercase tracking-wide">
            {t.referralTitle}
          </h2>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          {t.referralSubtitle}
        </p>
      </div>

      {/* Referral Code & Link Card */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 shadow-md">
        {/* Code */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-xs font-semibold text-slate-400">
              {t.yourReferralCode}
            </label>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              {language === 'bn' ? `${invitedUsers.length} জন আমন্ত্রিত` : `${invitedUsers.length} Invited`}
            </span>
          </div>
          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800 border border-slate-700">
            <span className="font-mono text-base font-extrabold text-amber-400 tracking-wider">
              {currentUser.referralCode}
            </span>
            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition active:scale-95"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCode ? t.copied : t.copyCode}</span>
            </button>
          </div>
        </div>

        {/* Link */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1">
            {t.yourReferralLink}
          </label>
          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800 border border-slate-700 gap-2">
            <span className="font-mono text-xs text-slate-300 truncate">
              {referralLink}
            </span>
            <button
              onClick={handleCopyLink}
              className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition active:scale-95"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copiedLink ? t.copied : t.copyLink}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Referral Stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center gap-2 text-slate-400 text-xs">
            <Users className="w-4 h-4 text-blue-400" />
            <span>{t.totalReferrals}</span>
          </div>
          <div className="text-xl font-black text-white font-mono">
            {invitedUsers.length}
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center gap-2 text-slate-400 text-xs">
            <Gift className="w-4 h-4 text-amber-400" />
            <span>{t.referralCommission}</span>
          </div>
          <div className="text-xl font-black text-amber-400 font-mono">
            ৳ {totalCommissionEarned.toLocaleString()}
          </div>
        </div>
      </div>

      {/* Invited Team List */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 space-y-3">
        <h4 className="text-xs font-extrabold text-white uppercase tracking-wider">
          {language === 'bn' ? 'আমার রেফারেল দল' : 'My Referral Team'}
        </h4>
        {invitedUsers.length === 0 ? (
          <p className="text-xs text-slate-400 text-center py-4">
            {t.noReferralsYet}
          </p>
        ) : (
          <div className="space-y-2">
            {invitedUsers.map((member) => (
              <div
                key={member.id}
                className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/60 text-xs"
              >
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-400 font-mono text-[10px] font-bold">
                    01
                  </div>
                  <div>
                    <p className="font-mono font-bold text-white">
                      {member.phone.slice(0, 3)}****{member.phone.slice(-4)}
                    </p>
                    <p className="text-[10px] text-slate-400">
                      {new Date(member.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-bold border border-emerald-500/20">
                    Active
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Commission History */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 space-y-3">
        <h4 className="text-xs font-extrabold text-white uppercase tracking-wider">
          {t.commissionHistory}
        </h4>
        {referralTransactions.length === 0 ? (
          <p className="text-xs text-slate-400 text-center py-4">
            {language === 'bn' ? 'এখনও কোন কমিশন রেকর্ড নেই।' : 'No commission history yet.'}
          </p>
        ) : (
          <div className="space-y-2">
            {referralTransactions.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/60 text-xs"
              >
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
                    <ArrowDownRight className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-bold text-white">Referral Bonus</p>
                    <p className="text-[10px] text-slate-400">
                      {new Date(tx.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold text-emerald-400">
                    + ৳ {tx.amount}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
