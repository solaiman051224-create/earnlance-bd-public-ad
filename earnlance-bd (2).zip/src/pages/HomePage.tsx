import React from 'react';
import { BannerSlider } from '../components/BannerSlider';
import { LiveActivityFeed } from '../components/LiveActivityFeed';
import { AdminConfig, Banner, BottomTab, Language, User, VipPackage } from '../types';
import { translations } from '../translations';
import {
  ArrowDownLeft,
  ArrowUpRight,
  Crown,
  CheckSquare,
  Headphones,
  ChevronRight,
  Flame,
} from 'lucide-react';

interface HomePageProps {
  currentUser: User | null;
  banners: Banner[];
  packages: VipPackage[];
  adminConfig: AdminConfig;
  feedItems?: string[];
  language: Language;
  onNavigateTab: (tab: BottomTab) => void;
  onOpenDeposit: () => void;
  onOpenWithdraw: () => void;
  onOpenSupport: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  currentUser,
  banners,
  packages,
  adminConfig,
  feedItems,
  language,
  onNavigateTab,
  onOpenDeposit,
  onOpenWithdraw,
  onOpenSupport,
}) => {
  const t = translations[language];

  const activePackage = currentUser?.activePackageId
    ? packages.find((p) => p.id === currentUser.activePackageId)
    : null;

  return (
    <div className="space-y-4 pb-20">
      {/* 10 Banners Slider (Auto changes every 2 seconds per Rule 5) */}
      <section className="pt-2">
        <BannerSlider
          banners={banners}
          onBannerAction={(banner) => {
            if (banner.tag?.includes('VIP') || banner.linkText?.includes('VIP')) {
              onNavigateTab('vip');
            } else if (banner.tag?.includes('Work') || banner.linkText?.includes('Tasks')) {
              onNavigateTab('task');
            } else if (banner.linkText?.includes('Support')) {
              onOpenSupport();
            } else {
              onNavigateTab('vip');
            }
          }}
        />
      </section>

      {/* User Dashboard / Financial Overview Card */}
      {currentUser && (
        <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-900 via-slate-900 to-indigo-950 border border-blue-500/30 p-4 shadow-xl">
          <div className="relative z-10 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-blue-200/80">
                  {t.currentBalance}
                </span>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-2xl font-black text-amber-400 font-mono tracking-tight">
                    ৳ {currentUser.balance.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Active VIP Badge */}
              <div
                onClick={() => onNavigateTab('vip')}
                className="cursor-pointer flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/90 border border-amber-400/30 text-amber-300 text-xs font-bold hover:bg-slate-750 transition"
              >
                <Crown className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  {activePackage
                    ? language === 'bn'
                      ? activePackage.nameBn
                      : activePackage.name
                    : t.noActivePackage}
                </span>
              </div>
            </div>

            {/* Quick Action Buttons: Deposit, Withdraw, Support */}
            <div className="grid grid-cols-3 gap-2 pt-1">
              <button
                onClick={onOpenDeposit}
                className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs shadow-md transition active:scale-95"
              >
                <ArrowDownLeft className="w-4 h-4 stroke-[2.5]" />
                <span>{t.deposit}</span>
              </button>
              <button
                onClick={onOpenWithdraw}
                className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition active:scale-95"
              >
                <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
                <span>{t.withdraw}</span>
              </button>
              <button
                onClick={onOpenSupport}
                className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition active:scale-95"
              >
                <Headphones className="w-4 h-4 text-blue-400" />
                <span>{t.support}</span>
              </button>
            </div>
          </div>

          {/* Decorative shield watermark */}
          <div className="absolute -bottom-8 -right-8 w-32 h-32 opacity-10 pointer-events-none text-white">
            <Crown className="w-full h-full" />
          </div>
        </section>
      )}

      {/* Daily Task Highlight Card */}
      <section
        onClick={() => onNavigateTab('task')}
        className="cursor-pointer rounded-2xl bg-slate-900 border border-slate-800 p-3.5 flex items-center justify-between hover:border-amber-400/40 transition group"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 group-hover:scale-105 transition">
            <CheckSquare className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h4 className="text-xs font-bold text-white">{t.taskTitle}</h4>
              <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-blue-500/20 text-blue-300">
                5 {language === 'bn' ? 'ভিডিও' : 'Videos'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {currentUser?.activePackageId
                ? language === 'bn'
                  ? `আজকের কাজ: ${currentUser.tasksCompletedToday}/৫ সম্পন্ন`
                  : `Today's Progress: ${currentUser.tasksCompletedToday}/5 Done`
                : t.noPackageTaskWarning}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1 text-xs font-bold text-amber-400 group-hover:translate-x-0.5 transition">
          <span>{language === 'bn' ? 'শুরু করুন' : 'Start'}</span>
          <ChevronRight className="w-4 h-4" />
        </div>
      </section>

      {/* VIP Packages Quick Showcase */}
      <section className="space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-extrabold text-white uppercase tracking-wider">
              {t.vipLevels}
            </h3>
          </div>
          <button
            onClick={() => onNavigateTab('vip')}
            className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-0.5"
          >
            <span>{t.viewAllVip}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {packages.slice(0, 4).map((pkg) => {
            const isCurrent = currentUser?.activePackageId === pkg.id;

            return (
              <div
                key={pkg.id}
                onClick={() => onNavigateTab('vip')}
                className={`relative rounded-xl p-3 border transition cursor-pointer flex flex-col justify-between ${
                  isCurrent
                    ? 'bg-blue-950/60 border-blue-500 shadow-lg'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[11px] font-bold text-white">
                      {language === 'bn' ? pkg.nameBn : pkg.name}
                    </span>
                    <span className="text-[10px] font-mono font-bold text-amber-400">
                      ৳ {pkg.price}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-300 space-y-0.5">
                    <div className="flex justify-between">
                      <span className="text-slate-400">{t.dailyProfit}:</span>
                      <span className="font-semibold text-emerald-400 font-mono">
                        ৳ {pkg.dailyIncome}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">{t.validity}:</span>
                      <span>
                        {pkg.validityDays} {t.days}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-2.5 pt-2 border-t border-slate-800/80">
                  <span
                    className={`block w-full py-1 text-center rounded text-[10px] font-bold ${
                      isCurrent
                        ? 'bg-blue-500/20 text-blue-300'
                        : !pkg.isActive
                        ? 'bg-slate-850 text-amber-300/90 border border-amber-500/20'
                        : 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30'
                    }`}
                  >
                    {isCurrent
                      ? t.statusActive
                      : !pkg.isActive
                      ? (language === 'bn' ? 'শীঘ্রই চালু হবে' : 'Coming Soon')
                      : t.buyNow}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Live Activity Feed at bottom per Rule 5 */}
      <section className="pt-1">
        <LiveActivityFeed
          feedItems={feedItems && feedItems.length > 0 ? feedItems : (adminConfig.customFeedItems || [])}
          isActive={adminConfig.feedActive}
          language={language}
        />
      </section>
    </div>
  );
};
