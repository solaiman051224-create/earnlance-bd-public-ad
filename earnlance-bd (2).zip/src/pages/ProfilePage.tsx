import React, { useState } from 'react';
import { Language, Transaction, User, VipPackage } from '../types';
import { translations } from '../translations';
import {
  User as UserIcon,
  Wallet,
  Plus,
  Edit3,
  ArrowDownLeft,
  ArrowUpRight,
  Crown,
  History,
  LogOut,
  Headphones,
  Globe,
} from 'lucide-react';

interface ProfilePageProps {
  currentUser: User | null;
  packages: VipPackage[];
  transactions: Transaction[];
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenDeposit: () => void;
  onOpenWithdraw: () => void;
  onOpenSupport: () => void;
  onOpenWalletSetup: () => void;
  onLogout: () => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({
  currentUser,
  packages,
  transactions,
  language,
  onLanguageChange,
  onOpenDeposit,
  onOpenWithdraw,
  onOpenSupport,
  onOpenWalletSetup,
  onLogout,
}) => {
  const t = translations[language];
  const [historyTab, setHistoryTab] = useState<'deposit' | 'withdraw'>('deposit');

  if (!currentUser) return null;

  const activePackage = currentUser.activePackageId
    ? packages.find((p) => p.id === currentUser.activePackageId)
    : null;

  const userDeposits = transactions.filter(
    (tx) => tx.userId === currentUser.id && tx.type === 'deposit'
  );
  const userWithdraws = transactions.filter(
    (tx) => tx.userId === currentUser.id && tx.type === 'withdraw'
  );

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* User Info Header Card */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-900 via-slate-900 to-indigo-950 border border-blue-500/30 text-white space-y-3 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-lg">
              <UserIcon className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-sm font-black font-mono tracking-wider text-white">
                {currentUser.phone}
              </h2>
              <p className="text-[10px] text-slate-300 font-mono">
                Ref Code: {currentUser.referralCode}
              </p>
            </div>
          </div>

          {/* Active Package Pill */}
          <div className="px-2.5 py-1 rounded-xl bg-amber-500/15 border border-amber-400/30 text-amber-300 text-xs font-bold flex items-center gap-1">
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span>
              {activePackage
                ? language === 'bn'
                  ? activePackage.nameBn
                  : activePackage.name
                : t.noActivePackage}
            </span>
          </div>
        </div>

        {/* Financial Stat Bars */}
        <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-700/60 text-center">
          <div className="p-2 rounded-xl bg-slate-800/60 border border-slate-800">
            <span className="text-[10px] text-slate-400 block">{t.currentBalance}</span>
            <span className="text-xs font-bold text-amber-400 font-mono">
              ৳ {currentUser.balance.toLocaleString()}
            </span>
          </div>
          <div className="p-2 rounded-xl bg-slate-800/60 border border-slate-800">
            <span className="text-[10px] text-slate-400 block">{t.totalDeposits}</span>
            <span className="text-xs font-bold text-emerald-400 font-mono">
              ৳ {currentUser.totalDeposit.toLocaleString()}
            </span>
          </div>
          <div className="p-2 rounded-xl bg-slate-800/60 border border-slate-800">
            <span className="text-[10px] text-slate-400 block">{t.totalWithdrawals}</span>
            <span className="text-xs font-bold text-rose-400 font-mono">
              ৳ {currentUser.totalWithdraw.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Action Buttons: Deposit & Withdraw */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={onOpenDeposit}
            className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md active:scale-95 transition"
          >
            <ArrowDownLeft className="w-4 h-4 stroke-[2.5]" />
            <span>{t.deposit}</span>
          </button>
          <button
            onClick={onOpenWithdraw}
            className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md active:scale-95 transition"
          >
            <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
            <span>{t.withdraw}</span>
          </button>
        </div>
      </div>

      {/* Wallet Card */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2.5 shadow-md">
        {currentUser.paymentDetailsSet && currentUser.bkashNagadNumber ? (
          <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400 shrink-0">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] text-slate-400 block font-semibold">
                {currentUser.paymentMethod || 'bKash'} Wallet
              </span>
              <span className="font-mono text-base font-bold text-white tracking-wider">
                {currentUser.bkashNagadNumber}
              </span>
            </div>
          </div>
        ) : (
          <div
            onClick={onOpenWalletSetup}
            className="p-3.5 rounded-xl bg-slate-800/60 border border-dashed border-slate-700 flex items-center justify-between cursor-pointer hover:border-amber-400/50 hover:bg-slate-800 transition"
          >
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
                <Wallet className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-white">
                {language === 'bn' ? 'ওয়ালেট যুক্ত করুন' : 'Add Wallet'}
              </span>
            </div>
            <Plus className="w-4 h-4 text-amber-400" />
          </div>
        )}

        <p
          onClick={onOpenSupport}
          className="text-xs text-amber-400/90 font-medium cursor-pointer hover:underline text-center pt-0.5"
        >
          {language === 'bn' ? 'অ্যাডমিনের সাথে যোগাযোগ করুন।' : 'Contact admin for assistance.'}
        </p>
      </div>

      {/* Transaction History Tabs: Deposit & Withdraw */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-blue-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              {language === 'bn' ? 'লেনদেনের হিস্ট্রি' : 'Transaction History'}
            </h3>
          </div>

          <div className="flex rounded-lg bg-slate-800 p-0.5 border border-slate-700 text-xs">
            <button
              onClick={() => setHistoryTab('deposit')}
              className={`px-3 py-1 rounded-md font-bold transition ${
                historyTab === 'deposit'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t.depositHistory}
            </button>
            <button
              onClick={() => setHistoryTab('withdraw')}
              className={`px-3 py-1 rounded-md font-bold transition ${
                historyTab === 'withdraw'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t.withdrawHistory}
            </button>
          </div>
        </div>

        {/* History List */}
        <div className="space-y-2">
          {historyTab === 'deposit' ? (
            userDeposits.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-4">{t.emptyHistory}</p>
            ) : (
              userDeposits.map((tx) => (
                <div
                  key={tx.id}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/60 text-xs"
                >
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
                      <ArrowDownLeft className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="font-bold text-white">
                        {tx.method} Deposit
                      </p>
                      <p className="text-[10px] text-slate-400 font-mono">
                        TrxID: {tx.trxId || 'N/A'} • {new Date(tx.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-bold text-emerald-400 block">
                      + ৳ {tx.amount.toLocaleString()}
                    </span>
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                        tx.status === 'approved'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : tx.status === 'pending'
                          ? 'bg-amber-500/20 text-amber-300'
                          : 'bg-rose-500/20 text-rose-300'
                      }`}
                    >
                      {tx.status}
                    </span>
                  </div>
                </div>
              ))
            )
          ) : userWithdraws.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-4">{t.emptyHistory}</p>
          ) : (
            userWithdraws.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/60 text-xs"
              >
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-bold text-white">
                      {tx.method} Withdrawal
                    </p>
                    <p className="text-[10px] text-slate-400 font-mono">
                      {new Date(tx.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold text-rose-400 block">
                    - ৳ {tx.amount.toLocaleString()}
                  </span>
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                      tx.status === 'approved'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : tx.status === 'pending'
                        ? 'bg-amber-500/20 text-amber-300'
                        : 'bg-rose-500/20 text-rose-300'
                    }`}
                  >
                    {tx.status}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Account Settings & Quick Utilities */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-2 space-y-1">
        {/* Support Chat */}
        <button
          onClick={onOpenSupport}
          className="w-full p-3 rounded-xl hover:bg-slate-800/80 text-left flex items-center justify-between text-xs text-slate-200 transition"
        >
          <div className="flex items-center gap-2.5">
            <Headphones className="w-4 h-4 text-blue-400" />
            <span className="font-semibold">{t.support}</span>
          </div>
          <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full font-bold">
            Online
          </span>
        </button>

        {/* Language switch */}
        <button
          onClick={() => onLanguageChange(language === 'bn' ? 'en' : 'bn')}
          className="w-full p-3 rounded-xl hover:bg-slate-800/80 text-left flex items-center justify-between text-xs text-slate-200 transition"
        >
          <div className="flex items-center gap-2.5">
            <Globe className="w-4 h-4 text-amber-400" />
            <span className="font-semibold">{t.changeLanguage}</span>
          </div>
          <span className="text-xs font-mono font-bold text-amber-400">
            {language === 'bn' ? 'বাংলা' : 'English'}
          </span>
        </button>

        {/* Logout */}
        <button
          onClick={onLogout}
          className="w-full p-3 rounded-xl hover:bg-rose-950/30 text-left flex items-center justify-between text-xs text-rose-400 transition"
        >
          <div className="flex items-center gap-2.5">
            <LogOut className="w-4 h-4" />
            <span className="font-semibold">{t.logoutAccount}</span>
          </div>
        </button>
      </div>
    </div>
  );
};
