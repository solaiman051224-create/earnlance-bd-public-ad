import React, { useState } from 'react';
import {
  AdminConfig,
  AdTask,
  Banner,
  Language,
  SupportMessage,
  Transaction,
  User,
  VipPackage,
} from '../types';
import {
  ShieldAlert,
  CreditCard,
  Crown,
  Image as ImageIcon,
  PlaySquare,
  Activity,
  Users,
  CheckCircle,
  XCircle,
  Key,
  LogOut,
  Save,
  Plus,
  Trash2,
  Edit2,
  MessageSquare,
  Search,
  Ban,
  Unlock,
  Coins,
  Minus,
  UserPlus,
  Copy,
  Check,
  Sparkles,
  AlertCircle,
} from 'lucide-react';

interface AdminPanelProps {
  adminConfig: AdminConfig;
  packages: VipPackage[];
  banners: Banner[];
  tasks: AdTask[];
  users: User[];
  transactions: Transaction[];
  supportMessages: SupportMessage[];
  language?: Language;
  onUpdateAdminConfig: (cfg: AdminConfig) => void;
  onUpdatePackages: (pkgs: VipPackage[]) => void;
  onUpdateBanners: (bans: Banner[]) => void;
  onUpdateTasks: (tasks: AdTask[]) => void;
  onUpdateUsers: (users: User[]) => void;
  onUpdateTransactions: (txs: Transaction[]) => void;
  onUpdateTransactionStatus?: (txId: string, status: 'approved' | 'rejected') => Promise<any> | void;
  onAdjustUserBalance?: (userId: string, action: 'add' | 'deduct', amount: number, note?: string) => Promise<any> | void;
  onCreateUser?: (data: { phone: string; password?: string; balance?: number; packageId?: string }) => Promise<any> | void;
  onSendSupportReply: (userId: string, text: string) => void;
  onDeleteUser?: (userId: string) => void;
  onExitAdmin: () => void;
}

type AdminTab =
  | 'requests'
  | 'numbers'
  | 'packages'
  | 'banners'
  | 'tasks'
  | 'feed'
  | 'users'
  | 'support'
  | 'security';

export const AdminPanel: React.FC<AdminPanelProps> = ({
  adminConfig,
  packages,
  banners,
  tasks,
  users,
  transactions,
  supportMessages,
  onUpdateAdminConfig,
  onUpdatePackages,
  onUpdateBanners,
  onUpdateTasks,
  onUpdateUsers,
  onUpdateTransactions,
  onUpdateTransactionStatus,
  onAdjustUserBalance,
  onCreateUser,
  onSendSupportReply,
  onDeleteUser,
  onExitAdmin,
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('requests');
  const [statusMsg, setStatusMsg] = useState('');

  // Balance adjust modal state
  const [balanceModalUser, setBalanceModalUser] = useState<User | null>(null);
  const [balanceAction, setBalanceAction] = useState<'add' | 'deduct'>('add');
  const [balanceAmount, setBalanceAmount] = useState<string>('');
  const [balanceNote, setBalanceNote] = useState<string>('');
  const [isSubmittingBalance, setIsSubmittingBalance] = useState(false);

  // Admin Create User Modal State
  const [showCreateUserModal, setShowCreateUserModal] = useState(false);
  const [createPhone, setCreatePhone] = useState('');
  const [createPassword, setCreatePassword] = useState('123456');
  const [createBalance, setCreateBalance] = useState('0');
  const [createPackageId, setCreatePackageId] = useState('');
  const [isCreatingUser, setIsCreatingUser] = useState(false);
  const [createError, setCreateError] = useState('');
  const [createdUserSuccess, setCreatedUserSuccess] = useState<User | null>(null);
  const [copiedSuccess, setCopiedSuccess] = useState(false);
  const [copiedUserId, setCopiedUserId] = useState<string | null>(null);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);

  // 1. Payment Numbers State
  const [bkashNum, setBkashNum] = useState(adminConfig.bkashNumber);
  const [nagadNum, setNagadNum] = useState(adminConfig.nagadNumber);
  const [bkashType, setBkashType] = useState(adminConfig.bkashType);
  const [nagadType, setNagadType] = useState(adminConfig.nagadType);
  const [minDeposit, setMinDeposit] = useState(adminConfig.minDeposit);
  const [minWithdraw, setMinWithdraw] = useState(adminConfig.minWithdraw);

  // 2. Packages State
  const [editingPackages, setEditingPackages] = useState<VipPackage[]>([...packages]);

  // 3. Banners State
  const [editingBanners, setEditingBanners] = useState<Banner[]>([...banners]);
  const [newBannerTitle, setNewBannerTitle] = useState('');
  const [newBannerSubtitle, setNewBannerSubtitle] = useState('');
  const [newBannerImg, setNewBannerImg] = useState('');
  const [newBannerTag, setNewBannerTag] = useState('');

  // 4. Tasks State
  const [editingTasks, setEditingTasks] = useState<AdTask[]>([...tasks]);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskSponsor, setNewTaskSponsor] = useState('');
  const [newTaskDuration, setNewTaskDuration] = useState(6);
  const [newTaskThumb, setNewTaskThumb] = useState('');

  // 5. Feed State
  const [feedActive, setFeedActive] = useState(adminConfig.feedActive);
  const [feedItems, setFeedItems] = useState<string[]>([...adminConfig.customFeedItems]);
  const [newFeedText, setNewFeedText] = useState('');

  // 6. Users State & User Edit Modal
  const [userSearch, setUserSearch] = useState('');
  const [userStatusFilter, setUserStatusFilter] = useState<'all' | 'active' | 'blocked'>('all');
  const [editingUser, setEditingUser] = useState<User | null>(null);

  // 7. Security State
  const [newAdminPassword, setNewAdminPassword] = useState('');

  // 8. Support State
  const [selectedSupportUserId, setSelectedSupportUserId] = useState<string>(
    users[0]?.id || ''
  );
  const [adminReplyText, setAdminReplyText] = useState('');

  const showNotification = (msg: string) => {
    setStatusMsg(msg);
    setTimeout(() => setStatusMsg(''), 2500);
  };

  // Save Payment Numbers
  const handleSavePaymentNumbers = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: AdminConfig = {
      ...adminConfig,
      bkashNumber: bkashNum,
      nagadNumber: nagadNum,
      bkashType,
      nagadType,
      minDeposit,
      minWithdraw,
    };
    onUpdateAdminConfig(updated);
    showNotification('Payment receiving numbers updated successfully!');
  };

  // Save Packages
  const handleSavePackages = () => {
    onUpdatePackages(editingPackages);
    showNotification('All 10 VIP packages updated successfully!');
  };

  // Add Banner
  const handleAddBanner = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBannerTitle.trim()) return;
    const banner: Banner = {
      id: `ban-${Date.now()}`,
      title: newBannerTitle.trim(),
      subtitle: newBannerSubtitle.trim() || 'Official Earnlance Promo',
      imageUrl:
        newBannerImg.trim() ||
        'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&auto=format&fit=crop&q=80',
      linkText: 'Check Now',
      tag: newBannerTag.trim() || 'VIP Offer',
      bgGradient: 'from-blue-900 via-indigo-900 to-slate-900',
      isActive: true,
    };
    const updated = [banner, ...editingBanners];
    setEditingBanners(updated);
    onUpdateBanners(updated);
    setNewBannerTitle('');
    setNewBannerSubtitle('');
    setNewBannerImg('');
    setNewBannerTag('');
    showNotification('New Banner added!');
  };

  const handleDeleteBanner = (id: string) => {
    const updated = editingBanners.filter((b) => b.id !== id);
    setEditingBanners(updated);
    onUpdateBanners(updated);
    showNotification('Banner deleted.');
  };

  const handleToggleBanner = (id: string) => {
    const updated = editingBanners.map((b) => (b.id === id ? { ...b, isActive: !b.isActive } : b));
    setEditingBanners(updated);
    onUpdateBanners(updated);
  };

  // Add Task Ad
  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    const task: AdTask = {
      id: `task-${Date.now()}`,
      title: newTaskTitle.trim(),
      titleBn: newTaskTitle.trim(),
      sponsor: newTaskSponsor.trim() || 'Earnlance Partner',
      category: 'Sponsored Video',
      durationSeconds: newTaskDuration || 6,
      thumbnail:
        newTaskThumb.trim() ||
        'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=500&auto=format&fit=crop&q=80',
      isActive: true,
    };
    const updated = [...editingTasks, task];
    setEditingTasks(updated);
    onUpdateTasks(updated);
    setNewTaskTitle('');
    setNewTaskSponsor('');
    setNewTaskThumb('');
    showNotification('New Video task added!');
  };

  const handleDeleteTask = (id: string) => {
    const updated = editingTasks.filter((t) => t.id !== id);
    setEditingTasks(updated);
    onUpdateTasks(updated);
    showNotification('Task deleted.');
  };

  const handleToggleTask = (id: string) => {
    const updated = editingTasks.map((t) => (t.id === id ? { ...t, isActive: !t.isActive } : t));
    setEditingTasks(updated);
    onUpdateTasks(updated);
  };

  // Feed Actions
  const handleAddFeedItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFeedText.trim()) return;
    const updated = [newFeedText.trim(), ...feedItems];
    setFeedItems(updated);
    onUpdateAdminConfig({
      ...adminConfig,
      feedActive,
      customFeedItems: updated,
    });
    setNewFeedText('');
    showNotification('Feed item added!');
  };

  const handleDeleteFeedItem = (index: number) => {
    const updated = feedItems.filter((_, i) => i !== index);
    setFeedItems(updated);
    onUpdateAdminConfig({
      ...adminConfig,
      feedActive,
      customFeedItems: updated,
    });
  };

  const handleToggleFeed = () => {
    const nextState = !feedActive;
    setFeedActive(nextState);
    onUpdateAdminConfig({
      ...adminConfig,
      feedActive: nextState,
      customFeedItems: feedItems,
    });
  };

  // User Edit Save
  const handleSaveUserEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    const updatedUsers = users.map((u) => (u.id === editingUser.id ? editingUser : u));
    onUpdateUsers(updatedUsers);
    setEditingUser(null);
    showNotification(`User ${editingUser.phone} updated successfully!`);
  };

  // User Block & Unblock toggle
  const handleToggleBlockUser = (targetUser: User) => {
    const nextBlockedState = !targetUser.isBlocked;
    const updatedUsers = users.map((u) =>
      u.id === targetUser.id ? { ...u, isBlocked: nextBlockedState } : u
    );
    onUpdateUsers(updatedUsers);
    showNotification(
      nextBlockedState
        ? `User ${targetUser.phone} has been BLOCKED!`
        : `User ${targetUser.phone} has been UNBLOCKED!`
    );
  };

  // Delete User (Permanent - Only Admin Can Delete)
  const handleDeleteUserDirect = (userId: string, phone: string) => {
    if (window.confirm(`আপনি কি নিশ্চিত যে ইউজার (${phone}) মুছে ফেলতে চান?`)) {
      if (onDeleteUser) {
        onDeleteUser(userId);
      } else {
        const filtered = users.filter((u) => u.id !== userId);
        onUpdateUsers(filtered);
      }
      setEditingUser(null);
      showNotification(`ইউজার ${phone} মুছে ফেলা হয়েছে!`);
    }
  };

  // Generate Random Phone / ID
  const handleGeneratePhone = () => {
    const prefixes = ['017', '018', '019', '016', '013'];
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const randomDigits = Math.floor(10000000 + Math.random() * 90000000);
    setCreatePhone(`${prefix}${randomDigits}`);
  };

  const handleGeneratePassword = () => {
    const randomPass = Math.floor(100000 + Math.random() * 900000).toString();
    setCreatePassword(randomPass);
  };

  // Copy User Login Details / Invite Info (Quick 1-click share)
  const handleCopyCredentials = (user: User) => {
    const origin = window.location.origin;
    const refLink = `${origin}/?ref=${user.referralCode}`;
    const text = `🎉 আপনার Earnlance BD একাউন্ট তৈরি সম্পন্ন হয়েছে!\n📱 লগইন আইডি / ফোন: ${user.phone}\n🔑 পাসওয়ার্ড: ${user.password}\n💰 একাউন্ট ব্যালেন্স: ৳ ${user.balance.toLocaleString()}\n👑 ভিআইপি স্ট্যাটাস: ${user.activePackageId || 'কোনো প্যাকেজ নেই'}\n🎁 আপনার নিজস্ব রেফার কোড: ${user.referralCode}\n🔗 আপনার রেফারেল লিংক: ${refLink}\n🌐 লগইন করতে ভিজিট করুন: ${origin}`;
    navigator.clipboard.writeText(text);
    setCopiedUserId(user.id);
    setTimeout(() => setCopiedUserId(null), 2500);
    showNotification(`ইউজার ${user.phone} এর সম্পূর্ণ লগইন তথ্য কপি করা হয়েছে!`);
  };

  // Submit Admin User Creation (No referral code needed, auto referral code generated)
  const handleCreateUserSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError('');
    const cleanPhone = createPhone.trim();
    if (!cleanPhone) {
      setCreateError('মোবাইল নাম্বার বা ইউজার আইডি দিন!');
      return;
    }

    setIsCreatingUser(true);
    try {
      if (onCreateUser) {
        const res: any = await onCreateUser({
          phone: cleanPhone,
          password: createPassword.trim() || '123456',
          balance: Math.max(0, Number(createBalance) || 0),
          packageId: createPackageId || undefined,
        });
        if (res && res.success && res.user) {
          setCreatedUserSuccess(res.user);
          setCreateError('');
          showNotification(`ইউজার ${cleanPhone} সফলভাবে তৈরি করা হয়েছে!`);
        } else {
          const errMsg = res?.error || 'ইউজার তৈরি ব্যর্থ হয়েছে! পুনরায় চেষ্টা করুন।';
          setCreateError(errMsg);
          showNotification(errMsg);
        }
      } else {
        const newRefCode = 'EL' + Math.floor(100000 + Math.random() * 900000);
        const newUser: User = {
          id: `user_${Date.now()}`,
          phone: cleanPhone,
          password: createPassword.trim() || '123456',
          balance: Math.max(0, Number(createBalance) || 0),
          totalDeposit: Math.max(0, Number(createBalance) || 0),
          totalWithdraw: 0,
          totalEarned: 0,
          referralCode: newRefCode,
          referredBy: null, // Admin created: No referral code required!
          activePackageId: createPackageId || null,
          purchasedPackageIds: createPackageId ? [createPackageId] : [],
          packageActivatedAt: createPackageId ? new Date().toISOString() : null,
          bkashNagadNumber: null,
          withdrawPassword: null,
          paymentMethod: null,
          paymentDetailsSet: false,
          tasksCompletedToday: 0,
          lastTaskTimestamp: null,
          isBlocked: false,
          createdAt: new Date().toISOString(),
        };
        onUpdateUsers([newUser, ...users]);
        setCreatedUserSuccess(newUser);
        setCreateError('');
        showNotification(`ইউজার ${cleanPhone} সফলভাবে তৈরি করা হয়েছে!`);
      }
    } catch (err: any) {
      const errMsg = 'ইউজার তৈরি ব্যর্থ হয়েছে: ' + (err?.message || 'Error');
      setCreateError(errMsg);
      showNotification(errMsg);
    } finally {
      setIsCreatingUser(false);
    }
  };

  // Transaction Approval / Rejection
  const handleApproveTransaction = async (tx: Transaction) => {
    if (onUpdateTransactionStatus) {
      await onUpdateTransactionStatus(tx.id, 'approved');
      showNotification(`${tx.type === 'deposit' ? 'ডিপোজিট' : 'উইথড্র'} #${tx.id} সফলভাবে অনুমোদন (Approved) হয়েছে!`);
    } else {
      const updatedTxs = transactions.map((t) => (t.id === tx.id ? { ...t, status: 'approved' as const } : t));
      onUpdateTransactions(updatedTxs);
      if (tx.type === 'deposit') {
        const targetUser = users.find((u) => u.id === tx.userId);
        if (targetUser) {
          const updatedUsers = users.map((u) =>
            u.id === targetUser.id
              ? {
                  ...u,
                  balance: u.balance + tx.amount,
                  totalDeposit: u.totalDeposit + tx.amount,
                }
              : u
          );
          onUpdateUsers(updatedUsers);
        }
      }
      showNotification(`${tx.type.toUpperCase()} #${tx.id} Approved!`);
    }
  };

  const handleRejectTransaction = async (tx: Transaction) => {
    if (onUpdateTransactionStatus) {
      await onUpdateTransactionStatus(tx.id, 'rejected');
      showNotification(`${tx.type === 'deposit' ? 'ডিপোজিট' : 'উইথড্র'} #${tx.id} বাতিল (Rejected) করা হয়েছে!`);
    } else {
      const updatedTxs = transactions.map((t) => (t.id === tx.id ? { ...t, status: 'rejected' as const } : t));
      onUpdateTransactions(updatedTxs);
      if (tx.type === 'withdraw') {
        const targetUser = users.find((u) => u.id === tx.userId);
        if (targetUser) {
          const updatedUsers = users.map((u) =>
            u.id === targetUser.id ? { ...u, balance: u.balance + tx.amount } : u
          );
          onUpdateUsers(updatedUsers);
        }
      }
      showNotification(`${tx.type.toUpperCase()} #${tx.id} Rejected.`);
    }
  };

  // Submit Admin Balance Adjustment (Add or Deduct money from user)
  const handleBalanceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!balanceModalUser) return;
    const num = Number(balanceAmount);
    if (isNaN(num) || num <= 0) {
      showNotification('সঠিক টাকার পরিমাণ দিন');
      return;
    }

    setIsSubmittingBalance(true);
    try {
      if (onAdjustUserBalance) {
        await onAdjustUserBalance(balanceModalUser.id, balanceAction, num, balanceNote);
      } else {
        const updatedUsers = users.map((u) => {
          if (u.id === balanceModalUser.id) {
            const nextBal = balanceAction === 'add' ? u.balance + num : Math.max(0, u.balance - num);
            return {
              ...u,
              balance: nextBal,
              totalDeposit: balanceAction === 'add' ? u.totalDeposit + num : u.totalDeposit,
            };
          }
          return u;
        });
        onUpdateUsers(updatedUsers);
      }
      showNotification(
        balanceAction === 'add'
          ? `ইউজার ${balanceModalUser.phone} এর ব্যালেন্সে ৳${num.toLocaleString()} সফলভাবে যোগ করা হয়েছে!`
          : `ইউজার ${balanceModalUser.phone} এর ব্যালেন্স থেকে ৳${num.toLocaleString()} কেটে নেওয়া হয়েছে!`
      );
      setBalanceModalUser(null);
      setBalanceAmount('');
      setBalanceNote('');
    } catch (err: any) {
      showNotification('ব্যালেন্স আপডেট ব্যর্থ হয়েছে: ' + (err?.message || 'Error'));
    } finally {
      setIsSubmittingBalance(false);
    }
  };

  // Change Admin Password
  const handleChangeAdminPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminPassword.trim()) return;
    onUpdateAdminConfig({
      ...adminConfig,
      adminPassword: newAdminPassword.trim(),
    });
    setNewAdminPassword('');
    showNotification('Admin password updated successfully!');
  };

  // Send Support Reply
  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminReplyText.trim() || !selectedSupportUserId) return;
    onSendSupportReply(selectedSupportUserId, adminReplyText.trim());
    setAdminReplyText('');
    showNotification('Reply sent to user!');
  };

  // Pending requests count
  const pendingCount = transactions.filter((t) => t.status === 'pending').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-20">
      {/* Admin Top Bar */}
      <header className="sticky top-0 z-50 bg-slate-900 border-b border-slate-800 px-4 py-3">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-sm font-extrabold text-white tracking-wide">
                EARNLANCE BD • ADMIN CONSOLE
              </h1>
              <p className="text-[10px] text-amber-400 font-mono">
                Full System Administration
              </p>
            </div>
          </div>
          <button
            onClick={onExitAdmin}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 border border-slate-700 transition active:scale-95"
          >
            <LogOut className="w-3.5 h-3.5 text-rose-400" />
            <span>Exit Admin</span>
          </button>
        </div>
      </header>

      {/* Status Notification Toast */}
      {statusMsg && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs shadow-2xl animate-in slide-in-from-top duration-200">
          {statusMsg}
        </div>
      )}

      {/* Main Container with Left Sidebar in Serial */}
      <div className="flex flex-col md:flex-row min-h-[calc(100vh-61px)]">
        {/* Left Sidebar */}
        <aside className="w-full md:w-64 bg-slate-900 border-b md:border-b-0 md:border-r border-slate-800 p-3 md:p-4 shrink-0 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Admin Controls
              </span>
              <span className="text-[10px] font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded">
                সিরিয়াল তালিকা
              </span>
            </div>

            {/* Serial List of Admin Options on Left */}
            <nav className="flex md:flex-col gap-1.5 overflow-x-auto md:overflow-visible pb-1 md:pb-0">
              {[
                { id: 'requests', label: 'Requests', labelBn: 'রিকোয়েস্ট অনুমোদন', count: pendingCount, icon: CreditCard },
                { id: 'numbers', label: 'Payment Numbers', labelBn: 'পেমেন্ট নাম্বার', icon: Key },
                { id: 'packages', label: '10 VIP Plans', labelBn: 'ভিআইপি প্যাকেজ', icon: Crown },
                { id: 'banners', label: 'Banners', labelBn: 'ব্যানার স্লাইডার', icon: ImageIcon },
                { id: 'tasks', label: 'Video Ads', labelBn: 'বিজ্ঞাপন ভিডিও', icon: PlaySquare },
                { id: 'feed', label: 'Live Ticker', labelBn: 'লাইভ নোটিফিকেশন', icon: Activity },
                { id: 'users', label: 'Users & Block', labelBn: 'ইউজার ও ব্লক', count: users.length, icon: Users },
                { id: 'support', label: 'Support Chat', labelBn: 'লাইভ সাপোর্ট', icon: MessageSquare },
                { id: 'security', label: 'Admin Password', labelBn: 'এডমিন পাসওয়ার্ড', icon: Key },
              ].map((tab, idx) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;

                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as AdminTab)}
                    className={`relative shrink-0 md:w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left ${
                      isActive
                        ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                        : 'bg-slate-850 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className={`w-5 h-5 rounded-md flex items-center justify-center text-[10px] font-mono font-black ${
                          isActive
                            ? 'bg-slate-950 text-amber-400'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {idx + 1}
                      </span>
                      <Icon className="w-4 h-4 shrink-0" />
                      <div className="flex flex-col">
                        <span className="leading-tight">{tab.label}</span>
                        <span
                          className={`text-[10px] font-normal leading-tight ${
                            isActive ? 'text-slate-900 font-semibold' : 'text-slate-500'
                          }`}
                        >
                          {tab.labelBn}
                        </span>
                      </div>
                    </div>
                    {tab.count !== undefined && tab.count > 0 && (
                      <span
                        className={`ml-1.5 px-1.5 py-0.2 rounded-full text-[10px] font-mono font-bold ${
                          isActive
                            ? 'bg-slate-950 text-amber-400'
                            : 'bg-amber-500 text-slate-950'
                        }`}
                      >
                        {tab.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="hidden md:block pt-4 border-t border-slate-800/80 text-[10px] text-slate-500 font-mono">
            <span className="text-amber-400 font-bold block">EARNLANCE BD</span>
            <span>Admin Active Session</span>
          </div>
        </aside>

        {/* Right Content Area */}
        <main className="flex-1 p-4 md:p-6 overflow-y-auto max-w-5xl">
          {/* TAB 1: REQUESTS (DEPOSIT & WITHDRAW) */}
          {activeTab === 'requests' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                  Deposit & Withdrawal Requests
                </h2>
                <span className="text-xs text-amber-400 font-mono">
                  {pendingCount} Pending Approval
                </span>
              </div>

              {transactions.length === 0 ? (
                <div className="p-8 text-center text-slate-500 bg-slate-900 rounded-2xl border border-slate-800 text-xs">
                  No deposit or withdraw requests found.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {transactions.map((tx) => (
                    <div
                      key={tx.id}
                      className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              tx.type === 'deposit'
                                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            }`}
                          >
                            {tx.type} • {tx.method}
                          </span>
                          <span className="text-xs font-mono font-bold text-white">
                            ৳ {tx.amount.toLocaleString()}
                          </span>
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                              tx.status === 'approved'
                                ? 'bg-emerald-500/20 text-emerald-300'
                                : tx.status === 'pending'
                                ? 'bg-amber-500/20 text-amber-300 animate-pulse'
                                : 'bg-rose-500/20 text-rose-300'
                            }`}
                          >
                            {tx.status}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400 flex flex-wrap gap-x-3 gap-y-1 font-mono">
                          <span>User: {tx.userPhone}</span>
                          {tx.trxId && <span>TrxID: {tx.trxId}</span>}
                          {tx.accountNumber && <span>Account: {tx.accountNumber}</span>}
                          <span>{new Date(tx.createdAt).toLocaleString()}</span>
                        </div>
                      </div>

                      {tx.status === 'pending' && (
                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => handleApproveTransaction(tx)}
                            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition active:scale-95"
                          >
                            <CheckCircle className="w-3.5 h-3.5" />
                            <span>Approve</span>
                          </button>
                          <button
                            onClick={() => handleRejectTransaction(tx)}
                            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition active:scale-95"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: PAYMENT RECEIVING NUMBERS */}
          {activeTab === 'numbers' && (
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4">
              <div>
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                  Official Payment Receiving Numbers
                </h2>
                <p className="text-xs text-slate-400">
                  Change the official bKash & Nagad numbers that appear on user deposit modals.
                </p>
              </div>

              <form onSubmit={handleSavePaymentNumbers} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* bKash */}
                  <div className="p-4 rounded-xl bg-slate-850 border border-pink-500/30 space-y-3">
                    <span className="text-xs font-bold text-pink-400 uppercase">
                      bKash Payment Settings
                    </span>
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">
                        bKash Receiving Number
                      </label>
                      <input
                        type="text"
                        value={bkashNum}
                        onChange={(e) => setBkashNum(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm font-mono focus:border-amber-400 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">
                        Account Type / Instruction
                      </label>
                      <input
                        type="text"
                        value={bkashType}
                        onChange={(e) => setBkashType(e.target.value)}
                        placeholder="e.g. Send Money (Personal)"
                        className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:border-amber-400 outline-none"
                      />
                    </div>
                  </div>

                  {/* Nagad */}
                  <div className="p-4 rounded-xl bg-slate-850 border border-amber-500/30 space-y-3">
                    <span className="text-xs font-bold text-amber-400 uppercase">
                      Nagad Payment Settings
                    </span>
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">
                        Nagad Receiving Number
                      </label>
                      <input
                        type="text"
                        value={nagadNum}
                        onChange={(e) => setNagadNum(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm font-mono focus:border-amber-400 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">
                        Account Type / Instruction
                      </label>
                      <input
                        type="text"
                        value={nagadType}
                        onChange={(e) => setNagadType(e.target.value)}
                        placeholder="e.g. Send Money (Personal)"
                        className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:border-amber-400 outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Limits */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Minimum Deposit (৳)
                    </label>
                    <input
                      type="number"
                      value={minDeposit}
                      onChange={(e) => setMinDeposit(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white font-mono text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Minimum Withdrawal (৳)
                    </label>
                    <input
                      type="number"
                      value={minWithdraw}
                      onChange={(e) => setMinWithdraw(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white font-mono text-sm"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="py-2.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md flex items-center gap-2 active:scale-95 transition"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Payment Settings</span>
                </button>
              </form>
            </div>
          )}

          {/* TAB 3: 10 VIP PACKAGES */}
          {activeTab === 'packages' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                    Manage 10 VIP Packages
                  </h2>
                  <p className="text-xs text-slate-400">
                    Edit name, price, daily income, and validity for all VIP tiers.
                  </p>
                </div>
                <button
                  onClick={handleSavePackages}
                  className="py-2 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md flex items-center gap-1.5 transition active:scale-95"
                >
                  <Save className="w-4 h-4" />
                  <span>Save All Packages</span>
                </button>
              </div>

              <div className="space-y-3">
                {editingPackages.map((pkg, idx) => (
                  <div
                    key={pkg.id}
                    className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-amber-400">
                        Tier {pkg.tier} • {pkg.id}
                      </span>
                      <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
                        <input
                          type="checkbox"
                          checked={pkg.isActive}
                          onChange={(e) => {
                            const updated = [...editingPackages];
                            updated[idx].isActive = e.target.checked;
                            setEditingPackages(updated);
                          }}
                          className="w-4 h-4 rounded accent-emerald-500 cursor-pointer"
                        />
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${pkg.isActive ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                          {pkg.isActive ? 'চালু (Active)' : 'বন্ধ (Disabled - শীঘ্রই চালু হবে)'}
                        </span>
                      </label>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-0.5">
                          Name (EN)
                        </label>
                        <input
                          type="text"
                          value={pkg.name}
                          onChange={(e) => {
                            const updated = [...editingPackages];
                            updated[idx].name = e.target.value;
                            setEditingPackages(updated);
                          }}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-0.5">
                          Name (BN)
                        </label>
                        <input
                          type="text"
                          value={pkg.nameBn}
                          onChange={(e) => {
                            const updated = [...editingPackages];
                            updated[idx].nameBn = e.target.value;
                            setEditingPackages(updated);
                          }}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-0.5">
                          Price (৳)
                        </label>
                        <input
                          type="number"
                          value={pkg.price}
                          onChange={(e) => {
                            const updated = [...editingPackages];
                            updated[idx].price = Number(e.target.value);
                            setEditingPackages(updated);
                          }}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-0.5">
                          Daily Income (৳)
                        </label>
                        <input
                          type="number"
                          value={pkg.dailyIncome}
                          onChange={(e) => {
                            const updated = [...editingPackages];
                            updated[idx].dailyIncome = Number(e.target.value);
                            setEditingPackages(updated);
                          }}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-emerald-400 font-mono"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-0.5">
                          Validity (Days)
                        </label>
                        <input
                          type="number"
                          value={pkg.validityDays}
                          onChange={(e) => {
                            const updated = [...editingPackages];
                            updated[idx].validityDays = Number(e.target.value);
                            setEditingPackages(updated);
                          }}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-0.5">
                          Description
                        </label>
                        <input
                          type="text"
                          value={pkg.description}
                          onChange={(e) => {
                            const updated = [...editingPackages];
                            updated[idx].description = e.target.value;
                            setEditingPackages(updated);
                          }}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: BANNERS (ADD / DELETE / ON-OFF) */}
          {activeTab === 'banners' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                  Add New Banner (Slider)
                </h2>
                <form onSubmit={handleAddBanner} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    required
                    placeholder="Banner Title"
                    value={newBannerTitle}
                    onChange={(e) => setNewBannerTitle(e.target.value)}
                    className="px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                  />
                  <input
                    type="text"
                    placeholder="Subtitle / Tagline"
                    value={newBannerSubtitle}
                    onChange={(e) => setNewBannerSubtitle(e.target.value)}
                    className="px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                  />
                  <input
                    type="text"
                    placeholder="Image URL"
                    value={newBannerImg}
                    onChange={(e) => setNewBannerImg(e.target.value)}
                    className="px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white font-mono"
                  />
                  <input
                    type="text"
                    placeholder="Tag (e.g. VIP Special)"
                    value={newBannerTag}
                    onChange={(e) => setNewBannerTag(e.target.value)}
                    className="px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                  />
                  <div className="sm:col-span-2">
                    <button
                      type="submit"
                      className="py-2 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Banner to Slider</span>
                    </button>
                  </div>
                </form>
              </div>

              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-400 uppercase">
                  Active & Inactive Banners ({editingBanners.length})
                </h3>
                {editingBanners.map((banner) => (
                  <div
                    key={banner.id}
                    className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={banner.imageUrl}
                        alt={banner.title}
                        className="w-14 h-10 rounded-lg object-cover border border-slate-700 shrink-0"
                      />
                      <div>
                        <p className="font-bold text-white line-clamp-1">{banner.title}</p>
                        <p className="text-[10px] text-slate-400 line-clamp-1">{banner.subtitle}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleToggleBanner(banner.id)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold ${
                          banner.isActive
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}
                      >
                        {banner.isActive ? 'Active (ON)' : 'Disabled (OFF)'}
                      </button>
                      <button
                        onClick={() => handleDeleteBanner(banner.id)}
                        className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400 hover:bg-rose-500/30"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: ADS / VIDEOS */}
          {activeTab === 'tasks' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                  Add Sponsor Ad / Video Task
                </h2>
                <form onSubmit={handleAddTask} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    required
                    placeholder="Video Task Title"
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                    className="px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                  />
                  <input
                    type="text"
                    placeholder="Sponsor Brand"
                    value={newTaskSponsor}
                    onChange={(e) => setNewTaskSponsor(e.target.value)}
                    className="px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                  />
                  <input
                    type="number"
                    min={3}
                    max={60}
                    placeholder="Duration (Seconds)"
                    value={newTaskDuration}
                    onChange={(e) => setNewTaskDuration(Number(e.target.value))}
                    className="px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white font-mono"
                  />
                  <input
                    type="text"
                    placeholder="Thumbnail Image URL"
                    value={newTaskThumb}
                    onChange={(e) => setNewTaskThumb(e.target.value)}
                    className="px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white font-mono"
                  />
                  <div className="sm:col-span-2">
                    <button
                      type="submit"
                      className="py-2 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Video Task</span>
                    </button>
                  </div>
                </form>
              </div>

              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-400 uppercase">
                  Video Tasks ({editingTasks.length})
                </h3>
                {editingTasks.map((task) => (
                  <div
                    key={task.id}
                    className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={task.thumbnail}
                        alt={task.title}
                        className="w-12 h-10 rounded-lg object-cover border border-slate-700 shrink-0"
                      />
                      <div>
                        <p className="font-bold text-white line-clamp-1">{task.title}</p>
                        <p className="text-[10px] text-slate-400">
                          {task.sponsor} • {task.durationSeconds}s
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleToggleTask(task.id)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold ${
                          task.isActive
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}
                      >
                        {task.isActive ? 'Active (ON)' : 'Disabled (OFF)'}
                      </button>
                      <button
                        onClick={() => handleDeleteTask(task.id)}
                        className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400 hover:bg-rose-500/30"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: LIVE TICKER / FEED DATA */}
          {activeTab === 'feed' && (
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                    Live Activity Feed Ticker
                  </h2>
                  <p className="text-xs text-amber-400 font-medium">
                    (Automatic): যেমন "Karim 1,200 TK Withdraw" ইত্যাদি
                  </p>
                </div>
                <button
                  onClick={handleToggleFeed}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    feedActive
                      ? 'bg-emerald-500 text-slate-950 shadow'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  Ticker Status: {feedActive ? 'ON' : 'OFF'}
                </button>
              </div>

              <form onSubmit={handleAddFeedItem} className="flex gap-2">
                <input
                  type="text"
                  required
                  placeholder='e.g. "Rahim 500 TK Deposit" or "Karim 1,200 TK Withdraw"'
                  value={newFeedText}
                  onChange={(e) => setNewFeedText(e.target.value)}
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
                />
                <button
                  type="submit"
                  className="py-2 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shrink-0"
                >
                  Add Info
                </button>
              </form>

              <div className="space-y-1.5 pt-2">
                <h3 className="text-xs font-bold text-slate-400 uppercase">Current Ticker Entries</h3>
                {feedItems.map((item, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-800/80 border border-slate-700/60 text-xs text-slate-200"
                  >
                    <span className="font-mono">{item}</span>
                    <button
                      onClick={() => handleDeleteFeedItem(index)}
                      className="text-rose-400 hover:text-rose-300 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 7: USERS MANAGEMENT & BLOCK/UNBLOCK */}
          {activeTab === 'users' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    <span>Users Management & Control</span>
                    <span className="px-2 py-0.5 rounded-full bg-slate-800 text-[11px] text-amber-400 font-mono">
                      {users.length} Users
                    </span>
                  </h2>
                  <p className="text-xs text-slate-400">
                    ইউজার আইডি তৈরি করুন, ব্যালেন্স যোগ/কাটা করুন, এবং যেকোনো অ্যাকাউন্ট নিয়ন্ত্রণ করুন।
                  </p>
                </div>

                {/* Top Action & Search */}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => {
                      setShowCreateUserModal(true);
                      setCreatePhone('');
                      setCreatePassword('123456');
                      setCreateBalance('0');
                      setCreatePackageId('');
                      setCreatedUserSuccess(null);
                      setCopiedSuccess(false);
                      setCreateError('');
                    }}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold text-xs shadow-lg shadow-emerald-500/20 active:scale-95 transition"
                  >
                    <UserPlus className="w-4 h-4 text-slate-950" />
                    <span>+ নতুন ইউজার তৈরি করুন</span>
                  </button>

                  {/* Search Bar */}
                  <div className="relative w-full sm:w-56">
                    <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Search phone or ID..."
                      value={userSearch}
                      onChange={(e) => setUserSearch(e.target.value)}
                      className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none focus:border-amber-400 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Status Filter Buttons */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setUserStatusFilter('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    userStatusFilter === 'all'
                      ? 'bg-amber-500 text-slate-950 shadow'
                      : 'bg-slate-850 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  All ({users.length})
                </button>
                <button
                  onClick={() => setUserStatusFilter('active')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                    userStatusFilter === 'active'
                      ? 'bg-emerald-500 text-slate-950 shadow'
                      : 'bg-slate-850 text-emerald-400 hover:text-emerald-300 border border-slate-800'
                  }`}
                >
                  <CheckCircle className="w-3 h-3" />
                  <span>Active ({users.filter((u) => !u.isBlocked).length})</span>
                </button>
                <button
                  onClick={() => setUserStatusFilter('blocked')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                    userStatusFilter === 'blocked'
                      ? 'bg-rose-500 text-white shadow'
                      : 'bg-slate-850 text-rose-400 hover:text-rose-300 border border-slate-800'
                  }`}
                >
                  <Ban className="w-3 h-3" />
                  <span>Blocked ({users.filter((u) => u.isBlocked).length})</span>
                </button>
              </div>

              {/* Users List */}
              <div className="space-y-2.5">
                {users
                  .filter((u) => {
                    const q = userSearch.toLowerCase();
                    const matchPhone = u.phone.toLowerCase().includes(q) || u.id.toLowerCase().includes(q) || (u.referralCode && u.referralCode.toLowerCase().includes(q));
                    if (!matchPhone) return false;
                    if (userStatusFilter === 'active') return !u.isBlocked;
                    if (userStatusFilter === 'blocked') return Boolean(u.isBlocked);
                    return true;
                  })
                  .map((user) => (
                    <div
                      key={user.id}
                      className={`p-3.5 rounded-2xl border transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-3 shadow-md ${
                        user.isBlocked
                          ? 'bg-rose-950/20 border-rose-500/40'
                          : 'bg-slate-900 border-slate-800'
                      }`}
                    >
                      <div className="space-y-1.5">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-mono text-sm font-bold text-white">
                            {user.phone}
                          </span>
                          {/* Block/Active Status Badge */}
                          {user.isBlocked ? (
                            <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center gap-1">
                              <Ban className="w-3 h-3" />
                              <span>BLOCKED / ব্লকড</span>
                            </span>
                          ) : (
                            <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                              <CheckCircle className="w-3 h-3" />
                              <span>ACTIVE / সক্রিয়</span>
                            </span>
                          )}
                          <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 font-mono">
                            Pass: <strong className="text-amber-400">{user.password}</strong>
                          </span>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-mono">
                            Code: {user.referralCode} ({users.filter((u) => u.referredBy === user.referralCode).length} Refs)
                          </span>
                          {user.referredBy ? (
                            <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono">
                              By: {user.referredBy}
                            </span>
                          ) : (
                            <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 font-mono border border-amber-500/20">
                              Admin Created
                            </span>
                          )}
                          {user.activePackageId && (
                            <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">
                              Active: {user.activePackageId}
                            </span>
                          )}
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-0.5 text-[11px] text-slate-400 font-mono">
                          <span>Balance: ৳ {user.balance.toLocaleString()}</span>
                          <span>Deposit: ৳ {user.totalDeposit.toLocaleString()}</span>
                          <span>Withdraw: ৳ {user.totalWithdraw.toLocaleString()}</span>
                          <span>Wallet: {user.bkashNagadNumber || 'None'}</span>
                        </div>
                      </div>

                      {/* Action buttons: Copy credentials, Block/Unblock, Balance & Edit */}
                      <div className="flex flex-wrap items-center gap-2 shrink-0 self-start lg:self-center">
                        <button
                          onClick={() => handleCopyCredentials(user)}
                          className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl font-bold text-xs transition active:scale-95 shadow border ${
                            copiedUserId === user.id
                              ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                              : 'bg-indigo-600/90 hover:bg-indigo-500 text-white border-indigo-500/40'
                          }`}
                          title="লগইন তথ্য ও লিঙ্ক কপি করে ইউজারকে দিন"
                        >
                          {copiedUserId === user.id ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>কপি হয়েছে!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>তথ্য কপি</span>
                            </>
                          )}
                        </button>

                        {user.isBlocked ? (
                          <button
                            onClick={() => handleToggleBlockUser(user)}
                            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition active:scale-95 shadow"
                            title="Unblock User"
                          >
                            <Unlock className="w-3.5 h-3.5" />
                            <span>Unblock</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => handleToggleBlockUser(user)}
                            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-rose-600/90 hover:bg-rose-500 text-white font-bold text-xs transition active:scale-95 shadow"
                            title="Block User"
                          >
                            <Ban className="w-3.5 h-3.5" />
                            <span>Block</span>
                          </button>
                        )}
                        <button
                          onClick={() => {
                            setBalanceModalUser(user);
                            setBalanceAction('add');
                            setBalanceAmount('');
                            setBalanceNote('');
                          }}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs transition active:scale-95 shadow"
                          title="টাকা যোগ বা কেটে নিন"
                        >
                          <Coins className="w-3.5 h-3.5" />
                          <span>ব্যালেন্স (±৳)</span>
                        </button>
                        <button
                          onClick={() => setEditingUser({ ...user })}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold text-xs border border-slate-700 transition"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>
                        <button
                          onClick={() => handleDeleteUserDirect(user.id, user.phone)}
                          className="p-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/25 text-rose-400 border border-rose-500/20 transition active:scale-95"
                          title="Delete User (Admin Only)"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
              </div>

              {/* User Edit Modal */}
              {editingUser && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
                  <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                      <h3 className="text-sm font-bold text-white flex items-center gap-2">
                        <span>Edit User: {editingUser.phone}</span>
                        {editingUser.isBlocked && (
                          <span className="text-[10px] px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 font-bold">
                            Blocked
                          </span>
                        )}
                      </h3>
                      <button
                        onClick={() => setEditingUser(null)}
                        className="text-slate-400 hover:text-white"
                      >
                        ✕
                      </button>
                    </div>

                    <form onSubmit={handleSaveUserEdit} className="space-y-3">
                      {/* Block / Unblock Checkbox Option */}
                      <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700">
                        <label className="flex items-center justify-between cursor-pointer">
                          <div className="flex items-center gap-2">
                            <Ban className={`w-4 h-4 ${editingUser.isBlocked ? 'text-rose-400' : 'text-slate-400'}`} />
                            <div>
                              <span className="text-xs font-bold text-white block">
                                Block User (ব্লক করুন)
                              </span>
                              <span className="text-[10px] text-slate-400">
                                {editingUser.isBlocked
                                  ? 'Account is currently blocked from login'
                                  : 'Account has active login access'}
                              </span>
                            </div>
                          </div>
                          <input
                            type="checkbox"
                            checked={Boolean(editingUser.isBlocked)}
                            onChange={(e) =>
                              setEditingUser({
                                ...editingUser,
                                isBlocked: e.target.checked,
                              })
                            }
                            className="w-5 h-5 rounded accent-rose-500 cursor-pointer"
                          />
                        </label>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">
                          Phone Number
                        </label>
                        <input
                          type="tel"
                          value={editingUser.phone}
                          onChange={(e) =>
                            setEditingUser({ ...editingUser, phone: e.target.value })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">
                          Login Password
                        </label>
                        <input
                          type="text"
                          value={editingUser.password}
                          onChange={(e) =>
                            setEditingUser({ ...editingUser, password: e.target.value })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">
                          Withdraw Password (Set by user on first login)
                        </label>
                        <input
                          type="text"
                          value={editingUser.withdrawPassword || ''}
                          onChange={(e) =>
                            setEditingUser({
                              ...editingUser,
                              withdrawPassword: e.target.value,
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">
                          Locked bKash / Nagad Number
                        </label>
                        <input
                          type="tel"
                          value={editingUser.bkashNagadNumber || ''}
                          onChange={(e) =>
                            setEditingUser({
                              ...editingUser,
                              bkashNagadNumber: e.target.value,
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-xs font-semibold text-slate-300 mb-1">
                            Current Balance (৳)
                          </label>
                          <input
                            type="number"
                            value={editingUser.balance}
                            onChange={(e) =>
                              setEditingUser({
                                ...editingUser,
                                balance: Number(e.target.value),
                              })
                            }
                            className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-amber-400 font-mono text-xs font-bold"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-300 mb-1">
                            Payment Method
                          </label>
                          <select
                            value={editingUser.paymentMethod || 'bKash'}
                            onChange={(e) =>
                              setEditingUser({
                                ...editingUser,
                                paymentMethod: e.target.value as 'bKash' | 'Nagad',
                              })
                            }
                            className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                          >
                            <option value="bKash">bKash</option>
                            <option value="Nagad">Nagad</option>
                          </select>
                        </div>
                      </div>

                      <div className="pt-2 flex flex-col gap-2">
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => setEditingUser(null)}
                            className="w-1/2 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            className="w-1/2 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow"
                          >
                            Save Changes
                          </button>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleDeleteUserDirect(editingUser.id, editingUser.phone)}
                          className="w-full py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 border border-rose-500/30 text-xs font-bold flex items-center justify-center gap-1.5 transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete User Permanently (মুছে ফেলুন)</span>
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}

              {/* User Balance Adjustment Modal (Add or Deduct money) */}
              {balanceModalUser && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 animate-in fade-in duration-150">
                  <div className="w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-2xl p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
                    {/* Header */}
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                      <div>
                        <h3 className="text-sm font-bold text-white flex items-center gap-2">
                          <Coins className="w-4 h-4 text-amber-400" />
                          <span>ইউজার ব্যালেন্স নিয়ন্ত্রণ (টাকা যোগ বা কর্তন)</span>
                        </h3>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          ইউজার:{' '}
                          <span className="font-mono text-amber-400 font-bold">
                            {balanceModalUser.phone}
                          </span>
                        </p>
                      </div>
                      <button
                        onClick={() => setBalanceModalUser(null)}
                        className="text-slate-400 hover:text-white text-lg p-1"
                      >
                        ✕
                      </button>
                    </div>

                    {/* Current Balance Card */}
                    <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 flex items-center justify-between">
                      <span className="text-xs text-slate-300">বর্তমান ব্যালেন্স:</span>
                      <span className="text-sm font-mono font-black text-amber-400">
                        ৳ {balanceModalUser.balance.toLocaleString()}
                      </span>
                    </div>

                    {/* Toggle Segment: Add or Deduct */}
                    <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-slate-800 border border-slate-700">
                      <button
                        type="button"
                        onClick={() => setBalanceAction('add')}
                        className={`py-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                          balanceAction === 'add'
                            ? 'bg-emerald-600 text-white shadow-md'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>টাকা যোগ করুন (+ Add)</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setBalanceAction('deduct')}
                        className={`py-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                          balanceAction === 'deduct'
                            ? 'bg-rose-600 text-white shadow-md'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <Minus className="w-3.5 h-3.5" />
                        <span>টাকা কেটে নিন (- Deduct)</span>
                      </button>
                    </div>

                    <form onSubmit={handleBalanceSubmit} className="space-y-3.5">
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">
                          {balanceAction === 'add'
                            ? 'কত টাকা যোগ করবেন? (৳)'
                            : 'কত টাকা কেটে নিবেন? (৳)'}
                        </label>
                        <div className="relative">
                          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">
                            ৳
                          </span>
                          <input
                            type="number"
                            required
                            min={1}
                            step="any"
                            placeholder="0.00"
                            value={balanceAmount}
                            onChange={(e) => setBalanceAmount(e.target.value)}
                            className="w-full pl-8 pr-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono text-sm font-bold focus:border-amber-400 outline-none"
                          />
                        </div>
                      </div>

                      {/* Quick presets */}
                      <div className="flex flex-wrap gap-1.5">
                        {[100, 500, 1000, 2000, 5000].map((preset) => (
                          <button
                            key={preset}
                            type="button"
                            onClick={() => setBalanceAmount(String(preset))}
                            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-mono border border-slate-700/80 active:scale-95 transition"
                          >
                            {balanceAction === 'add' ? `+৳${preset}` : `-৳${preset}`}
                          </button>
                        ))}
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">
                          কারণ বা বিবরণ (ঐচ্ছিক):
                        </label>
                        <input
                          type="text"
                          placeholder={
                            balanceAction === 'add'
                              ? 'যেমন: বোনাস / ডিপোজিট সমন্বয় / রিওয়ার্ড'
                              : 'যেমন: জরিমানা / ভুল ব্যালেন্স সংশোধন'
                          }
                          value={balanceNote}
                          onChange={(e) => setBalanceNote(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:border-amber-400 outline-none"
                        />
                      </div>

                      {/* Projected Balance preview */}
                      {Number(balanceAmount) > 0 && (
                        <div
                          className={`p-2.5 rounded-xl border text-xs flex items-center justify-between font-mono ${
                            balanceAction === 'add'
                              ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
                              : 'bg-rose-950/30 border-rose-500/40 text-rose-300'
                          }`}
                        >
                          <span>নতুন ব্যালেন্স হবে:</span>
                          <span className="font-bold text-sm">
                            ৳{' '}
                            {balanceAction === 'add'
                              ? (
                                  balanceModalUser.balance + Number(balanceAmount)
                                ).toLocaleString()
                              : Math.max(
                                  0,
                                  balanceModalUser.balance - Number(balanceAmount)
                                ).toLocaleString()}
                          </span>
                        </div>
                      )}

                      <div className="pt-2 flex gap-2">
                        <button
                          type="button"
                          onClick={() => setBalanceModalUser(null)}
                          className="w-1/3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
                        >
                          বাতিল
                        </button>
                        <button
                          type="submit"
                          disabled={isSubmittingBalance || !Number(balanceAmount)}
                          className={`w-2/3 py-2.5 rounded-xl text-white font-bold text-xs shadow-lg transition active:scale-95 disabled:opacity-50 flex items-center justify-center gap-1.5 ${
                            balanceAction === 'add'
                              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-emerald-900/30'
                              : 'bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 shadow-rose-900/30'
                          }`}
                        >
                          {balanceAction === 'add' ? (
                            <>
                              <Plus className="w-4 h-4" />
                              <span>টাকা যোগ নিশ্চিত করুন</span>
                            </>
                          ) : (
                            <>
                              <Minus className="w-4 h-4" />
                              <span>টাকা কর্তন নিশ্চিত করুন</span>
                            </>
                          )}
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}

              {/* Admin Create User Modal (No referral code required; auto-generates referral code) */}
              {showCreateUserModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 animate-in fade-in duration-150">
                  <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl p-5 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
                    {/* Header */}
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          <UserPlus className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                            <span>নতুন ইউজার আইডি তৈরি করুন</span>
                            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                              Admin
                            </span>
                          </h3>
                          <p className="text-[11px] text-slate-400">
                            কোনো রেফার কোড লাগবে না • স্বয়ংক্রিয় রেফারেল কোড তৈরি হবে
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          setShowCreateUserModal(false);
                          setCreatedUserSuccess(null);
                        }}
                        className="text-slate-400 hover:text-white text-lg p-1"
                      >
                        ✕
                      </button>
                    </div>

                    {/* Success Screen if user was created */}
                    {createdUserSuccess ? (
                      <div className="space-y-4 py-2">
                        <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-center space-y-2">
                          <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 mx-auto flex items-center justify-center">
                            <CheckCircle className="w-7 h-7" />
                          </div>
                          <h4 className="text-base font-extrabold text-emerald-300">
                            অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে!
                          </h4>
                          <p className="text-xs text-slate-300 max-w-sm mx-auto leading-relaxed">
                            এই আইডি ও পাসওয়ার্ড দিয়ে ব্যবহারকারী সরাসরি অ্যাপে লগইন করতে পারবেন। নিচে থেকে তথ্যগুলো কপি করে ইউজারকে পাঠিয়ে দিন।
                          </p>
                        </div>

                        {/* Credential summary */}
                        <div className="p-4 rounded-xl bg-slate-800/90 border border-slate-700/80 space-y-2.5 font-mono text-xs">
                          <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                            <span className="text-slate-400">📱 লগইন আইডি / ফোন:</span>
                            <span className="font-bold text-white text-sm bg-slate-900 px-2 py-1 rounded">
                              {createdUserSuccess.phone}
                            </span>
                          </div>
                          <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                            <span className="text-slate-400">🔑 পাসওয়ার্ড:</span>
                            <span className="font-bold text-amber-400 text-sm bg-slate-900 px-2 py-1 rounded">
                              {createdUserSuccess.password}
                            </span>
                          </div>
                          <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                            <span className="text-slate-400">💰 প্রারম্ভিক ব্যালেন্স:</span>
                            <span className="font-bold text-emerald-400 text-sm">
                              ৳ {createdUserSuccess.balance.toLocaleString()}
                            </span>
                          </div>
                          <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                            <span className="text-slate-400">👑 প্যাকেজ স্ট্যাটাস:</span>
                            <span className="font-bold text-amber-300">
                              {createdUserSuccess.activePackageId || 'কোনো ভিআইপি নেই (Free)'}
                            </span>
                          </div>
                          <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                            <span className="text-slate-400">🎁 স্বয়ংক্রিয় রেফার কোড:</span>
                            <span className="font-bold text-blue-400 text-sm bg-blue-950/60 px-2 py-0.5 rounded border border-blue-500/30">
                              {createdUserSuccess.referralCode}
                            </span>
                          </div>
                          <div className="flex flex-col gap-1 pt-1">
                            <span className="text-slate-400">🔗 রেফারেল লিংক:</span>
                            <span className="text-[11px] text-slate-300 bg-slate-900 p-2 rounded break-all border border-slate-700">
                              {`${window.location.origin}/?ref=${createdUserSuccess.referralCode}`}
                            </span>
                          </div>
                        </div>

                        {/* Informative Note */}
                        <div className="p-3 rounded-xl bg-blue-950/30 border border-blue-500/30 text-blue-300 text-xs flex items-start gap-2">
                          <Sparkles className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
                          <p className="leading-relaxed">
                            <strong>রেফারেল নিয়ম:</strong> এই আইডি তৈরিতে কোনো রেফার কোড লাগেনি। কিন্তু এই ইউজার যখন অন্য কাউকে আমন্ত্রণ জানাবে, তখন তার এই কোডটি <strong>({createdUserSuccess.referralCode})</strong> স্বয়ংক্রিয়ভাবে ব্যবহৃত হবে।
                          </p>
                        </div>

                        {/* Copy Button */}
                        <button
                          onClick={() => {
                            const origin = window.location.origin;
                            const refLink = `${origin}/?ref=${createdUserSuccess.referralCode}`;
                            const text = `🎉 আপনার Earnlance BD একাউন্ট তৈরি সম্পন্ন হয়েছে!\n📱 লগইন আইডি / ফোন: ${createdUserSuccess.phone}\n🔑 পাসওয়ার্ড: ${createdUserSuccess.password}\n💰 একাউন্ট ব্যালেন্স: ৳ ${createdUserSuccess.balance.toLocaleString()}\n👑 ভিআইপি স্ট্যাটাস: ${createdUserSuccess.activePackageId || 'কোনো প্যাকেজ নেই'}\n🎁 আপনার নিজস্ব রেফার কোড: ${createdUserSuccess.referralCode}\n🔗 আপনার রেফারেল লিংক: ${refLink}\n🌐 লগইন করতে ভিজিট করুন: ${origin}`;
                            navigator.clipboard.writeText(text);
                            setCopiedSuccess(true);
                            showNotification('সম্পূর্ণ লগইন তথ্য কপি করা হয়েছে!');
                            setTimeout(() => setCopiedSuccess(false), 2500);
                          }}
                          className={`w-full py-3 rounded-xl font-extrabold text-sm shadow-xl transition flex items-center justify-center gap-2 ${
                            copiedSuccess
                              ? 'bg-emerald-500 text-slate-950'
                              : 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950'
                          }`}
                        >
                          {copiedSuccess ? (
                            <>
                              <Check className="w-4 h-4" />
                              <span>লগইন তথ্য সফলভাবে কপি হয়েছে!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-4 h-4" />
                              <span>📋 সব তথ্য ও লগইন লিঙ্ক কপি করুন</span>
                            </>
                          )}
                        </button>

                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setCreatedUserSuccess(null);
                              setCreatePhone('');
                              setCreatePassword('123456');
                              setCreateBalance('0');
                              setCreatePackageId('');
                            }}
                            className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition"
                          >
                            + আরেকটি ইউজার তৈরি করুন
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setShowCreateUserModal(false);
                              setCreatedUserSuccess(null);
                            }}
                            className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 font-bold text-xs transition"
                          >
                            বন্ধ করুন
                          </button>
                        </div>
                      </div>
                    ) : (
                      /* Creation Form */
                      <form onSubmit={handleCreateUserSubmit} className="space-y-3.5">
                        {/* Notice */}
                        <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-300 text-xs flex items-start gap-2">
                          <Sparkles className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
                          <p className="leading-relaxed">
                            <strong>অ্যাডমিন সুবিধা:</strong> এখানে অ্যাকাউন্ট করতে <strong>কোনো রেফার কোড লাগবে না</strong>। অ্যাকাউন্ট খোলার সাথে সাথেই ইউজারের জন্য নিজস্ব রেফার কোড স্বয়ংক্রিয় তৈরি হবে।
                          </p>
                        </div>

                        {/* Error Callout */}
                        {createError && (
                          <div className="p-3 rounded-xl bg-rose-950/70 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2 animate-in fade-in">
                            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                            <span className="font-semibold">{createError}</span>
                          </div>
                        )}

                        {/* Phone / User ID */}
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="text-xs font-semibold text-slate-300">
                              মোবাইল নাম্বার বা লগইন আইডি *
                            </label>
                            <button
                              type="button"
                              onClick={handleGeneratePhone}
                              className="text-[11px] text-amber-400 hover:underline font-bold"
                            >
                              ⚡ অটো নাম্বার জেনারেট
                            </button>
                          </div>
                          <input
                            type="text"
                            required
                            placeholder="যেমন: 017XXXXXXXX বা USER101"
                            value={createPhone}
                            onChange={(e) => setCreatePhone(e.target.value)}
                            className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono focus:border-emerald-400 outline-none"
                          />
                        </div>

                        {/* Password */}
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="text-xs font-semibold text-slate-300">
                              লগইন পাসওয়ার্ড *
                            </label>
                            <button
                              type="button"
                              onClick={handleGeneratePassword}
                              className="text-[11px] text-amber-400 hover:underline font-bold"
                            >
                              ⚡ র্যান্ডম পিন
                            </button>
                          </div>
                          <input
                            type="text"
                            required
                            placeholder="পাসওয়ার্ড দিন"
                            value={createPassword}
                            onChange={(e) => setCreatePassword(e.target.value)}
                            className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono focus:border-emerald-400 outline-none"
                          />
                        </div>

                        {/* Initial Balance */}
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="text-xs font-semibold text-slate-300">
                              প্রারম্ভিক ব্যালেন্স (৳) [ঐচ্ছিক]
                            </label>
                            <div className="flex gap-1">
                              {['0', '50', '100', '500', '1000'].map((amt) => (
                                <button
                                  key={amt}
                                  type="button"
                                  onClick={() => setCreateBalance(amt)}
                                  className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 hover:border-amber-400 text-slate-300 font-mono"
                                >
                                  +{amt}
                                </button>
                              ))}
                            </div>
                          </div>
                          <input
                            type="number"
                            min="0"
                            placeholder="0"
                            value={createBalance}
                            onChange={(e) => setCreateBalance(e.target.value)}
                            className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono focus:border-emerald-400 outline-none"
                          />
                        </div>

                        {/* Initial VIP Package */}
                        <div>
                          <label className="block text-xs font-semibold text-slate-300 mb-1">
                            ভিআইপি প্যাকেজ যুক্ত করুন (ঐচ্ছিক)
                          </label>
                          <select
                            value={createPackageId}
                            onChange={(e) => setCreatePackageId(e.target.value)}
                            className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:border-emerald-400 outline-none"
                          >
                            <option value="">কোনো প্যাকেজ নেই (ফ্রি মেম্বার)</option>
                            {packages.map((pkg) => (
                              <option key={pkg.id} value={pkg.id}>
                                {pkg.name} - ৳{pkg.price.toLocaleString()} (দৈনিক আয়: ৳{pkg.dailyIncome.toLocaleString()})
                              </option>
                            ))}
                          </select>
                        </div>

                        {/* Submit Button */}
                        <div className="pt-2 flex gap-2">
                          <button
                            type="button"
                            onClick={() => setShowCreateUserModal(false)}
                            className="w-1/3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
                          >
                            বাতিল
                          </button>
                          <button
                            type="submit"
                            disabled={isCreatingUser || !createPhone.trim()}
                            className="w-2/3 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold text-xs shadow-lg shadow-emerald-500/20 active:scale-95 transition disabled:opacity-50 flex items-center justify-center gap-2"
                          >
                            <UserPlus className="w-4 h-4" />
                            <span>{isCreatingUser ? 'তৈরি হচ্ছে...' : 'ইউজার আইডি তৈরি করুন'}</span>
                          </button>
                        </div>
                      </form>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 8: IN-APP SUPPORT INBOX (RULE 11: Direct in-app messaging) */}
          {activeTab === 'support' && (
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 space-y-4">
              <div>
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                  In-App Live Support Inbox
                </h2>
                <p className="text-xs text-slate-400">
                  Rule 11: No Telegram / WhatsApp. Users send messages here and Admin replies directly.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 h-[450px]">
                {/* User Selector List */}
                <div className="bg-slate-850 rounded-xl border border-slate-800 overflow-y-auto p-2 space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase px-2 block mb-1">
                    Active Conversations
                  </span>
                  {users.map((u) => {
                    const msgs = supportMessages.filter((m) => m.userId === u.id);
                    const isSelected = selectedSupportUserId === u.id;
                    return (
                      <button
                        key={u.id}
                        onClick={() => setSelectedSupportUserId(u.id)}
                        className={`w-full text-left p-2 rounded-lg text-xs transition flex items-center justify-between ${
                          isSelected
                            ? 'bg-blue-600 text-white font-bold'
                            : 'text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <div>
                          <p className="font-mono">{u.phone}</p>
                          <p className="text-[10px] opacity-75">{msgs.length} messages</p>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Chat Thread */}
                <div className="md:col-span-2 bg-slate-950/60 rounded-xl border border-slate-800 flex flex-col overflow-hidden">
                  <div className="p-2.5 bg-slate-850 border-b border-slate-800 text-xs font-bold text-white font-mono">
                    Chat with User: {users.find((u) => u.id === selectedSupportUserId)?.phone || 'Select a user'}
                  </div>

                  <div className="flex-1 p-3 overflow-y-auto space-y-2">
                    {supportMessages
                      .filter((m) => m.userId === selectedSupportUserId)
                      .map((msg) => (
                        <div
                          key={msg.id}
                          className={`flex flex-col ${
                            msg.sender === 'admin' ? 'items-end' : 'items-start'
                          }`}
                        >
                          <span className="text-[9px] text-slate-400 mb-0.5">
                            {msg.sender === 'admin' ? 'You (Admin)' : 'User'} •{' '}
                            {new Date(msg.createdAt).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                          <div
                            className={`max-w-[80%] rounded-xl px-3 py-1.5 text-xs ${
                              msg.sender === 'admin'
                                ? 'bg-amber-500 text-slate-950 font-medium'
                                : 'bg-slate-800 border border-slate-700 text-white'
                            }`}
                          >
                            {msg.text}
                          </div>
                        </div>
                      ))}
                  </div>

                  <form onSubmit={handleSendReply} className="p-2 bg-slate-900 border-t border-slate-800 flex gap-2">
                    <input
                      type="text"
                      value={adminReplyText}
                      onChange={(e) => setAdminReplyText(e.target.value)}
                      placeholder="Type official admin reply..."
                      className="flex-1 px-3 py-1.5 text-xs rounded-lg bg-slate-800 border border-slate-700 text-white outline-none focus:border-amber-400"
                    />
                    <button
                      type="submit"
                      disabled={!adminReplyText.trim()}
                      className="py-1.5 px-3 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-xs font-bold"
                    >
                      Send
                    </button>
                  </form>
                </div>
              </div>
            </div>
          )}

          {/* TAB 9: ADMIN SECURITY (CHANGE PASSWORD) */}
          {activeTab === 'security' && (
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4 max-w-md">
              <div>
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                  Change Admin Secret Password
                </h2>
                <p className="text-xs text-slate-400">
                  Update the secret password required after 5 clicks on the logo.
                </p>
              </div>

              <form onSubmit={handleChangeAdminPassword} className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    New Admin Secret Password
                  </label>
                  <input
                    type="text"
                    required
                    value={newAdminPassword}
                    onChange={(e) => setNewAdminPassword(e.target.value)}
                    placeholder="Enter new admin password"
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
                  />
                </div>
                <button
                  type="submit"
                  className="py-2.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow flex items-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  <span>Save New Password</span>
                </button>
              </form>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
