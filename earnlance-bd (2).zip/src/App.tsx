import React, { useState, useEffect, useCallback } from 'react';
import {
  initStorage,
  getAllUsers,
  saveUsers,
  getCurrentUser,
  setCurrentUserId,
  getPackages,
  savePackages,
  getBanners,
  saveBanners,
  getAdTasks,
  saveAdTasks,
  getTransactions,
  saveTransactions,
  getAdminConfig,
  saveAdminConfig,
  getSupportMessages,
  saveSupportMessages,
  getLanguage,
  saveLanguage,
  getFeedItems,
  saveFeedItems,
  addDeletedUser,
  removeDeletedUser,
  isUserDeleted,
  saveDeletedUsers,
} from './storage';
import {
  fetchServerState,
  apiUpdateUser,
  apiToggleBlockUser,
  apiDeleteUser,
  apiAdminCreateUser,
  apiPurchasePackage,
  apiCompleteTask,
  apiSubmitDeposit,
  apiSubmitWithdraw,
  apiUpdateTransactionStatus,
  apiAdjustUserBalance,
  apiUpdateAdminUsers,
  apiUpdateAdminConfig,
  apiUpdatePackages,
  apiUpdateBanners,
  apiUpdateTasks,
  apiSendSupportMessage,
} from './api';
import {
  User,
  VipPackage,
  Banner,
  AdTask,
  Transaction,
  AdminConfig,
  SupportMessage,
  Language,
  BottomTab,
} from './types';
import { translations } from './translations';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { AuthScreen } from './components/AuthScreen';
import { SecretAdminEntryModal } from './components/SecretAdminEntryModal';
import { FirstTimeSetupModal } from './components/FirstTimeSetupModal';
import { DepositModal } from './components/DepositModal';
import { WithdrawModal } from './components/WithdrawModal';
import { SupportModal } from './components/SupportModal';
import { HomePage } from './pages/HomePage';
import { VipPage } from './pages/VipPage';
import { TaskPage } from './pages/TaskPage';
import { ReferralPage } from './pages/ReferralPage';
import { ProfilePage } from './pages/ProfilePage';
import { AdminPanel } from './pages/AdminPanel';
import { Headphones, Ban } from 'lucide-react';
import confetti from 'canvas-confetti';

export default function App() {
  // Initialize storage
  useEffect(() => {
    initStorage();
  }, []);

  const [language, setLanguageState] = useState<Language>(() => getLanguage());
  const [currentUser, setCurrentUserState] = useState<User | null>(() => getCurrentUser());
  const [users, setUsersState] = useState<User[]>(() => getAllUsers());
  const [packages, setPackagesState] = useState<VipPackage[]>(() => getPackages());
  const [banners, setBannersState] = useState<Banner[]>(() => getBanners());
  const [tasks, setTasksState] = useState<AdTask[]>(() => getAdTasks());
  const [transactions, setTransactionsState] = useState<Transaction[]>(() => getTransactions());
  const [adminConfig, setAdminConfigState] = useState<AdminConfig>(() => getAdminConfig());
  const [feedItems, setFeedItemsState] = useState<string[]>(() => getFeedItems());
  const [supportMessages, setSupportMessagesState] = useState<SupportMessage[]>(() =>
    getSupportMessages()
  );

  const [currentTab, setCurrentTab] = useState<BottomTab>('home');
  const [isAdminView, setIsAdminView] = useState(false);
  const [showSecretAdminModal, setShowSecretAdminModal] = useState(false);
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [showWalletSetupModal, setShowWalletSetupModal] = useState(false);
  const [showSupportModal, setShowSupportModal] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [deletedAccountNotice, setDeletedAccountNotice] = useState<string | null>(null);

  const t = translations[language];

  // Helper toast
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Sync state from server (Real Central Persistent DB across all sessions & devices)
  const syncServerState = useCallback(async () => {
    const serverState = await fetchServerState();
    if (!serverState) return;

    if (serverState.deletedUsers && Array.isArray(serverState.deletedUsers)) {
      saveDeletedUsers(serverState.deletedUsers);
    }

    if (serverState.users) {
      setUsersState(serverState.users);
      saveUsers(serverState.users);

      const currId = currentUser?.id || localStorage.getItem('earnlance_current_user_id');
      if (currId) {
        // Immediate check: Was this active user deleted by admin?
        const isDeleted =
          isUserDeleted(currId) ||
          (currentUser?.phone && isUserDeleted(currentUser.phone)) ||
          (serverState.deletedUsers &&
            serverState.deletedUsers.some(
              (d: any) =>
                d.id === currId ||
                (currentUser?.phone && d.phone && d.phone.toLowerCase() === currentUser.phone.toLowerCase())
            ));

        if (isDeleted) {
          setCurrentUserId(null);
          setCurrentUserState(null);
          localStorage.removeItem('earnlance_current_user_id');
          setDeletedAccountNotice(
            language === 'bn'
              ? 'আপনার এই অ্যাকাউন্টটি অ্যাডমিন কর্তৃক ডিলিট/মুছে ফেলা হয়েছে! আপনি আর এই আইডিতে লগইন করতে পারবেন না।'
              : 'Your account has been deleted by administration! You can no longer access this account.'
          );
          return;
        }

        const found = serverState.users.find((u) => u.id === currId);
        if (found) {
          if (found.isBlocked) {
            setCurrentUserId(null);
            setCurrentUserState(null);
            localStorage.removeItem('earnlance_current_user_id');
            triggerToast(t.accountBlocked);
          } else {
            setCurrentUserState(found);
          }
        } else {
          // User was removed/deleted from server DB! Immediately log out and notify
          setCurrentUserId(null);
          setCurrentUserState(null);
          localStorage.removeItem('earnlance_current_user_id');
          if (currentUser?.phone) {
            addDeletedUser(currId, currentUser.phone);
          }
          setDeletedAccountNotice(
            language === 'bn'
              ? 'আপনার এই অ্যাকাউন্টটি অ্যাডমিন কর্তৃক ডিলিট/মুছে ফেলা হয়েছে! আপনি আর এই আইডিতে লগইন করতে পারবেন না।'
              : 'Your account has been deleted by administration! You can no longer access this account.'
          );
        }
      }
    }
    if (serverState.packages) {
      setPackagesState(serverState.packages);
      savePackages(serverState.packages);
    }
    if (serverState.banners) {
      setBannersState(serverState.banners);
      saveBanners(serverState.banners);
    }
    if (serverState.tasks) {
      setTasksState(serverState.tasks);
      saveAdTasks(serverState.tasks);
    }
    if (serverState.transactions) {
      setTransactionsState(serverState.transactions);
      saveTransactions(serverState.transactions);
    }
    if (serverState.adminConfig) {
      setAdminConfigState(serverState.adminConfig);
      saveAdminConfig(serverState.adminConfig);
    }
    if (serverState.feedItems) {
      setFeedItemsState(serverState.feedItems);
      saveFeedItems(serverState.feedItems);
    }
    if (serverState.supportMessages) {
      setSupportMessagesState(serverState.supportMessages);
      saveSupportMessages(serverState.supportMessages);
    }
  }, [currentUser?.id, t.accountBlocked]);

  // Initial and recurring sync
  useEffect(() => {
    syncServerState();
    const interval = setInterval(syncServerState, 4000);
    return () => clearInterval(interval);
  }, [syncServerState]);

  // Switch Language
  const handleLanguageChange = (newLang: Language) => {
    setLanguageState(newLang);
    saveLanguage(newLang);
  };

  // Users Update Handlers
  const handleUpdateUsers = async (newUsers: User[]) => {
    setUsersState(newUsers);
    saveUsers(newUsers);
    await apiUpdateAdminUsers(newUsers);
    syncServerState();
  };

  const handleUpdateCurrentUser = async (updatedUser: User) => {
    setCurrentUserState(updatedUser);
    const updatedUsers = users.map((u) => (u.id === updatedUser.id ? updatedUser : u));
    handleUpdateUsers(updatedUsers);
    await apiUpdateUser(updatedUser);
  };

  const handleLoginSuccess = (user: User) => {
    setCurrentUserId(user.id);
    setCurrentUserState(user);
    triggerToast(t.loginSuccess);
    syncServerState();
  };

  const handleRegisterSuccess = (newUser: User) => {
    const updatedUsers = [newUser, ...users];
    handleUpdateUsers(updatedUsers);
    setCurrentUserId(newUser.id);
    setCurrentUserState(newUser);
    triggerToast(t.registerSuccess);
    syncServerState();
  };

  const handleLogout = () => {
    setCurrentUserId(null);
    setCurrentUserState(null);
    setCurrentTab('home');
  };

  // Save wallet setup once: user cannot change it once set
  const handleSaveFirstTimeSetup = async (
    method: 'bKash' | 'Nagad',
    walletNumber: string,
    withdrawPassword: string
  ) => {
    if (!currentUser) return;
    if (currentUser.paymentDetailsSet) return;
    const updated: User = {
      ...currentUser,
      paymentMethod: method,
      bkashNagadNumber: walletNumber,
      withdrawPassword,
      paymentDetailsSet: true,
    };
    await handleUpdateCurrentUser(updated);
    triggerToast(
      language === 'bn' ? 'ওয়ালেট সফলভাবে যুক্ত হয়েছে!' : 'Wallet successfully added!'
    );
  };

  // VIP Package Purchase & Upgrade: Single active package rule, auto-terminate with refund & no downgrade
  const handlePurchasePackage = async (pkg: VipPackage) => {
    if (!currentUser) return;

    if (currentUser.activePackageId === pkg.id) {
      triggerToast(language === 'bn' ? 'এই প্যাকেজটি ইতিমধ্যে আপনার সক্রিয় রয়েছে!' : 'This package is already active!');
      return;
    }

    const currentActivePkg = currentUser.activePackageId
      ? packages.find((p) => p.id === currentUser.activePackageId)
      : null;

    if (currentActivePkg && pkg.price <= currentActivePkg.price) {
      triggerToast(
        language === 'bn'
          ? 'বড় প্যাকেজ থেকে ছোট প্যাকেজ কেনা সম্ভব নয়। আপনি শুধুমাত্র উচ্চতর প্যাকেজে আপগ্রেড করতে পারবেন।'
          : 'Downgrade is not allowed. You can only upgrade to a larger package.'
      );
      return;
    }

    const refundAmount = currentActivePkg ? currentActivePkg.price : 0;
    const availableBalance = currentUser.balance + refundAmount;

    if (availableBalance < pkg.price) {
      triggerToast(t.insufficientBalance);
      setShowDepositModal(true);
      return;
    }

    const res = await apiPurchasePackage(currentUser.id, pkg.id);
    if (res.success && res.user) {
      handleUpdateCurrentUser(res.user);
      try {
        confetti({ particleCount: 75, spread: 60, origin: { y: 0.7 } });
      } catch {}

      if (res.refundedAmount && res.refundedAmount > 0) {
        triggerToast(
          language === 'bn'
            ? `পূর্বের ${res.previousPackageName || 'প্যাকেজের'} ৳${res.refundedAmount} ব্যালেন্সে রিফান্ড সহ ${pkg.nameBn} সফলভাবে অ্যাক্টিভ হয়েছে!`
            : `${pkg.name} activated! Previous package refunded ৳${res.refundedAmount} to balance.`
        );
      } else {
        triggerToast(
          language === 'bn'
            ? `${pkg.nameBn} সফলভাবে অ্যাক্টিভ করা হয়েছে!`
            : `${pkg.name} activated successfully!`
        );
      }
      syncServerState();
    } else {
      triggerToast(res.error || (language === 'bn' ? 'প্যাকেজ অ্যাক্টিভেশন ব্যর্থ হয়েছে' : 'Package activation failed'));
    }
  };

  // Task Completion following Rule 7 & Auto Live Feed
  const handleCompleteTask = async (_taskId: string) => {
    if (!currentUser || !currentUser.activePackageId) return;

    const res = await apiCompleteTask(currentUser.id);
    if (res.success && res.user) {
      handleUpdateCurrentUser(res.user);
      if (res.user.tasksCompletedToday >= 5) {
        try {
          confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
        } catch {}
        triggerToast(
          language === 'bn'
            ? 'অভিনন্দন! আজকের কাজ সম্পন্ন ও ব্যালেন্স জমা হয়েছে!'
            : 'Tasks Completed! Daily profit credited!'
        );
      } else {
        triggerToast(
          language === 'bn'
            ? `কাজ ${res.user.tasksCompletedToday}/৫ সম্পন্ন`
            : `Task ${res.user.tasksCompletedToday}/5 completed`
        );
      }
      syncServerState();
    } else {
      triggerToast(res.error || 'কাজ সম্পন্ন করা যায়নি');
    }
  };

  // Deposit Request with Auto Live Feed
  const handleSubmitDeposit = async (
    amount: number,
    method: 'bKash' | 'Nagad',
    senderNumber: string,
    trxId: string
  ) => {
    if (!currentUser) return;
    const res = await apiSubmitDeposit({
      userId: currentUser.id,
      amount,
      method,
      senderNumber,
      trxId,
    });
    if (res.success && res.transaction) {
      setTransactionsState((prev) => [res.transaction!, ...prev]);
      triggerToast(t.depositSubmitted);
      syncServerState();
    } else {
      triggerToast(res.error || 'ডিপোজিট রিকোয়েস্ট ব্যর্থ হয়েছে');
    }
  };

  // Withdraw Request with Auto Live Feed
  const handleSubmitWithdraw = async (amount: number, withdrawPassword: string) => {
    if (!currentUser) return;
    const res = await apiSubmitWithdraw({
      userId: currentUser.id,
      amount,
      withdrawPassword,
    });
    if (res.success && res.transaction) {
      if (res.user) handleUpdateCurrentUser(res.user);
      setTransactionsState((prev) => [res.transaction!, ...prev]);
      triggerToast(t.withdrawSubmitted);
      syncServerState();
    } else {
      triggerToast(res.error || 'উত্তোলন ব্যর্থ হয়েছে');
    }
  };

  // Approve / Reject Transaction in Admin
  const handleUpdateTransactionStatus = async (txId: string, status: 'approved' | 'rejected') => {
    const res = await apiUpdateTransactionStatus(txId, status);
    await syncServerState();
    return res;
  };

  // Admin Manual Balance Adjust (Add or Deduct)
  const handleAdjustUserBalance = async (
    userId: string,
    action: 'add' | 'deduct',
    amount: number,
    note?: string
  ) => {
    const res = await apiAdjustUserBalance(userId, action, amount, note);
    await syncServerState();
    return res;
  };

  // Block / Unblock User in Admin
  const handleToggleBlock = async (userId: string) => {
    await apiToggleBlockUser(userId);
    syncServerState();
  };

  // Delete User in Admin (Admin Only)
  const handleDeleteUser = async (userId: string) => {
    const target = users.find((u) => u.id === userId);
    const targetPhone = target?.phone || userId;

    // 1. Immediately track as deleted
    addDeletedUser(userId, targetPhone);

    // 2. Remove from local state & cache
    const filtered = users.filter((u) => u.id !== userId);
    setUsersState(filtered);
    saveUsers(filtered);

    // 3. If the deleted user is currently the active session user, immediately kick out and show prominent notice
    const currId = currentUser?.id || localStorage.getItem('earnlance_current_user_id');
    if (currId === userId || (target && currentUser?.phone === target.phone)) {
      setCurrentUserId(null);
      setCurrentUserState(null);
      localStorage.removeItem('earnlance_current_user_id');
      setDeletedAccountNotice(
        language === 'bn'
          ? 'আপনার এই অ্যাকাউন্টটি অ্যাডমিন কর্তৃক ডিলিট/মুছে ফেলা হয়েছে! আপনি আর এই আইডিতে লগইন করতে পারবেন না।'
          : 'Your account has been permanently deleted by the administrator! You can no longer access this account.'
      );
    }

    // 4. Call backend API to delete and persist
    try {
      const res = await apiDeleteUser(userId);
      if (res && res.success && res.users) {
        setUsersState(res.users);
        saveUsers(res.users);
      }
      if (res && res.deletedUsers) {
        saveDeletedUsers(res.deletedUsers);
      }
    } catch (err) {
      console.warn('API delete user failed, local deletion preserved:', err);
    }
    syncServerState();
  };

  // In-App Support Message send
  const handleSendSupportMessage = async (text: string) => {
    if (!currentUser) return;
    const res = await apiSendSupportMessage({
      userId: currentUser.id,
      text,
      sender: 'user',
    });
    if (res.success && res.message) {
      setSupportMessagesState((prev) => [...prev, res.message!]);
      syncServerState();
    }
  };

  const handleSendAdminReply = async (userId: string, text: string) => {
    const res = await apiSendSupportMessage({
      userId,
      text,
      sender: 'admin',
    });
    if (res.success && res.message) {
      setSupportMessagesState((prev) => [...prev, res.message!]);
      syncServerState();
    }
  };

  // Check 24 hour reset for current user tasks
  useEffect(() => {
    if (!currentUser?.lastTaskTimestamp || currentUser.tasksCompletedToday < 5) return;
    const now = Date.now();
    if (now - currentUser.lastTaskTimestamp >= 24 * 3600 * 1000) {
      handleUpdateCurrentUser({
        ...currentUser,
        tasksCompletedToday: 0,
      });
    }
  }, [currentUser]);

  // Create User in Admin (Admin Only - No referral code required, auto referral code generated)
  const handleAdminCreateUser = async (data: {
    phone: string;
    password?: string;
    balance?: number;
    packageId?: string;
  }) => {
    const cleanPhone = (data.phone || '').trim();
    if (!cleanPhone) {
      return { success: false, error: 'মোবাইল নাম্বার বা ইউজার আইডি লিখুন।' };
    }

    // Check duplicate
    const existing = users.find(
      (u) =>
        (u.phone && u.phone.toLowerCase() === cleanPhone.toLowerCase()) ||
        (u.id && u.id.toLowerCase() === cleanPhone.toLowerCase())
    );
    if (existing) {
      return { success: false, error: 'এই নাম্বার বা আইডিতে ইতিমধ্যে একাউন্ট রয়েছে!' };
    }

    // Un-delete from local deletedUsers if previously deleted
    removeDeletedUser(cleanPhone);

    try {
      const res = await apiAdminCreateUser(data);
      if (res && res.success && res.user) {
        if (res.users && Array.isArray(res.users)) {
          setUsersState(res.users);
          saveUsers(res.users);
        } else {
          const next = [res.user, ...users];
          setUsersState(next);
          saveUsers(next);
        }
        if (res.transactions && Array.isArray(res.transactions)) {
          setTransactionsState(res.transactions);
          saveTransactions(res.transactions);
        }
        if (res.deletedUsers && Array.isArray(res.deletedUsers)) {
          saveDeletedUsers(res.deletedUsers);
        }
        syncServerState();
        return res;
      }
      // Only return if it's explicitly a duplicate validation error
      if (res && res.error && res.error.includes('ইতিমধ্যে')) {
        return res;
      }
    } catch (err) {
      console.warn('Backend create user failed, applying fallback:', err);
    }

    // Client-side fallback if backend network is unreachable or running in static preview
    const newRef = 'EL' + Math.floor(100000 + Math.random() * 900000);
    const initialBal = Math.max(0, Number(data.balance) || 0);
    const fallbackUser: User = {
      id: `user_${Date.now()}`,
      phone: cleanPhone,
      password: data.password?.trim() || '123456',
      balance: initialBal,
      totalDeposit: initialBal,
      totalWithdraw: 0,
      totalEarned: 0,
      referralCode: newRef,
      referredBy: null, // Admin-created: No referral code required!
      activePackageId: data.packageId || null,
      purchasedPackageIds: data.packageId ? [data.packageId] : [],
      packageActivatedAt: data.packageId ? new Date().toISOString() : null,
      bkashNagadNumber: null,
      withdrawPassword: null,
      paymentMethod: null,
      paymentDetailsSet: false,
      tasksCompletedToday: 0,
      lastTaskTimestamp: null,
      isBlocked: false,
      createdAt: new Date().toISOString(),
    };

    const nextUsers = [fallbackUser, ...users];
    setUsersState(nextUsers);
    saveUsers(nextUsers);

    if (initialBal > 0) {
      const initTx: Transaction = {
        id: `tx-init-${Date.now()}`,
        userId: fallbackUser.id,
        userPhone: fallbackUser.phone,
        type: 'deposit',
        amount: initialBal,
        status: 'approved',
        method: 'অ্যাডমিন প্রারম্ভিক ব্যালেন্স',
        accountNumber: 'Admin Panel',
        trxId: `ADMIN-INIT-${Date.now().toString().slice(-4)}`,
        createdAt: new Date().toISOString(),
      };
      const nextTx = [initTx, ...transactions];
      setTransactionsState(nextTx);
      saveTransactions(nextTx);
    }

    try {
      await apiUpdateAdminUsers(nextUsers);
    } catch {
      // offline
    }
    syncServerState();
    return { success: true, user: fallbackUser, users: nextUsers };
  };

  // If in Admin View, show full Admin Panel
  if (isAdminView) {
    return (
      <AdminPanel
        adminConfig={adminConfig}
        packages={packages}
        banners={banners}
        tasks={tasks}
        users={users}
        transactions={transactions}
        supportMessages={supportMessages}
        language={language}
        onUpdateAdminConfig={async (cfg) => {
          setAdminConfigState(cfg);
          saveAdminConfig(cfg);
          await apiUpdateAdminConfig(cfg);
        }}
        onUpdatePackages={async (pkgs) => {
          setPackagesState(pkgs);
          savePackages(pkgs);
          await apiUpdatePackages(pkgs);
        }}
        onUpdateBanners={async (bans) => {
          setBannersState(bans);
          saveBanners(bans);
          await apiUpdateBanners(bans);
        }}
        onUpdateTasks={async (newTasks) => {
          setTasksState(newTasks);
          saveAdTasks(newTasks);
          await apiUpdateTasks(newTasks);
        }}
        onUpdateUsers={handleUpdateUsers}
        onUpdateTransactions={async (txs) => {
          setTransactionsState(txs);
          saveTransactions(txs);
        }}
        onUpdateTransactionStatus={handleUpdateTransactionStatus}
        onAdjustUserBalance={handleAdjustUserBalance}
        onCreateUser={handleAdminCreateUser}
        onSendSupportReply={handleSendAdminReply}
        onDeleteUser={handleDeleteUser}
        onExitAdmin={() => setIsAdminView(false)}
      />
    );
  }

  // If not logged in, show AuthScreen (Login & Register)
  if (!currentUser) {
    return (
      <>
        <AuthScreen
          users={users}
          language={language}
          onLanguageChange={handleLanguageChange}
          onLoginSuccess={handleLoginSuccess}
          onRegisterSuccess={handleRegisterSuccess}
          onSecretAdminClick={() => setShowSecretAdminModal(true)}
        />

        {/* Secret Admin Modal (Rule 2 - 5 Clicks) */}
        <SecretAdminEntryModal
          isOpen={showSecretAdminModal}
          onClose={() => setShowSecretAdminModal(false)}
          correctPassword={adminConfig.adminPassword}
          onSuccess={() => {
            setShowSecretAdminModal(false);
            setIsAdminView(true);
          }}
        />
      </>
    );
  }

  // Main Authenticated Client App
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-amber-500 selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl bg-slate-900 border border-amber-500/50 text-amber-300 font-bold text-xs shadow-2xl animate-in slide-in-from-top duration-200 flex items-center gap-2">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Header with Secret 5-Click logo */}
      <Header
        currentUser={currentUser}
        language={language}
        onLanguageChange={handleLanguageChange}
        onOpenSecretAdmin={() => setShowSecretAdminModal(true)}
        onOpenSupport={() => setShowSupportModal(true)}
        onOpenDeposit={() => setShowDepositModal(true)}
      />

      {/* Main Mobile App Container */}
      <main className="flex-1 max-w-md w-full mx-auto px-3.5 pt-2">
        {currentTab === 'home' && (
          <HomePage
            currentUser={currentUser}
            banners={banners}
            packages={packages}
            adminConfig={adminConfig}
            feedItems={feedItems}
            language={language}
            onNavigateTab={(tab) => setCurrentTab(tab)}
            onOpenDeposit={() => setShowDepositModal(true)}
            onOpenWithdraw={() => {
              if (!currentUser.paymentDetailsSet) {
                setShowWalletSetupModal(true);
              } else {
                setShowWithdrawModal(true);
              }
            }}
            onOpenSupport={() => setShowSupportModal(true)}
          />
        )}

        {currentTab === 'vip' && (
          <VipPage
            currentUser={currentUser}
            packages={packages}
            language={language}
            onPurchasePackage={handlePurchasePackage}
            onOpenDeposit={() => setShowDepositModal(true)}
          />
        )}

        {currentTab === 'task' && (
          <TaskPage
            currentUser={currentUser}
            tasks={tasks}
            packages={packages}
            language={language}
            onNavigateToVip={() => setCurrentTab('vip')}
            onCompleteTask={handleCompleteTask}
          />
        )}

        {currentTab === 'referral' && (
          <ReferralPage
            currentUser={currentUser}
            allUsers={users}
            transactions={transactions}
            language={language}
          />
        )}

        {currentTab === 'profile' && (
          <ProfilePage
            currentUser={currentUser}
            packages={packages}
            transactions={transactions}
            language={language}
            onLanguageChange={handleLanguageChange}
            onOpenDeposit={() => setShowDepositModal(true)}
            onOpenWithdraw={() => {
              if (!currentUser.paymentDetailsSet) {
                setShowWalletSetupModal(true);
              } else {
                setShowWithdrawModal(true);
              }
            }}
            onOpenSupport={() => setShowSupportModal(true)}
            onOpenWalletSetup={() => {
              if (!currentUser.paymentDetailsSet) {
                setShowWalletSetupModal(true);
              }
            }}
            onLogout={handleLogout}
          />
        )}
      </main>

      {/* Floating Live Chat Action Button */}
      <div className="fixed bottom-[4.5rem] right-3.5 z-40">
        <button
          onClick={() => setShowSupportModal(true)}
          className="group flex items-center gap-1.5 pl-3 pr-3.5 py-2 rounded-full bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs shadow-2xl shadow-blue-500/50 border border-blue-400/40 active:scale-95 transition-all duration-200 backdrop-blur-md"
          title={language === 'bn' ? 'সরাসরি সাপোর্ট' : 'Live Chat'}
        >
          <div className="relative">
            <Headphones className="w-4 h-4 text-amber-300 group-hover:scale-110 transition" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-slate-900 animate-ping" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-slate-900" />
          </div>
          <span className="tracking-wide text-[11px] font-bold text-white drop-shadow-sm">
            {language === 'bn' ? 'লাইভ সাপোর্ট' : 'Live Chat'}
          </span>
        </button>
      </div>

      {/* Fixed 5-Item Bottom Navigation */}
      <BottomNav
        currentTab={currentTab}
        onTabChange={(tab) => setCurrentTab(tab)}
        language={language}
        hasActivePackage={Boolean(currentUser.activePackageId)}
        tasksCompleted={currentUser.tasksCompletedToday || 0}
      />

      {/* Wallet Setup Modal: Can be opened anytime by user without blocking registration */}
      <FirstTimeSetupModal
        isOpen={showWalletSetupModal}
        language={language}
        onSave={handleSaveFirstTimeSetup}
        onClose={() => setShowWalletSetupModal(false)}
      />

      {/* Deposit Modal */}
      <DepositModal
        isOpen={showDepositModal}
        onClose={() => setShowDepositModal(false)}
        user={currentUser}
        adminConfig={adminConfig}
        language={language}
        onSubmitDeposit={handleSubmitDeposit}
      />

      {/* Withdraw Modal */}
      <WithdrawModal
        isOpen={showWithdrawModal}
        onClose={() => setShowWithdrawModal(false)}
        user={currentUser}
        adminConfig={adminConfig}
        language={language}
        onSubmitWithdraw={handleSubmitWithdraw}
      />

      {/* Rule 11: In-App Support Chat Modal */}
      <SupportModal
        isOpen={showSupportModal}
        onClose={() => setShowSupportModal(false)}
        user={currentUser}
        messages={supportMessages}
        language={language}
        onSendMessage={handleSendSupportMessage}
      />

      {/* Rule 2: Secret Admin Entry Modal */}
      <SecretAdminEntryModal
        isOpen={showSecretAdminModal}
        onClose={() => setShowSecretAdminModal(false)}
        correctPassword={adminConfig.adminPassword}
        onSuccess={() => {
          setShowSecretAdminModal(false);
          setIsAdminView(true);
        }}
      />
    </div>
  );
}
