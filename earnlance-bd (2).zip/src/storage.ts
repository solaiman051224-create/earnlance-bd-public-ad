import {
  User,
  VipPackage,
  Banner,
  AdTask,
  Transaction,
  SupportMessage,
  AdminConfig,
  Language,
} from './types';

const STORAGE_KEYS = {
  USERS: 'earnlance_users',
  CURRENT_USER_ID: 'earnlance_current_user_id',
  PACKAGES: 'earnlance_packages',
  BANNERS: 'earnlance_banners',
  TASKS: 'earnlance_tasks',
  TRANSACTIONS: 'earnlance_transactions',
  FEED_ITEMS: 'earnlance_feed_items',
  SUPPORT_MESSAGES: 'earnlance_support_messages',
  ADMIN_CONFIG: 'earnlance_admin_config',
  LANGUAGE: 'earnlance_language',
  DELETED_USERS: 'earnlance_deleted_users',
};

// 10 Default VIP Packages
export const DEFAULT_PACKAGES: VipPackage[] = [
  {
    id: 'vip-1',
    tier: 1,
    name: 'VIP 1 Starter',
    nameBn: 'ভিআইপি ১ স্টারটার',
    price: 500,
    dailyIncome: 50,
    validityDays: 30,
    isActive: true,
    description: 'Entry package for beginners with high daily ROI',
    badgeColor: 'from-blue-500 to-indigo-600',
  },
  {
    id: 'vip-2',
    tier: 2,
    name: 'VIP 2 Bronze',
    nameBn: 'ভিআইপি ২ ব্রোঞ্জ',
    price: 1000,
    dailyIncome: 110,
    validityDays: 30,
    isActive: true,
    description: 'Double your earning potential with fast return',
    badgeColor: 'from-amber-600 to-orange-600',
  },
  {
    id: 'vip-3',
    tier: 3,
    name: 'VIP 3 Silver',
    nameBn: 'ভিআইপি ৩ সিলভার',
    price: 2000,
    dailyIncome: 230,
    validityDays: 30,
    isActive: true,
    description: 'Most popular package among active community members',
    badgeColor: 'from-slate-400 to-zinc-600',
  },
  {
    id: 'vip-4',
    tier: 4,
    name: 'VIP 4 Gold',
    nameBn: 'ভিআইপি ৪ গোল্ড',
    price: 3000,
    dailyIncome: 360,
    validityDays: 35,
    isActive: true,
    description: 'Enhanced profit tier with extended package validity',
    badgeColor: 'from-yellow-400 to-amber-500',
  },
  {
    id: 'vip-5',
    tier: 5,
    name: 'VIP 5 Platinum',
    nameBn: 'ভিআইপি ৫ প্লাটিনাম',
    price: 5000,
    dailyIncome: 650,
    validityDays: 40,
    isActive: true,
    description: 'High return investment designed for regular earners',
    badgeColor: 'from-cyan-500 to-blue-600',
  },
  {
    id: 'vip-6',
    tier: 6,
    name: 'VIP 6 Diamond',
    nameBn: 'ভিআইপি ৬ ডায়মন্ড',
    price: 10000,
    dailyIncome: 1350,
    validityDays: 45,
    isActive: true,
    description: 'Premium tier with fast bKash & Nagad withdrawal priority',
    badgeColor: 'from-teal-400 to-emerald-600',
  },
  {
    id: 'vip-7',
    tier: 7,
    name: 'VIP 7 Crown',
    nameBn: 'ভিআইপি ৭ ক্রাউন',
    price: 15000,
    dailyIncome: 2100,
    validityDays: 50,
    isActive: true,
    description: 'Elite level investment with guaranteed high daily payouts',
    badgeColor: 'from-purple-500 to-indigo-700',
  },
  {
    id: 'vip-8',
    tier: 8,
    name: 'VIP 8 Master',
    nameBn: 'ভিআইপি ৮ মাস্টার',
    price: 25000,
    dailyIncome: 3700,
    validityDays: 60,
    isActive: true,
    description: 'Masterclass earning bracket with dedicated account priority',
    badgeColor: 'from-rose-500 to-red-700',
  },
  {
    id: 'vip-9',
    tier: 9,
    name: 'VIP 9 Grand Master',
    nameBn: 'ভিআইপি ৯ গ্র্যান্ড মাস্টার',
    price: 50000,
    dailyIncome: 7800,
    validityDays: 65,
    isActive: true,
    description: 'Top enterprise level daily profit generator',
    badgeColor: 'from-fuchsia-600 to-purple-800',
  },
  {
    id: 'vip-10',
    tier: 10,
    name: 'VIP 10 Ultimate Sovereign',
    nameBn: 'ভিআইপি ১০ আলটিমেট সভারেন',
    price: 100000,
    dailyIncome: 16500,
    validityDays: 70,
    isActive: true,
    description: 'The supreme VIP investment package of Earnlance BD',
    badgeColor: 'from-amber-400 via-yellow-300 to-yellow-600',
  },
];

// 10 Default Banners
export const DEFAULT_BANNERS: Banner[] = [
  {
    id: 'ban-1',
    title: 'Earnlance BD Investment',
    subtitle: '100% Reliable Daily Income & Quick Payouts',
    imageUrl: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&auto=format&fit=crop&q=80',
    linkText: 'Join VIP Now',
    tag: 'Official Launch',
    bgGradient: 'from-blue-900 via-indigo-900 to-slate-900',
    isActive: true,
  },
  {
    id: 'ban-2',
    title: 'Daily 5 Task Watching',
    subtitle: 'Watch simple sponsor videos & get guaranteed profit',
    imageUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=800&auto=format&fit=crop&q=80',
    linkText: 'Start Tasks',
    tag: 'Daily Work',
    bgGradient: 'from-sky-900 via-blue-950 to-slate-900',
    isActive: true,
  },
  {
    id: 'ban-3',
    title: 'Instant bKash & Nagad Cashout',
    subtitle: 'Safe, direct, and automated wallet withdrawals',
    imageUrl: 'https://images.unsplash.com/photo-1556742049-0a67c5574f73?w=800&auto=format&fit=crop&q=80',
    linkText: 'Check Wallet',
    tag: 'Fast Payout',
    bgGradient: 'from-amber-900 via-yellow-950 to-slate-900',
    isActive: true,
  },
  {
    id: 'ban-4',
    title: 'VIP Packages 1 to 10',
    subtitle: 'From 500 TK to 100,000 TK with high daily returns',
    imageUrl: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=800&auto=format&fit=crop&q=80',
    linkText: 'Upgrade Tier',
    tag: 'High Yield',
    bgGradient: 'from-purple-900 via-indigo-950 to-slate-900',
    isActive: true,
  },
  {
    id: 'ban-5',
    title: 'Earnlance Referral Program',
    subtitle: 'Earn direct commission by inviting your network',
    imageUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&auto=format&fit=crop&q=80',
    linkText: 'Invite Friends',
    tag: 'Commission',
    bgGradient: 'from-emerald-900 via-teal-950 to-slate-900',
    isActive: true,
  },
  {
    id: 'ban-6',
    title: 'One-Account Protection',
    subtitle: 'Strict security against duplicate numbers & fraud',
    imageUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop&q=80',
    linkText: 'Security Notice',
    tag: 'Safe & Secure',
    bgGradient: 'from-slate-800 via-slate-900 to-black',
    isActive: true,
  },
  {
    id: 'ban-7',
    title: '24/7 Live Support',
    subtitle: 'Send your query, the system administrator will assist you directly',
    imageUrl: 'https://images.unsplash.com/photo-1534536281715-e28d76689b4d?w=800&auto=format&fit=crop&q=80',
    linkText: 'Get Support',
    tag: 'Live Chat',
    bgGradient: 'from-blue-950 via-slate-900 to-zinc-900',
    isActive: true,
  },
  {
    id: 'ban-8',
    title: 'Lifetime Single Purchase Rule',
    subtitle: 'Fair community policies: 1 package per lifetime per tier',
    imageUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=800&auto=format&fit=crop&q=80',
    linkText: 'Platform Rules',
    tag: 'Fair Play',
    bgGradient: 'from-stone-900 via-neutral-900 to-zinc-950',
    isActive: true,
  },
  {
    id: 'ban-9',
    title: 'Automated 24h Reset Timer',
    subtitle: 'Daily video tasks reset smoothly every 24 hours',
    imageUrl: 'https://images.unsplash.com/photo-1501139083538-0139583c060f?w=800&auto=format&fit=crop&q=80',
    linkText: 'View Schedule',
    tag: 'Auto Reset',
    bgGradient: 'from-cyan-950 via-slate-900 to-slate-950',
    isActive: true,
  },
  {
    id: 'ban-10',
    title: 'Smart Investment, Real Profit',
    subtitle: 'Join thousands of satisfied Bangladeshi investors today',
    imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80',
    linkText: 'Get Started',
    tag: 'Earnlance BD',
    bgGradient: 'from-indigo-950 via-blue-900 to-slate-950',
    isActive: true,
  },
];

// Default 5 Video/Ad Tasks
export const DEFAULT_TASKS: AdTask[] = [
  {
    id: 'task-1',
    title: 'Digital Marketing & Growth Ad',
    titleBn: 'ডিজিটাল মার্কেটিং ও ব্র্যান্ড গ্রোথ ভিডিও',
    sponsor: 'TechBD Global',
    category: 'Technology',
    durationSeconds: 6,
    thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&auto=format&fit=crop&q=80',
    isActive: true,
  },
  {
    id: 'task-2',
    title: 'Smart Fintech & Mobile Banking',
    titleBn: 'স্মার্ট ফিনটেক ও মোবাইল ব্যাংকিং স্পন্সর',
    sponsor: 'PayStream Asia',
    category: 'Fintech',
    durationSeconds: 6,
    thumbnail: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=500&auto=format&fit=crop&q=80',
    isActive: true,
  },
  {
    id: 'task-3',
    title: 'E-Commerce Super Brand Promo',
    titleBn: 'ই-কমার্স সুপার ব্র্যান্ড প্রমোশন',
    sponsor: 'ShopBazaar BD',
    category: 'E-Commerce',
    durationSeconds: 6,
    thumbnail: 'https://images.unsplash.com/photo-1522204523234-8729aa6e3d5f?w=500&auto=format&fit=crop&q=80',
    isActive: true,
  },
  {
    id: 'task-4',
    title: 'Cloud Infrastructure & AI Tools',
    titleBn: 'ক্লাউড নেটওয়ার্ক ও এআই টেকনোলজি',
    sponsor: 'Apex Cloud Systems',
    category: 'Artificial Intelligence',
    durationSeconds: 6,
    thumbnail: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=500&auto=format&fit=crop&q=80',
    isActive: true,
  },
  {
    id: 'task-5',
    title: 'Global Trade & Currency Exchange',
    titleBn: 'গ্লোবাল ট্রেড ও কারেন্সি একচেঞ্জ রিভিউ',
    sponsor: 'Prime FX International',
    category: 'Trading',
    durationSeconds: 6,
    thumbnail: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=500&auto=format&fit=crop&q=80',
    isActive: true,
  },
];

// Activity Feed items reflecting realistic user actions
export const DEFAULT_FEED_ITEMS: string[] = [
  'Karim 1,200 TK Withdraw',
  'Rahim 500 TK Deposit',
  'Tanvir VIP 2 Activated',
  'Hasan 2,000 TK Deposit',
  'Sumon 3,500 TK Withdraw',
  'Faruk VIP 3 Activated',
  'Jamil 1,000 TK Deposit',
  'Arif 5,000 TK VIP 5 Activated',
  'Mahmud 1,800 TK Withdraw',
  'Rakib 500 TK Deposit',
  'Shuvo VIP 1 Activated',
  'Kamal 2,200 TK Withdraw',
];

// Default Admin Config
export const DEFAULT_ADMIN_CONFIG: AdminConfig = {
  adminPassword: 'admin',
  bkashNumber: '01812345678',
  nagadNumber: '01798765432',
  bkashType: 'Send Money (Personal)',
  nagadType: 'Send Money (Personal)',
  minDeposit: 500,
  minWithdraw: 200,
  feedActive: true,
  customFeedItems: [...DEFAULT_FEED_ITEMS],
};

export const DEFAULT_USERS: User[] = [];
export const DEFAULT_TRANSACTIONS: Transaction[] = [];
export const DEFAULT_SUPPORT: SupportMessage[] = [];

// Helper functions for LocalStorage cache
export function getStoredData<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch {
    return fallback;
  }
}

export function setStoredData<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.error('Failed to save to localStorage:', err);
  }
}

export function initStorage(): void {
  if (!localStorage.getItem(STORAGE_KEYS.PACKAGES)) {
    setStoredData(STORAGE_KEYS.PACKAGES, DEFAULT_PACKAGES);
  }
  if (!localStorage.getItem(STORAGE_KEYS.BANNERS)) {
    setStoredData(STORAGE_KEYS.BANNERS, DEFAULT_BANNERS);
  }
  if (!localStorage.getItem(STORAGE_KEYS.TASKS)) {
    setStoredData(STORAGE_KEYS.TASKS, DEFAULT_TASKS);
  }
  if (!localStorage.getItem(STORAGE_KEYS.ADMIN_CONFIG)) {
    setStoredData(STORAGE_KEYS.ADMIN_CONFIG, DEFAULT_ADMIN_CONFIG);
  }
  if (!localStorage.getItem(STORAGE_KEYS.FEED_ITEMS)) {
    setStoredData(STORAGE_KEYS.FEED_ITEMS, DEFAULT_FEED_ITEMS);
  }
  if (!localStorage.getItem(STORAGE_KEYS.LANGUAGE)) {
    setStoredData(STORAGE_KEYS.LANGUAGE, 'bn');
  }
}

// User methods
export function getAllUsers(): User[] {
  return getStoredData<User[]>(STORAGE_KEYS.USERS, DEFAULT_USERS);
}

export function saveUsers(users: User[]): void {
  setStoredData(STORAGE_KEYS.USERS, users);
}

export function getCurrentUser(): User | null {
  const currentId = localStorage.getItem(STORAGE_KEYS.CURRENT_USER_ID);
  if (!currentId) return null;
  const users = getAllUsers();
  return users.find((u) => u.id === currentId) || null;
}

export function setCurrentUserId(userId: string | null): void {
  if (userId) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, userId);
  } else {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER_ID);
  }
}

export function updateUser(updated: User): void {
  const users = getAllUsers();
  const index = users.findIndex((u) => u.id === updated.id);
  if (index !== -1) {
    users[index] = updated;
    saveUsers(users);
  }
}

// Packages
export function getPackages(): VipPackage[] {
  return getStoredData<VipPackage[]>(STORAGE_KEYS.PACKAGES, DEFAULT_PACKAGES);
}

export function savePackages(packages: VipPackage[]): void {
  setStoredData(STORAGE_KEYS.PACKAGES, packages);
}

// Banners
export function getBanners(): Banner[] {
  return getStoredData<Banner[]>(STORAGE_KEYS.BANNERS, DEFAULT_BANNERS);
}

export function saveBanners(banners: Banner[]): void {
  setStoredData(STORAGE_KEYS.BANNERS, banners);
}

// Tasks
export function getAdTasks(): AdTask[] {
  return getStoredData<AdTask[]>(STORAGE_KEYS.TASKS, DEFAULT_TASKS);
}

export function saveAdTasks(tasks: AdTask[]): void {
  setStoredData(STORAGE_KEYS.TASKS, tasks);
}

// Transactions
export function getTransactions(): Transaction[] {
  return getStoredData<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, DEFAULT_TRANSACTIONS);
}

export function saveTransactions(transactions: Transaction[]): void {
  setStoredData(STORAGE_KEYS.TRANSACTIONS, transactions);
}

export function addTransaction(transaction: Transaction): void {
  const all = getTransactions();
  all.unshift(transaction);
  saveTransactions(all);
}

// Feed items
export function getFeedItems(): string[] {
  return getStoredData<string[]>(STORAGE_KEYS.FEED_ITEMS, DEFAULT_FEED_ITEMS);
}

export function saveFeedItems(items: string[]): void {
  setStoredData(STORAGE_KEYS.FEED_ITEMS, items);
}

// Support Messages
export function getSupportMessages(): SupportMessage[] {
  return getStoredData<SupportMessage[]>(STORAGE_KEYS.SUPPORT_MESSAGES, DEFAULT_SUPPORT);
}

export function saveSupportMessages(messages: SupportMessage[]): void {
  setStoredData(STORAGE_KEYS.SUPPORT_MESSAGES, messages);
}

export function addSupportMessage(msg: SupportMessage): void {
  const all = getSupportMessages();
  all.push(msg);
  saveSupportMessages(all);
}

// Admin Config
export function getAdminConfig(): AdminConfig {
  return getStoredData<AdminConfig>(STORAGE_KEYS.ADMIN_CONFIG, DEFAULT_ADMIN_CONFIG);
}

export function saveAdminConfig(config: AdminConfig): void {
  setStoredData(STORAGE_KEYS.ADMIN_CONFIG, config);
}

// Language
export function getLanguage(): Language {
  return getStoredData<Language>(STORAGE_KEYS.LANGUAGE, 'bn');
}

export function saveLanguage(lang: Language): void {
  setStoredData(STORAGE_KEYS.LANGUAGE, lang);
}

// Deleted Users Tracking (Ensures deleted accounts cannot log in or register, even offline)
export interface DeletedUserRecord {
  id: string;
  phone: string;
  deletedAt: string;
}

export function getDeletedUsers(): DeletedUserRecord[] {
  return getStoredData<DeletedUserRecord[]>(STORAGE_KEYS.DELETED_USERS, []);
}

export function saveDeletedUsers(list: DeletedUserRecord[]): void {
  setStoredData(STORAGE_KEYS.DELETED_USERS, list);
}

export function addDeletedUser(id: string, phone: string): void {
  const list = getDeletedUsers();
  const cleanPhone = (phone || '').trim();
  const cleanId = (id || '').trim();
  if (!list.some((d) => d.id === cleanId || (cleanPhone && d.phone === cleanPhone))) {
    list.unshift({ id: cleanId, phone: cleanPhone, deletedAt: new Date().toISOString() });
    saveDeletedUsers(list);
  }
}

export function removeDeletedUser(identifier: string): void {
  if (!identifier) return;
  const clean = identifier.trim().toLowerCase();
  const list = getDeletedUsers().filter(
    (d) => d.id.toLowerCase() !== clean && d.phone.toLowerCase() !== clean
  );
  saveDeletedUsers(list);
}

export function isUserDeleted(identifier: string): boolean {
  if (!identifier) return false;
  const clean = identifier.trim().toLowerCase();
  return getDeletedUsers().some(
    (d) =>
      (d.phone && d.phone.toLowerCase() === clean) ||
      (d.id && d.id.toLowerCase() === clean)
  );
}
